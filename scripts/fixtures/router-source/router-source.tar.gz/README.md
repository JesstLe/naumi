# Naumi Router

Naumi Router is an image-generation routing data plane. It accepts an OpenAI-compatible image request, derives task requirements, selects the cheapest healthy route that can satisfy them, and calls the selected provider adapter.

The project deliberately does **not** reimplement accounts, API keys, channel administration, dashboards, or external API quota management. The intended deployment is:

```text
Naumi infinite canvas (design UI, jobs, assets, product credits)
  -> New API (unified gateway, model aliases, channels, service tokens)
  -> Naumi Router (cost/quality/edit-capability routing, safe failover)
  -> authorized image providers
```

Naumi, an unmodified New API deployment, and Naumi Router remain separate processes and repositories. Naumi calls New API with an internal service token, so Naumi can keep its existing product-credit ledger without double-charging. New API can later expose customer tokens and billing if a standalone API product is launched.

## Current milestone

The first vertical slice is runnable and has one test-ready real provider:

- `POST /v1/images/generations`
- `POST /v1/images/edits` for up to 15 multipart reference images
- `GET /v1/models`
- `GET /healthz`
- `GET /readyz`
- bearer-token authentication between Naumi and the router
- bounded request bodies and input validation
- deterministic cost/quality/latency route selection
- automatic fallback to the next eligible route
- OpenAI-shaped response payload
- no prompts, bearer tokens, or provider secrets in logs

The APIMart and fal.ai adapters are implemented and covered by local fake-server tests. APIMart has passed paid text-to-image and reference-image edit testing. Fal remains available as a backup text-to-image integration. This repository is not production-ready.

## Run locally

```bash
cp .env.example .env
export NAUMI_ROUTER_TOKEN='local-only-change-me'
export NAUMI_ROUTES_CONFIG='config/routes.example.json'
go run ./cmd/server
```

Test the endpoint:

```bash
curl http://127.0.0.1:8081/v1/images/generations \
  -H 'Authorization: Bearer local-only-change-me' \
  -H 'Content-Type: application/json' \
  -d '{
    "model": "naumi-image-auto",
    "prompt": "A clean product photo on a white background",
    "size": "1024x1024",
    "quality": "standard",
    "n": 1
  }'
```

The mock adapter returns a tiny PNG in `b64_json`. It exists only to prove the complete request -> policy -> provider -> response path.

## APIMart adapter — first live test

The first paid smoke test uses APIMart's `gpt-image-2.5-ext` Flare route. The adapter:

- reads `APIMART_KEY` only from the environment;
- sends the documented `X-APIMart-Response-Version` and a fresh UUID idempotency key;
- reuses that same idempotency key if an ambiguous submission must be retried;
- polls `/v1/tasks/{task_id}` without following provider-supplied polling paths;
- records the settled `cost` and `credits_cost` fields in internal logs without exposing them to customers;
- downloads the result, verifies its image header, aspect ratio, and declared resolution tier;
- accepts public HTTPS CDN URLs while rejecting loopback, private, link-local, multicast, and unsafe redirects at the network layer;
- blocks automatic fallback after an ambiguous or accepted paid submission.

Set the key in the local environment—never in Git or chat—then run:

```bash
test -n "$APIMART_KEY"
export NAUMI_ROUTER_TOKEN='local-only-change-me-at-least-24-characters'
export NAUMI_ROUTES_CONFIG='config/routes.apimart.example.json'
go run ./cmd/server
```

In another terminal, make the cheapest 1K test first:

```bash
curl http://127.0.0.1:8081/v1/images/generations \
  -H 'Authorization: Bearer local-only-change-me-at-least-24-characters' \
  -H 'Content-Type: application/json' \
  -d '{
    "model": "naumi-image-standard",
    "prompt": "A red ceramic mug on a white studio background, product photography",
    "size": "1k",
    "quality": "standard",
    "response_format": "url",
    "n": 1
  }'
```

APIMart's public price page currently lists GPT Image 2.5 Ext at `$0.0085`/1K, `$0.014`/2K, and `$0.021`/4K per delivered image. The route file conservatively uses the 4K price for ordering until request-aware pricing is implemented. The task receipt is the source of truth for the paid smoke test.

The 2026-09-19 paid smoke test settled at `$0.0085` / `0.085 Credits` for one 1K image. APIMart delivered a 1254×1254 PNG from `getapib.org`; this confirms that its `1K` label is a pricing/resolution tier rather than an exact 1024×1024 contract.

Important: APIMart's current terms prohibit reselling, redistributing, or white-labeling its API without explicit authorization. This integration is for technical and unit-economics validation only until APIMart gives written commercial authorization.

## fal.ai adapter — backup

The backup adapter uses fal's persistent Queue REST API for GPT Image 2.5 Flare/Sunburst text-to-image endpoints. It:

- reads `FAL_KEY` only from the environment;
- submits with `Authorization: Key ...`;
- polls the trusted queue endpoint until completion;
- never follows status/result URLs returned by the provider;
- validates fal request IDs before constructing URLs;
- verifies returned metadata and the actual PNG dimensions;
- accepts only fal media-host URLs for URL responses;
- treats every failure after queue acceptance as unsafe for automatic fallback, preventing accidental duplicate paid generations.

To enable the example fal routes:

```bash
test -n "$FAL_KEY" # set it in your local secret environment first
export NAUMI_ROUTES_CONFIG='config/routes.fal.example.json'
go run ./cmd/server
```

The example costs are conservative 4K estimates for route ordering. Before mixed-resolution production traffic, replace them with a versioned request-aware price matrix and reconcile estimates against actual fal billing records.

## Routing controls

The public model aliases are:

| Model | Meaning |
|---|---|
| `naumi-image-auto` | Infer the minimum acceptable quality from the request |
| `naumi-image-economy` | Prefer the lowest-cost eligible route |
| `naumi-image-standard` | Require standard-or-better quality |
| `naumi-image-premium` | Require the highest configured quality tier |

Requests may add an optional `naumi` object:

```json
{
  "naumi": {
    "native_resolution": true,
    "text_accuracy": "required"
  }
}
```

`native_resolution` prevents a route that only delivers 4K through upscaling from satisfying a 4K request. `text_accuracy` may be `auto`, `required`, or `best_effort`.

When requests pass through an unmodified New API instance, put these options inside `extra_fields` because New API preserves that declared field but does not forward arbitrary top-level image fields:

```json
{
  "extra_fields": {
    "naumi": {
      "native_resolution": true,
      "text_accuracy": "required"
    }
  }
}
```

## New API integration

New API is the unified gateway in front of the router. See [Naumi integration](docs/NAUMI_INTEGRATION.md) for both sides of the configuration.

Configure the service in an unmodified New API instance as an OpenAI-compatible channel:

- Base URL: `http://naumi-router:8081` (New API appends the incoming `/v1/...` path)
- Channel key: the same secret as `NAUMI_ROUTER_TOKEN`
- Models: `naumi-image-auto`, `naumi-image-economy`, `naumi-image-standard`, `naumi-image-premium`
- Customer-facing billing: configure in New API by model alias
- Actual upstream cost and routing telemetry: retain in Naumi Router

Do not expose Naumi Router directly to customers. New API is the gateway boundary; the router token remains a service credential used only by the New API channel.

For a local two-service deployment, set both secrets from `.env.example` and run:

```bash
docker compose -f deploy/compose.dev.yml up --build
```

The compose file intentionally does not preconfigure a New API channel or create customer credentials. After first-time New API setup, create the channel manually with the settings above. Never reuse `SESSION_SECRET` as `NAUMI_ROUTER_TOKEN`.

For the isolated Linux server deployment, use the checksum-verified official
New API release binary and the systemd units in
[`deploy/server`](deploy/server/README.md). Both services bind to loopback;
customer traffic must continue to enter through Naumi, not directly through
New API or Naumi Router. Provisioning creates only an internal service token
and does not issue a paid image request.

## Verification

```bash
make fmt
make test
make vet
```

The isolated New API contract and Naumi canvas chain can be replayed against a
fresh local New API data volume without paid upstream calls:

```bash
set -a && source .env && set +a
RUN_NAUMI_SMOKE=1 scripts/new-api-chain-smoke.sh
```

The smoke harness deliberately refuses to initialize or mutate an existing New
API instance.

## Documentation

- [Durable image routing and operations](docs/IMAGE_GATEWAY_OPERATIONS.md)
- [Architecture](docs/ARCHITECTURE.md)
- [MVP acceptance](docs/MVP.md)
- [APIMart research and first-test record](docs/research/2026-09-19-apimart.md)
- [APIMart 1K benchmark summary](docs/research/2026-09-19-apimart-1k-benchmark.md)
- [New API and Naumi full-chain smoke](docs/research/2026-09-19-new-api-chain-smoke.md)
- [Isolated server staging record](docs/research/2026-09-19-server-staging.md)
- [Server 1K smoke and outbound connectivity blocker](docs/research/2026-09-19-server-paid-smoke.md)
- [JD product-detail style target](docs/research/2026-09-19-jd-detail-style.md)
- [Decision 0001: separate New API control plane](docs/decisions/0001-new-api-control-plane.md)
- [Decision 0002: rejected direct-Naumi alternative](docs/decisions/0002-naumi-direct-control-plane.md)
