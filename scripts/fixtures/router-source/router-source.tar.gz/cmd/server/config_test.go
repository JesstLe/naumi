package main

import (
	"github.com/JesstLe/naumi-router/internal/routing"
	"path/filepath"
	"testing"
)

func TestBundledRouteConfigurationsRemainLoadable(t *testing.T) {
	files, err := filepath.Glob("../../config/routes*.json")
	if err != nil || len(files) == 0 {
		t.Fatal("no bundled routing configuration")
	}
	for _, file := range files {
		t.Run(filepath.Base(file), func(t *testing.T) {
			config, err := loadConfig(file)
			if err != nil {
				t.Fatal(err)
			}
			if _, err = routing.NewEngine(config.Routes); err != nil {
				t.Fatal(err)
			}
		})
	}
}
