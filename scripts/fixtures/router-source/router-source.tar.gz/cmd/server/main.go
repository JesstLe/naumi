package main

import (
	"encoding/json"
	"errors"
	"fmt"
	"log/slog"
	"net/http"
	"os"
	"strings"
	"time"

	"github.com/JesstLe/naumi-router/internal/api"
	"github.com/JesstLe/naumi-router/internal/configuration"
	"github.com/JesstLe/naumi-router/internal/execution"
	"github.com/JesstLe/naumi-router/internal/provider"
	"github.com/JesstLe/naumi-router/internal/routing"
)

var buildVersion = "development"

func main() {
	token := os.Getenv("NAUMI_ROUTER_TOKEN")
	if len(token) < 24 {
		slog.Error("NAUMI_ROUTER_TOKEN must contain at least 24 characters")
		os.Exit(1)
	}

	configPath := envOrDefault("NAUMI_ROUTES_CONFIG", "config/routes.example.json")
	config, err := loadConfig(configPath)
	if err != nil {
		slog.Error("failed to load route config", "error", err)
		os.Exit(1)
	}
	engine, err := routing.NewEngine(config.Routes)
	if err != nil {
		slog.Error("invalid route config", "error", err)
		os.Exit(1)
	}

	providers := provider.Registry{
		"mock": &provider.Mock{},
	}
	if apimartKey := os.Getenv("APIMART_KEY"); apimartKey != "" {
		providers["apimart"] = provider.NewAPIMart(apimartKey)
	}
	if falKey := os.Getenv("FAL_KEY"); falKey != "" {
		providers["fal"] = provider.NewFal(falKey)
	}
	for _, configured := range config.Providers {
		if configured.ID == "" || providers[configured.ID] != nil || configured.Protocol != "openai-images" || configured.BaseURLEnv == "" || configured.APIKeyEnv == "" {
			slog.Error("invalid provider configuration")
			os.Exit(1)
		}
		endpoint, key := os.Getenv(configured.BaseURLEnv), os.Getenv(configured.APIKeyEnv)
		if endpoint == "" || key == "" {
			slog.Error("configured provider environment is missing", "provider", configured.ID)
			os.Exit(1)
		}
		providers[configured.ID] = &provider.OpenAIImages{BaseURL: endpoint, Key: key}
	}
	if err := validateProviderRegistry(config.Routes, providers); err != nil {
		slog.Error("route provider is not configured", "error", err)
		os.Exit(1)
	}

	store, err := execution.Open(envOrDefault("NAUMI_STATE_DIR", "data/router"))
	if err != nil {
		slog.Error("execution store unavailable")
		os.Exit(1)
	}
	defer store.Close()
	server := &api.Server{
		Version:            buildVersion,
		Store:              store,
		RequireOperationID: !strings.EqualFold(os.Getenv("NAUMI_ALLOW_LEGACY_REQUESTS"), "true"),
		Token:              token,
		ExposeRouteDebug:   strings.EqualFold(os.Getenv("NAUMI_EXPOSE_ROUTE_DEBUG"), "true"),
		Engine:             engine,
		Providers:          providers,
	}

	if managementToken := os.Getenv("NAUMI_ROUTER_MANAGEMENT_TOKEN"); managementToken != "" {
		secret := os.Getenv("MODEL_CONFIG_ENVELOPE_SECRET")
		if len(managementToken) < 32 || len(secret) < 32 || managementToken == token || secret == managementToken || secret == token {
			slog.Error("invalid independent model configuration credentials")
			os.Exit(1)
		}
		options := configuration.Options{EnvelopeSecret: secret}
		capacity, capacityErr := configuration.NewCapacityClient(os.Getenv("NAUMI_MODEL_CAPACITY_URL"), managementToken)
		if capacityErr != nil {
			slog.Error("private shared model capacity connection unavailable")
			os.Exit(1)
		}
		options.CapacityAcquire = capacity
		for _, origin := range strings.Split(os.Getenv("MODEL_CONFIG_TRUSTED_ORIGINS"), ",") {
			if value := strings.TrimSpace(origin); value != "" {
				options.TrustedOrigins = append(options.TrustedOrigins, value)
			}
		}
		manager, err := configuration.Open(envOrDefault("NAUMI_CONFIG_STATE_DIR", envOrDefault("NAUMI_STATE_DIR", "data/router")+"/configurations"), options)
		if err != nil {
			slog.Error("model configuration state unavailable")
			os.Exit(1)
		}
		defer manager.Close()
		if manager.BindLegacy(engine, providers) != nil {
			slog.Error("model configuration account budgets unavailable")
			os.Exit(1)
		}
		server.Configurations, server.ManagementToken = manager, managementToken
		handler, err := server.ManagementHandler()
		if err != nil {
			slog.Error("model management unavailable")
			os.Exit(1)
		}
		managementServer := &http.Server{Addr: envOrDefault("NAUMI_ROUTER_MANAGEMENT_ADDR", "127.0.0.1:8082"), Handler: handler, ReadHeaderTimeout: 5 * time.Second, ReadTimeout: 15 * time.Second, WriteTimeout: 30 * time.Second, IdleTimeout: 30 * time.Second, MaxHeaderBytes: 16 << 10}
		go func() {
			if err := managementServer.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
				slog.Error("model management listener unavailable")
				os.Exit(1)
			}
		}()
	}

	httpServer := &http.Server{
		Addr:              envOrDefault("NAUMI_HTTP_ADDR", ":8081"),
		Handler:           server.Handler(),
		ReadHeaderTimeout: 5 * time.Second,
		ReadTimeout:       15 * time.Second,
		WriteTimeout:      130 * time.Second,
		IdleTimeout:       60 * time.Second,
		MaxHeaderBytes:    32 << 10,
	}

	slog.Info("Naumi Router listening", "addr", httpServer.Addr)
	if err := httpServer.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
		slog.Error("server stopped", "error", err)
		os.Exit(1)
	}
}

func validateProviderRegistry(routes []routing.Route, providers provider.Registry) error {
	for _, route := range routes {
		if !route.Enabled {
			continue
		}
		if providers[route.Provider] == nil {
			return fmt.Errorf("route %q requires provider %q", route.ID, route.Provider)
		}
	}
	return nil
}

func loadConfig(path string) (routing.Config, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return routing.Config{}, fmt.Errorf("read %s: %w", path, err)
	}
	var config routing.Config
	decoder := json.NewDecoder(strings.NewReader(string(data)))
	decoder.DisallowUnknownFields()
	if err := decoder.Decode(&config); err != nil {
		return routing.Config{}, fmt.Errorf("decode %s: %w", path, err)
	}
	return config, nil
}

func envOrDefault(name, fallback string) string {
	if value := os.Getenv(name); value != "" {
		return value
	}
	return fallback
}
