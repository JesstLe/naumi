#!/usr/bin/env bash

set -euo pipefail

version="${1:-v1.0.0-rc.38}"
destination="${2:-}"

if [[ ! "$version" =~ ^v[0-9A-Za-z._-]+$ ]]; then
  echo "invalid New API release version" >&2
  exit 1
fi
if [[ -z "$destination" ]]; then
  echo "usage: $0 VERSION DESTINATION" >&2
  exit 1
fi

asset="new-api-$version"
release_base="https://github.com/QuantumNous/new-api/releases/download/$version"
work_dir="$(mktemp -d)"
cleanup() {
  find "$work_dir" -depth -delete 2>/dev/null || true
}
trap cleanup EXIT INT TERM

curl --fail --silent --show-error --location \
  --connect-timeout 15 --max-time 600 --retry 3 --retry-all-errors \
  --output "$work_dir/checksums-linux.txt" \
  "$release_base/checksums-linux.txt"
curl --fail --silent --show-error --location \
  --connect-timeout 15 --max-time 600 --retry 3 --retry-all-errors \
  --output "$work_dir/$asset" \
  "$release_base/$asset"

expected="$(awk -v asset="$asset" '$2 == asset || $2 == "*" asset {print $1}' "$work_dir/checksums-linux.txt")"
if [[ ! "$expected" =~ ^[0-9a-fA-F]{64}$ ]]; then
  echo "release checksum for $asset was not found" >&2
  exit 1
fi
actual="$(sha256sum "$work_dir/$asset" | awk '{print $1}')"
if [[ "$actual" != "$expected" ]]; then
  echo "New API checksum verification failed" >&2
  exit 1
fi

install -m 0755 "$work_dir/$asset" "$destination"
printf 'installed New API %s with sha256 %s\n' "$version" "$actual"
