# Same-server Naumi canvas acceptance

This is a separate Naumi app, PostgreSQL database and media volume. It uses
the real private gateway but does not reuse production user data or change
the existing `naumi-app-1` deployment.

## Runtime

- Directory: `/opt/naumi-gateway/canvas-test`.
- Compose project: `naumi-gateway-canvas-test`.
- App: `http://127.0.0.1:3013` (host network, explicitly loopback-bound).
- Test database: `127.0.0.1:15433`, separate Docker volume.
- Gateway: `http://127.0.0.1:3100/v1`.
- Environment and dedicated test password: `.env`, root-only `0600`.
- Media and account state remain in this project's dedicated volumes.

Access from the workstation with an authenticated SSH tunnel forwarding a
local port to server `127.0.0.1:3013`. No public Nginx route is installed.

The premium alias is only temporarily added through `CANVAS_MODELS` to test
gateway rejection and credit refund. Recreating the app with the default
Compose configuration removes that unsupported tier from the model picker.

## Acceptance

`scripts/canvas-server-acceptance.mjs` registers a dedicated user, uploads a
reference, submits one 1K standard edit, verifies storage/parent/batch linkage
and six-credit settlement, then submits a premium request that must be rejected
before provider submission and refunded. It creates a one-shot marker before
doing any work and refuses to reuse an existing output directory. Inspect jobs
and receipts before restarting any failed run; never blindly replay a paid test.

`scripts/canvas-server-browser.mjs` logs into that dedicated account via the
tunnel, checks the saved canvas and three supported aliases, switches the
model selector and reloads, and captures a screenshot. It submits no generation.

## Stop and rollback

Run `docker compose --env-file .env -f compose.yml stop` in the test directory.
This stops only the test app and DB and preserves all test volumes. Start the
same pinned version with `up -d --pull never`. Production Naumi does not need
rollback because it has not been modified. Restoring an earlier test image is
possible by changing only this project's pinned image, retaining its DB/media.

The shared gateway's code/proxy rollback is documented in `README.md`.
