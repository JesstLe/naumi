# Isolated server deployment

This deployment keeps the Naumi gateway separate from the legacy
`/opt/api-relay` installation:

- release files: `/opt/naumi-gateway/releases/<release>`;
- stable symlink: `/opt/naumi-gateway/current`;
- secrets: `/etc/naumi-gateway/*.env`, mode `0600` or `0640`;
- New API state: `/var/lib/naumi-gateway/new-api`;
- New API process socket: port `3100`, isolated by systemd so that only
  localhost traffic is allowed;
- Naumi Router listener: `127.0.0.1:8081`.

The upstream New API binary accepts a port but not a bind address, so its
socket appears as `*:3100`. The unit applies `IPAddressDeny=any` and
`IPAddressAllow=localhost`; verify both the effective unit properties and an
external connection failure after every deployment. Do not rely on the socket
listing alone.

The release bundle must contain the Router binary, a checksum-verified official
New API binary, the APIMart route configuration, the two systemd units, and the
provisioning script. `install-release.sh` backs up an existing SQLite database,
switches the release symlink, starts both services, and restores the previous
symlink when a health check fails.

The first installation requires two server-side environment files:

```text
# /etc/naumi-gateway/router.env
NAUMI_HTTP_ADDR=127.0.0.1:8081
NAUMI_ROUTES_CONFIG=/opt/naumi-gateway/current/config/routes.apimart.server.json
NAUMI_EXPOSE_ROUTE_DEBUG=false
NAUMI_ROUTER_TOKEN=<independent random service token>
APIMART_KEY=<server-side provider key>

# /etc/naumi-gateway/new-api.env
SESSION_SECRET=<independent random session secret>
SQLITE_PATH=/var/lib/naumi-gateway/new-api/one-api.db
TZ=Asia/Shanghai
```

After the first healthy start, run `scripts/provision-new-api.sh` once with
`NAUMI_ROUTER_TOKEN` loaded from the server environment. It initializes New API
in self-use mode, disables registration, creates the Router channel and an
internal Naumi token, and writes the generated credentials to a mode-0600 file.
It does not submit a paid image request.

## Optional private Mihomo egress

The server has the official Mihomo `v1.19.31` Linux amd64-v1 binary at
`/opt/naumi-gateway/tools/mihomo-v1.19.31`. The downloaded gzip was verified
against the GitHub release asset digest:
`d4304c546c3cddcb6fafd4b4fddb0ba1a95ffa36606fda56d75db2e59ad24114`.

`naumi-mihomo.service` is enabled and active. With the user's authorization,
the workstation's currently selected node was imported as a private snapshot.
APIMart's authenticated model-list endpoint returned HTTP 200 through the proxy.
The listener is loopback port `17890`;
there is no public controller or TUN mode. A separate unprivileged user and
192 MiB memory limit constrain the service.

Supply a provider-format YAML file containing `proxies` at
`/var/lib/naumi-mihomo/nodes.yaml`, owned by `naumi-mihomo` with mode `0600`.
The service uses `/etc/naumi-mihomo/config.yaml` (root-owned, group-readable
only). Do not commit node credentials or subscription URLs.

Router's systemd drop-in `router-proxy.conf` enables `HTTPS_PROXY` only for that
service. The API client uses Go's default HTTP transport. The APIMart media
client explicitly ignores environment proxies and connects directly to a
validated public IP, preserving its SSRF and redirect checks. The current
`getapib.org` CDN is reachable directly from the server. A future CDN that is
not reachable directly will fail delivery rather than bypass these checks.

The imported node is a snapshot, not an automatically refreshed subscription.
Refresh it from the authorized local configuration when credentials or node
endpoints change. It does not depend on the workstation remaining online.

The running Router release is
`/opt/naumi-gateway/releases/d91c31b-20260919-proxy`. The initial release remains
available for rollback. To roll back both code and proxy behavior, remove only
`/etc/systemd/system/naumi-router.service.d/proxy.conf`, reload systemd, and run
the installer against the previous release. That restores the former direct
network path, which was unable to reach APIMart from this server.

References: [official release](https://github.com/MetaCubeX/mihomo/releases/tag/v1.19.31),
[general configuration](https://wiki.metacubex.one/en/config/general/),
[file proxy providers](https://wiki.metacubex.one/en/config/proxy-providers/).
