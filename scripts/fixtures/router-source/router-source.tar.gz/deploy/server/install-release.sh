#!/usr/bin/env bash

set -euo pipefail

release_dir="${1:-}"
case "$release_dir" in
  /opt/naumi-gateway/releases/*) ;;
  *)
    echo "release directory must be under /opt/naumi-gateway/releases" >&2
    exit 1
    ;;
esac

for required in \
  "$release_dir/bin/naumi-router" \
  "$release_dir/bin/new-api" \
  "$release_dir/config/routes.apimart.server.json" \
  "$release_dir/deploy/server/naumi-router.service" \
  "$release_dir/deploy/server/naumi-new-api.service"; do
  if [[ ! -f "$required" ]]; then
    echo "missing release file: $required" >&2
    exit 1
  fi
done

if [[ "$(id -u)" -ne 0 ]]; then
  echo "install-release.sh must run as root" >&2
  exit 1
fi

for dependency in jq sqlite3 curl systemctl sha256sum runuser; do
  command -v "$dependency" >/dev/null || { echo "missing deployment dependency: $dependency" >&2; exit 1; }
done

if ! id naumi-gateway >/dev/null 2>&1; then
  useradd --system --home-dir /var/lib/naumi-gateway --create-home \
    --shell /usr/sbin/nologin naumi-gateway
fi

install -d -m 0755 /opt/naumi-gateway /opt/naumi-gateway/releases
install -d -o naumi-gateway -g naumi-gateway -m 0700 \
  /var/lib/naumi-gateway/new-api \
  /var/lib/naumi-gateway/router \
  /var/log/naumi-gateway/new-api
install -d -o root -g naumi-gateway -m 0750 /etc/naumi-gateway

for env_file in /etc/naumi-gateway/router.env /etc/naumi-gateway/new-api.env; do
  if [[ ! -s "$env_file" ]]; then
    echo "missing required environment file: $env_file" >&2
    exit 1
  fi
  mode="$(stat -c '%a' "$env_file")"
  if [[ "$mode" != "600" && "$mode" != "640" && "$mode" != "400" && "$mode" != "440" ]]; then
    echo "$env_file must not be readable by other users" >&2
    exit 1
  fi
done

chown -R root:root "$release_dir"
find "$release_dir" -type d -exec chmod 0755 {} +
chmod 0755 "$release_dir/bin/naumi-router" "$release_dir/bin/new-api"
chmod 0644 "$release_dir/config/routes.apimart.server.json"

backup_dir="/opt/naumi-gateway/backups/$(date -u +%Y%m%dT%H%M%SZ)"
install -d -m 0700 "$backup_dir"
cp -a /etc/naumi-gateway "$backup_dir/environment"
for unit in naumi-router naumi-new-api; do
  if [[ -f "/etc/systemd/system/$unit.service" ]]; then
    cp -p "/etc/systemd/system/$unit.service" "$backup_dir/$unit.service"
  fi
done
database="/var/lib/naumi-gateway/new-api/one-api.db"
if [[ -s "$database" ]]; then
  install -d -m 0700 "$backup_dir"
  sqlite3 "$database" ".backup '$backup_dir/one-api.db'"
  sha256sum "$backup_dir/one-api.db" >"$backup_dir/SHA256SUMS"
fi

previous=""
new_router_started=0
model_management_enabled=0
if grep -Eq '^NAUMI_ROUTER_MANAGEMENT_TOKEN=.+$' /etc/naumi-gateway/router.env; then
  model_management_enabled=1
fi
if [[ -L /opt/naumi-gateway/current ]]; then
  previous="$(readlink -f /opt/naumi-gateway/current)"
fi

# Validate/copy configuration before any downtime or symlink switch.
if [[ -n "$previous" && -d "$previous/config" ]]; then
  cp -a "$previous/config" "$backup_dir/previous-config"
  cp -a "$previous/config/." "$release_dir/config/"
fi
for routes_file in "$release_dir"/config/routes*.json; do
  jq -e '.routes|type=="array"' "$routes_file" >/dev/null
  jq '.routes |= map(if .provider=="apimart" and .upstream_model=="gpt-image-2.5-ext" and .supports_edit==true and (has("preserves_identity")|not) then .+{preserves_identity:true,max_reference_images:15} else . end)' "$routes_file" > "$routes_file.next"
  mv "$routes_file.next" "$routes_file"
  # The caller can use umask 077. jq+mv creates a new inode, so establish the
  # intended read permission after the final rewrite, before switching services.
  chmod 0644 "$routes_file"
  runuser -u naumi-gateway -- test -r "$routes_file"
done
touch "$release_dir/config/execution-ledger-v1"
touch "$release_dir/config/model-config-v1"

# Retained configured digests cannot be read by a legacy-only binary. Keep the
# caller paused until a compatible fixed release/recovery service is restored.
router_rollback_compatible() {
  [[ "$new_router_started" == 0 ]] ||
    [[ -f "$previous/config/execution-ledger-v1" &&
       ( "$model_management_enabled" == 0 || -f "$previous/config/model-config-v1" ) ]]
}

rollback() {
  systemctl stop naumi-new-api.service naumi-router.service || true
  for unit in naumi-router naumi-new-api; do
    if [[ -f "$backup_dir/$unit.service" ]]; then
      install -m 0644 "$backup_dir/$unit.service" "/etc/systemd/system/$unit.service"
    else
      rm -f "/etc/systemd/system/$unit.service"
    fi
  done
  systemctl daemon-reload
  if [[ -n "$previous" && -d "$previous" ]]; then
    ln -sfn "$previous" /opt/naumi-gateway/current.rollback
    mv -Tf /opt/naumi-gateway/current.rollback /opt/naumi-gateway/current
    # An old router ignores the paid ledger and could resubmit recovered jobs.
    # Keep both isolated gateway services stopped until a compatible release
    # is restored. Never restore an older ledger over newly accepted work.
    if router_rollback_compatible; then
      systemctl restart naumi-router.service naumi-new-api.service || true
    else
      echo "rollback preserved paid/configuration ledgers; incompatible old gateway stays stopped" >&2
    fi
  else
    unlink /opt/naumi-gateway/current 2>/dev/null || true
    systemctl stop naumi-new-api.service naumi-router.service 2>/dev/null || true
  fi
}
trap rollback ERR

# Stop the caller first; take a cold, coherent snapshot of the ledger and assets.
systemctl stop naumi-new-api.service naumi-router.service
cp -a /var/lib/naumi-gateway/router "$backup_dir/router-state"

ln -sfn "$release_dir" /opt/naumi-gateway/current.next
mv -Tf /opt/naumi-gateway/current.next /opt/naumi-gateway/current
install -m 0644 "$release_dir/deploy/server/naumi-router.service" /etc/systemd/system/naumi-router.service
install -m 0644 "$release_dir/deploy/server/naumi-new-api.service" /etc/systemd/system/naumi-new-api.service

systemctl daemon-reload
systemctl enable naumi-router.service naumi-new-api.service >/dev/null
new_router_started=1
systemctl restart naumi-router.service

for _ in $(seq 1 30); do
  if curl --fail --silent --show-error http://127.0.0.1:8081/readyz >/dev/null 2>&1; then
    break
  fi
  sleep 1
done
curl --fail --silent --show-error http://127.0.0.1:8081/readyz >/dev/null

systemctl restart naumi-new-api.service
for _ in $(seq 1 60); do
  if curl --fail --silent --show-error http://127.0.0.1:3100/api/setup >/dev/null 2>&1; then
    break
  fi
  sleep 1
done
curl --fail --silent --show-error http://127.0.0.1:3100/api/setup >/dev/null

trap - ERR
printf 'installed release %s\n' "$release_dir"
