#!/usr/bin/env bash
set -Eeuo pipefail
fixture=$(mktemp -d /tmp/naumi-model-rollback-XXXXXX)
case "$fixture" in /tmp/naumi-model-rollback-*) ;; *) exit 1;; esac
trap 'rm -rf -- "$fixture"' EXIT
installer=$(cd "$(dirname "$0")/.." && pwd)/deploy/server/install-release.sh
awk '/^router_rollback_compatible\(\)/ {active=1} active {print} active && /^}/ {exit}' "$installer" > "$fixture/policy.sh"
source "$fixture/policy.sh"
declare -F router_rollback_compatible >/dev/null
previous="$fixture/old"
mkdir -p "$previous/config"
new_router_started=0
model_management_enabled=1
router_rollback_compatible
new_router_started=1
if router_rollback_compatible; then echo 'old gateway lacks paid ledger' >&2; exit 1; fi
touch "$previous/config/execution-ledger-v1"
if router_rollback_compatible; then echo 'legacy gateway cannot recover configured digests' >&2; exit 1; fi
model_management_enabled=0
router_rollback_compatible
model_management_enabled=1
touch "$previous/config/model-config-v1"
router_rollback_compatible
echo MODEL_DIGEST_ROLLBACK_COMPATIBILITY=PASS
