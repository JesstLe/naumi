#!/usr/bin/env bash

set -euo pipefail

new_api_base_url="${NEW_API_BASE_URL:-http://127.0.0.1:3100}"
router_upstream_base_url="${ROUTER_UPSTREAM_BASE_URL:-http://host.docker.internal:8081}"
reference_image="${REFERENCE_IMAGE:-/Users/lv/Downloads/08.jpg.png}"
run_naumi_smoke="${RUN_NAUMI_SMOKE:-0}"
naumi_dir="${NAUMI_DIR:-/Users/lv/Workspace/naumi}"
naumi_port="${NAUMI_SMOKE_PORT:-3310}"
models="naumi-image-auto,naumi-image-economy,naumi-image-standard,naumi-image-premium"
operation_suffix="$(date +%s)-$$"

for command_name in curl jq openssl; do
  if ! command -v "$command_name" >/dev/null 2>&1; then
    echo "missing required command: $command_name" >&2
    exit 1
  fi
done

if [[ -z "${NAUMI_ROUTER_TOKEN:-}" ]] || [[ ${#NAUMI_ROUTER_TOKEN} -lt 24 ]]; then
  echo "NAUMI_ROUTER_TOKEN must be set and contain at least 24 characters" >&2
  exit 1
fi
if [[ ! -f "$reference_image" ]]; then
  echo "reference image does not exist: $reference_image" >&2
  exit 1
fi

cookie_jar="$(mktemp)"
naumi_app_pid=""
postgres_container=""

cleanup() {
  if [[ -n "$naumi_app_pid" ]] && kill -0 "$naumi_app_pid" >/dev/null 2>&1; then
    kill "$naumi_app_pid" >/dev/null 2>&1 || true
    wait "$naumi_app_pid" 2>/dev/null || true
  fi
  if [[ -n "$postgres_container" ]] && docker container inspect "$postgres_container" >/dev/null 2>&1; then
    docker stop "$postgres_container" >/dev/null 2>&1 || true
    docker container rm "$postgres_container" >/dev/null 2>&1 || true
  fi
  find "$cookie_jar" -type f -delete 2>/dev/null || true
}
trap cleanup EXIT INT TERM

setup_state="$(curl -fsS "$new_api_base_url/api/setup")"
if [[ "$(jq -r '.success' <<<"$setup_state")" != "true" ]]; then
  echo "unable to read New API setup state" >&2
  exit 1
fi
if [[ "$(jq -r '.data.status' <<<"$setup_state")" == "true" ]]; then
  echo "refusing to mutate an initialized New API instance; use a fresh smoke-test data volume" >&2
  exit 1
fi

admin_password="$(openssl rand -base64 24 | tr -d '/+=')"
setup_payload="$(jq -n \
  --arg username "naumiadmin" \
  --arg password "$admin_password" \
  '{username:$username,password:$password,confirmPassword:$password,SelfUseModeEnabled:true,DemoSiteEnabled:false}')"
setup_response="$(curl -fsS -X POST "$new_api_base_url/api/setup" \
  -H 'Content-Type: application/json' \
  --data "$setup_payload")"
if [[ "$(jq -r '.success' <<<"$setup_response")" != "true" ]]; then
  jq '{stage:"setup",success,message}' <<<"$setup_response" >&2
  exit 1
fi

login_payload="$(jq -n \
  --arg username "naumiadmin" \
  --arg password "$admin_password" \
  '{username:$username,password:$password}')"
login_response="$(curl -fsS -c "$cookie_jar" -b "$cookie_jar" \
  -X POST "$new_api_base_url/api/user/login" \
  -H 'Content-Type: application/json' \
  --data "$login_payload")"
if [[ "$(jq -r '.success' <<<"$login_response")" != "true" ]]; then
  jq '{stage:"login",success,message}' <<<"$login_response" >&2
  exit 1
fi
admin_id="$(jq -r '.data.user.id // .data.id' <<<"$login_response")"
admin_access_token="$(jq -r '.data.access_token // empty' <<<"$login_response")"
admin_auth_args=()
if [[ -n "$admin_access_token" ]]; then
  admin_auth_args=(-H "Authorization: Bearer $admin_access_token")
fi

channel_payload="$(jq -n \
  --arg key "$NAUMI_ROUTER_TOKEN" \
  --arg base_url "$router_upstream_base_url" \
  --arg models "$models" \
  '{mode:"single",channel:{type:1,key:$key,status:1,name:"Naumi Router Local Smoke",weight:100,base_url:$base_url,models:$models,group:"default",priority:0,auto_ban:0,other:""}}')"
channel_response="$(curl -sS -c "$cookie_jar" -b "$cookie_jar" \
  -X POST "$new_api_base_url/api/channel/" \
  "${admin_auth_args[@]}" \
  -H "New-Api-User: $admin_id" \
  -H 'Content-Type: application/json' \
  --data "$channel_payload")"
if [[ "$(jq -r '.success' <<<"$channel_response")" != "true" ]]; then
  jq '{stage:"channel",success,message}' <<<"$channel_response" >&2
  exit 1
fi

token_payload="$(jq -n \
  --arg models "$models" \
  '{name:"Naumi Internal Smoke",expired_time:-1,unlimited_quota:true,model_limits_enabled:true,model_limits:$models,group:"default"}')"
token_response="$(curl -sS -c "$cookie_jar" -b "$cookie_jar" \
  -X POST "$new_api_base_url/api/token/" \
  "${admin_auth_args[@]}" \
  -H "New-Api-User: $admin_id" \
  -H 'Content-Type: application/json' \
  --data "$token_payload")"
if [[ "$(jq -r '.success' <<<"$token_response")" != "true" ]]; then
  jq '{stage:"token",success,message}' <<<"$token_response" >&2
  exit 1
fi

token_list="$(curl -sS -c "$cookie_jar" -b "$cookie_jar" \
  "$new_api_base_url/api/token/?p=0&page_size=20" \
  "${admin_auth_args[@]}" \
  -H "New-Api-User: $admin_id")"
token_id="$(jq -r '.data.items[] | select(.name == "Naumi Internal Smoke") | .id' <<<"$token_list" | head -n 1)"
if [[ -z "$token_id" || "$token_id" == "null" ]]; then
  echo "New API token was created but could not be retrieved" >&2
  exit 1
fi
key_response="$(curl -sS -c "$cookie_jar" -b "$cookie_jar" \
  -X POST "$new_api_base_url/api/token/$token_id/key" \
  "${admin_auth_args[@]}" \
  -H "New-Api-User: $admin_id")"
raw_key="$(jq -r '.data.key' <<<"$key_response")"
if [[ -z "$raw_key" || "$raw_key" == "null" ]]; then
  echo "New API returned an empty internal token" >&2
  exit 1
fi
new_api_key="sk-$raw_key"

model_response="$(curl -fsS "$new_api_base_url/v1/models" \
  -H "Authorization: Bearer $new_api_key")"
generation_response="$(curl -fsS "$new_api_base_url/v1/images/generations" \
  -H "Authorization: Bearer $new_api_key" \
  -H 'Content-Type: application/json' \
  -d "$(jq -nc --arg id "chain-$operation_suffix:generate" '{model:"naumi-image-standard",prompt:"A clean product photo on a white background",size:"1024x1024",quality:"standard",response_format:"b64_json",n:1,extra_fields:{naumi:{operation_id:$id}}}')")"
edit_response="$(curl -fsS "$new_api_base_url/v1/images/edits" \
  -H "Authorization: Bearer $new_api_key" \
  -F 'model=naumi-image-standard' \
  -F 'prompt=Keep the package identity and place it on a pale green commercial studio background' \
  -F 'size=1024x1024' \
  -F 'quality=standard' \
  -F 'n=1' \
  -F "extra_fields={\"naumi\":{\"operation_id\":\"chain-$operation_suffix:edit\"}}" \
  -F "image=@$reference_image;type=image/png")"

for response_name in generation_response edit_response; do
  response_value="${!response_name}"
  if [[ "$(jq -r '.data | length' <<<"$response_value")" != "1" ]] || \
     [[ "$(jq -r '.data[0].b64_json | type' <<<"$response_value")" != "string" ]]; then
    jq --arg stage "$response_name" '{stage:$stage,error,data}' <<<"$response_value" >&2
    exit 1
  fi
done

jq -n \
  --argjson models "$model_response" \
  --argjson generation "$generation_response" \
  --argjson edit "$edit_response" \
  '{status:"PASS",layer:"new-api-to-router",models:[$models.data[].id]|map(select(startswith("naumi-image-"))),generation:{count:($generation.data|length),b64_chars:($generation.data[0].b64_json|length)},edit:{count:($edit.data|length),b64_chars:($edit.data[0].b64_json|length)}}'

if [[ "$run_naumi_smoke" != "1" ]]; then
  exit 0
fi

for command_name in docker node; do
  if ! command -v "$command_name" >/dev/null 2>&1; then
    echo "missing required command for Naumi smoke: $command_name" >&2
    exit 1
  fi
done
if [[ ! -x "$naumi_dir/node_modules/.bin/next" ]]; then
  echo "Naumi dependencies are not installed; run npm ci in $naumi_dir" >&2
  exit 1
fi
if lsof -nP -iTCP:"$naumi_port" -sTCP:LISTEN >/dev/null 2>&1; then
  echo "Naumi smoke port is already in use: $naumi_port" >&2
  exit 1
fi

postgres_container="naumi-chain-smoke-$RANDOM-$$"
postgres_password="$(openssl rand -hex 24)"
docker run -d --name "$postgres_container" \
  -e POSTGRES_USER=fixture \
  -e "POSTGRES_PASSWORD=$postgres_password" \
  -e POSTGRES_DB=fixture \
  -p 127.0.0.1::5432 \
  --tmpfs /var/lib/postgresql/data \
  postgres:16-alpine >/dev/null

for _ in {1..60}; do
  if docker exec "$postgres_container" pg_isready -U fixture -d fixture >/dev/null 2>&1; then
    break
  fi
  sleep 0.5
done
if ! docker exec "$postgres_container" pg_isready -U fixture -d fixture >/dev/null 2>&1; then
  echo "temporary PostgreSQL did not become ready" >&2
  exit 1
fi
postgres_port="$(docker port "$postgres_container" 5432/tcp | awk -F: 'NR==1 {print $NF}')"
database_url="postgres://fixture:$postgres_password@127.0.0.1:$postgres_port/fixture?sslmode=disable"

naumi_output_dir="$naumi_dir/output/new-api-router-smoke"
mkdir -p "$naumi_output_dir/media"
account_password="Naumi-Smoke-$(openssl rand -hex 12)!"
settings_secret="$(openssl rand -hex 32)"

(
  cd "$naumi_dir"
  env \
    DATABASE_URL="$database_url" \
    SETTINGS_SECRET="$settings_secret" \
    ADMIN_EMAIL="canvas-new-api-smoke@local.test" \
    NAUMI_EDITION=cloud \
    NAUMI_MULTI_USER=1 \
    NAUMI_PUBLIC_COMMERCE=0 \
    MEDIA_DIR="$naumi_output_dir/media" \
    STORAGE_DRIVER=local \
    NEXT_PUBLIC_SUPABASE_URL= \
    NEXT_PUBLIC_SUPABASE_ANON_KEY= \
    SMTP_HOST= \
    OPENAI_API_KEY="$new_api_key" \
    OPENAI_BASE_URL="$new_api_base_url/v1" \
    OPENAI_IMAGE_MODEL=naumi-image-standard \
    OPENAI_IMAGE_MODELS="$models" \
    NEXT_TELEMETRY_DISABLED=1 \
    node node_modules/next/dist/bin/next dev -p "$naumi_port"
) >"$naumi_output_dir/next.log" 2>&1 &
naumi_app_pid=$!

naumi_base_url="http://127.0.0.1:$naumi_port"
for _ in {1..180}; do
  if health_response="$(curl -fsS "$naumi_base_url/api/health" 2>/dev/null)" && \
     [[ "$(jq -r '.db.ok' <<<"$health_response")" == "true" ]]; then
    break
  fi
  sleep 0.5
done
if ! health_response="$(curl -fsS "$naumi_base_url/api/health" 2>/dev/null)" || \
   [[ "$(jq -r '.db.ok' <<<"$health_response")" != "true" ]]; then
  echo "Naumi did not become healthy; see $naumi_output_dir/next.log" >&2
  exit 1
fi

(
  cd "$naumi_dir"
  env \
    CANVAS_BASE_URL="$naumi_base_url" \
    CANVAS_SMOKE_EMAIL="canvas-new-api-smoke@local.test" \
    CANVAS_SMOKE_PASSWORD="$account_password" \
    CANVAS_SMOKE_REGISTER=1 \
    CANVAS_SMOKE_COUNT=1 \
    CANVAS_SMOKE_EXPECTED_COUNT=1 \
    node scripts/canvas-generation-smoke.mjs
)

(
  cd "$naumi_dir"
  env \
    CANVAS_BASE_URL="$naumi_base_url" \
    CANVAS_SMOKE_EMAIL="canvas-new-api-smoke@local.test" \
    CANVAS_SMOKE_PASSWORD="$account_password" \
    CANVAS_SMOKE_REGISTER=0 \
    CANVAS_SMOKE_COUNT=1 \
    CANVAS_SMOKE_EXPECTED_COUNT=1 \
    CANVAS_SMOKE_MODEL=naumi-image-economy \
    node scripts/canvas-generation-smoke.mjs
)

jq -n \
  --arg model "$(jq -r '.openai.model' <<<"$health_response")" \
  '{status:"PASS",layer:"naumi-to-new-api-to-router",default_model:$model,switched_model:"naumi-image-economy",paid_upstream_calls:0}'
