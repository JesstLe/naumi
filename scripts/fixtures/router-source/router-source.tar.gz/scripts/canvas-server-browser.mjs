import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
const require = createRequire(path.join(process.env.NAUMI_DIR || '/Users/lv/Workspace/naumi', 'package.json'));
const { chromium, request, expect } = require('@playwright/test');
const base = process.env.CANVAS_BASE_URL || 'http://127.0.0.1:3313';
const output = path.resolve('artifacts/server-canvas-browser');
await mkdir(output, {recursive:true});
assert.ok(process.env.CANVAS_SMOKE_PASSWORD);
const api = await request.newContext({baseURL:base});
let browser;
try {
  const login = await api.post('/api/auth/login',{data:{email:'gateway-canvas-test@local.test',password:process.env.CANVAS_SMOKE_PASSWORD}});
  assert.equal(login.status(),200);
  const config = await (await api.get('/api/config')).json();
  assert.deepEqual(config.imageModels.map(m=>m.id).sort(),['naumi-image-auto','naumi-image-economy','naumi-image-standard']);
  assert.ok(config.imageModels.every(m=>m.supportsEdit));
  const account=await (await api.get('/api/account?email=gateway-canvas-test%40local.test')).json();
  const saved=account.artworks.find(a=>a.id.startsWith('gen-'));
  assert.ok(saved,'The saved generation must exist before opening its canvas');
  browser=await chromium.launch({channel:'chrome',headless:true});
  const context=await browser.newContext({storageState:await api.storageState(),viewport:{width:1440,height:1000}});
  await context.addCookies([{name:'naumi_locale',value:'zh',url:base}]);
  const page=await context.newPage();
  const errors=[];
  page.on('pageerror',e=>errors.push(e.message));
  await page.goto(base+'/canvas?node='+encodeURIComponent(saved.id));
  await page.locator('.react-flow').waitFor({timeout:30000});
  const generated=page.locator('.react-flow__node[data-id^="gen-"]');
  await expect(generated).toHaveCount(1,{timeout:30000});
  await generated.first().click({force:true});
  await page.getByRole('button',{name:/naumi-image-standard/}).click();
  await page.getByRole('button',{name:'naumi-image-economy',exact:true}).click();
  assert.equal(await page.evaluate(()=>localStorage.getItem('naumi:canvas-image-model')),'naumi-image-economy');
  await page.reload();
  await expect(generated).toHaveCount(1,{timeout:30000});
  await generated.first().click({force:true});
  await expect(page.getByRole('button',{name:/naumi-image-economy/})).toBeVisible();
  await page.screenshot({path:path.join(output,'canvas.png'),fullPage:true});
  assert.deepEqual(errors,[]);
  const summary={status:'PASS',models:config.imageModels.map(m=>m.id),generatedNodes:1,selectionPersists:true,pageErrors:errors,additionalPaidRequests:0};
  await writeFile(path.join(output,'summary.json'),JSON.stringify(summary,null,2));
  console.log(JSON.stringify(summary));
} catch (error) {
  const page=browser?.contexts()[0]?.pages()[0];
  if(page) {
    await page.screenshot({path:path.join(output,'failure.png'),fullPage:true}).catch(()=>{});
    await writeFile(path.join(output,'failure.txt'),await page.locator('body').innerText().catch(()=>''));
  }
  throw error;
} finally {await browser?.close();await api.dispose();}
