#!/usr/bin/env bash

set -euo pipefail

base_url="${NEW_API_BASE_URL:-http://127.0.0.1:3100}"
router_base_url="${ROUTER_UPSTREAM_BASE_URL:-http://127.0.0.1:8081}"
credentials_output="${NEW_API_CREDENTIALS_OUTPUT:-/etc/naumi-gateway/credentials.env}"
models="naumi-image-auto,naumi-image-economy,naumi-image-standard,naumi-image-premium"

for command_name in curl jq openssl install; do
  if ! command -v "$command_name" >/dev/null 2>&1; then
    echo "missing required command: $command_name" >&2
    exit 1
  fi
done
if [[ -z "${NAUMI_ROUTER_TOKEN:-}" || ${#NAUMI_ROUTER_TOKEN} -lt 24 ]]; then
  echo "NAUMI_ROUTER_TOKEN must contain at least 24 characters" >&2
  exit 1
fi
if [[ -e "$credentials_output" ]]; then
  echo "refusing to overwrite existing credentials file" >&2
  exit 1
fi

setup_state="$(curl --fail --silent --show-error "$base_url/api/setup")"
if [[ "$(jq -r '.success' <<<"$setup_state")" != "true" ]]; then
  echo "unable to read New API setup state" >&2
  exit 1
fi
if [[ "$(jq -r '.data.status' <<<"$setup_state")" == "true" ]]; then
  echo "refusing to mutate an initialized New API instance" >&2
  exit 1
fi

cookie_jar="$(mktemp)"
temp_credentials="$(mktemp)"
cleanup() {
  find "$cookie_jar" "$temp_credentials" -type f -delete 2>/dev/null || true
}
trap cleanup EXIT INT TERM

admin_username="naumiadmin"
admin_password="$(openssl rand -base64 36 | tr -d '/+=')"
setup_payload="$(jq -n \
  --arg username "$admin_username" \
  --arg password "$admin_password" \
  '{username:$username,password:$password,confirmPassword:$password,SelfUseModeEnabled:true,DemoSiteEnabled:false}')"
setup_response="$(curl --fail --silent --show-error -X POST "$base_url/api/setup" \
  -H 'Content-Type: application/json' \
  --data "$setup_payload")"
if [[ "$(jq -r '.success' <<<"$setup_response")" != "true" ]]; then
  jq '{stage:"setup",success,message}' <<<"$setup_response" >&2
  exit 1
fi

login_payload="$(jq -n \
  --arg username "$admin_username" \
  --arg password "$admin_password" \
  '{username:$username,password:$password}')"
login_response="$(curl --fail --silent --show-error -c "$cookie_jar" -b "$cookie_jar" \
  -X POST "$base_url/api/user/login" \
  -H 'Content-Type: application/json' \
  --data "$login_payload")"
if [[ "$(jq -r '.success' <<<"$login_response")" != "true" ]]; then
  jq '{stage:"login",success,message}' <<<"$login_response" >&2
  exit 1
fi
admin_id="$(jq -r '.data.user.id // .data.id' <<<"$login_response")"
admin_access_token="$(jq -r '.data.access_token // empty' <<<"$login_response")"
admin_auth_args=()
if [[ -n "$admin_access_token" ]]; then
  admin_auth_args=(-H "Authorization: Bearer $admin_access_token")
fi

for option_key in RegisterEnabled PasswordRegisterEnabled; do
  option_payload="$(jq -n --arg key "$option_key" '{key:$key,value:false}')"
  option_response="$(curl --fail --silent --show-error -c "$cookie_jar" -b "$cookie_jar" \
    -X PUT "$base_url/api/option/" \
    "${admin_auth_args[@]}" \
    -H "New-Api-User: $admin_id" \
    -H 'Content-Type: application/json' \
    --data "$option_payload")"
  if [[ "$(jq -r '.success' <<<"$option_response")" != "true" ]]; then
    jq --arg option "$option_key" '{stage:"disable-registration",option:$option,success,message}' <<<"$option_response" >&2
    exit 1
  fi
done

channel_payload="$(jq -n \
  --arg key "$NAUMI_ROUTER_TOKEN" \
  --arg base_url "$router_base_url" \
  --arg models "$models" \
  '{mode:"single",channel:{type:1,key:$key,status:1,name:"Naumi Router",weight:100,base_url:$base_url,models:$models,group:"default",priority:0,auto_ban:0,other:""}}')"
channel_response="$(curl --fail --silent --show-error -c "$cookie_jar" -b "$cookie_jar" \
  -X POST "$base_url/api/channel/" \
  "${admin_auth_args[@]}" \
  -H "New-Api-User: $admin_id" \
  -H 'Content-Type: application/json' \
  --data "$channel_payload")"
if [[ "$(jq -r '.success' <<<"$channel_response")" != "true" ]]; then
  jq '{stage:"channel",success,message}' <<<"$channel_response" >&2
  exit 1
fi

token_payload="$(jq -n \
  --arg models "$models" \
  '{name:"Naumi Internal",expired_time:-1,unlimited_quota:true,model_limits_enabled:true,model_limits:$models,group:"default"}')"
token_response="$(curl --fail --silent --show-error -c "$cookie_jar" -b "$cookie_jar" \
  -X POST "$base_url/api/token/" \
  "${admin_auth_args[@]}" \
  -H "New-Api-User: $admin_id" \
  -H 'Content-Type: application/json' \
  --data "$token_payload")"
if [[ "$(jq -r '.success' <<<"$token_response")" != "true" ]]; then
  jq '{stage:"token",success,message}' <<<"$token_response" >&2
  exit 1
fi

token_list="$(curl --fail --silent --show-error -c "$cookie_jar" -b "$cookie_jar" \
  "$base_url/api/token/?p=0&page_size=20" \
  "${admin_auth_args[@]}" \
  -H "New-Api-User: $admin_id")"
token_id="$(jq -r '.data.items[] | select(.name == "Naumi Internal") | .id' <<<"$token_list" | head -n 1)"
if [[ -z "$token_id" || "$token_id" == "null" ]]; then
  echo "New API token was created but could not be retrieved" >&2
  exit 1
fi
key_response="$(curl --fail --silent --show-error -c "$cookie_jar" -b "$cookie_jar" \
  -X POST "$base_url/api/token/$token_id/key" \
  "${admin_auth_args[@]}" \
  -H "New-Api-User: $admin_id")"
raw_key="$(jq -r '.data.key' <<<"$key_response")"
if [[ -z "$raw_key" || "$raw_key" == "null" ]]; then
  echo "New API returned an empty internal token" >&2
  exit 1
fi
new_api_key="sk-$raw_key"

model_response="$(curl --fail --silent --show-error "$base_url/v1/models" \
  -H "Authorization: Bearer $new_api_key")"
model_count="$(jq '[.data[].id | select(startswith("naumi-image-"))] | length' <<<"$model_response")"
if [[ "$model_count" != "4" ]]; then
  echo "New API did not expose all Naumi image aliases" >&2
  exit 1
fi

umask 077
printf 'NEW_API_ADMIN_USERNAME=%q\n' "$admin_username" >"$temp_credentials"
printf 'NEW_API_ADMIN_PASSWORD=%q\n' "$admin_password" >>"$temp_credentials"
printf 'NEW_API_INTERNAL_TOKEN=%q\n' "$new_api_key" >>"$temp_credentials"
install -m 0600 "$temp_credentials" "$credentials_output"

printf 'provisioned New API with registration disabled and %s internal models\n' "$model_count"
