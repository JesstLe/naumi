#!/usr/bin/env bash
# Validate the shipped full bridge and embeddable locations with real Nginx.
set -Eeuo pipefail
repo=${1:-$(cd "$(dirname "$0")/.." && pwd)}
command -v nginx >/dev/null
workspace=$(mktemp -d /tmp/naumi-model-nginx-XXXXXX)
[[ "$workspace" == /tmp/naumi-model-nginx-* ]]
trap 'rm -rf -- "$workspace"' EXIT
cat > "$workspace/nginx.conf" <<EOF
pid $workspace/nginx.pid;
error_log stderr;
events {}
http {
    access_log off;
    include "$repo/deploy/server/model-management-bridge.conf";
    server {
        listen 127.0.0.1:18089;
        include "$repo/deploy/server/model-management.nginx.example.conf";
    }
}
EOF
nginx -t -p "$workspace/" -c "$workspace/nginx.conf"
echo SHIPPED_MODEL_PRIVATE_NGINX_SYNTAX=PASS
