import assert from 'node:assert/strict';
import { readFile, writeFile, mkdir } from 'node:fs/promises';

const base = process.env.CANVAS_BASE_URL || 'http://127.0.0.1:3013';
const email = process.env.CANVAS_SMOKE_EMAIL || 'gateway-canvas-test@local.test';
const password = process.env.CANVAS_SMOKE_PASSWORD;
const output = process.env.CANVAS_SMOKE_OUTPUT || '/tmp/canvas-acceptance';
assert.ok(password, 'Dedicated test account password is required');
await mkdir(output, { recursive: true });
// Refuse to replay a paid run after either failure or success.
await writeFile(`${output}/started.json`, JSON.stringify({ at: new Date(), base, email }), { flag: 'wx', mode: 0o600 });
let cookie;
async function request(path, init = {}) {
  const headers = new Headers(init.headers);
  if (cookie) headers.set('cookie', cookie);
  const response = await fetch(base + path, { ...init, headers });
  const setCookie = response.headers.get('set-cookie');
  if (setCookie) cookie = setCookie.split(';')[0];
  assert.ok(response.ok, `${path}: HTTP ${response.status}`);
  return response;
}
async function json(path, init) { return (await request(path, init)).json(); }
const available = (a) => a.user.creditsTotal - a.user.creditsUsed;
const account = () => json(`/api/account?email=${encodeURIComponent(email)}`);
await json('/api/auth/register', { method: 'POST', headers: {'content-type':'application/json'}, body: JSON.stringify({email,password,name:'网关画布验收'}) });
const config = await json('/api/config');
assert.ok(config.db && config.storage && config.openai);
assert.ok(config.imageModels.find(m => m.id === 'naumi-image-standard' && m.supportsEdit));
const source = await readFile(process.env.REFERENCE_IMAGE || '/app/public/demos/suite-before.webp');
const parentForm = new FormData();
parentForm.set('email', email);
parentForm.set('title', '网关验收参考图');
parentForm.set('image', new Blob([source], {type:'image/webp'}), 'source.webp');
const parent = await json('/api/artworks/add', {method:'POST',body:parentForm});

async function generate(model) {
  const form = new FormData();
  for (const [k,v] of Object.entries({email,model,prompt:'Keep the product shape and create a clean studio product photo on a light gray background',userPrompt:'保留商品形状，浅灰背景棚拍',category:'main',ratio:'1:1',resolution:'1K',count:'1',parentId:parent.id,parentIds:'[]',origin:'canvas'})) form.set(k,v);
  form.set('image',new Blob([source],{type:'image/webp'}),'source.webp');
  const started = Date.now();
  const job = await json('/api/generate-image',{method:'POST',body:form});
  assert.ok(job.jobId);
  await writeFile(`${output}/${model}-job.json`,JSON.stringify(job),{mode:0o600});
  while (Date.now()-started < 330000) {
    await new Promise(r=>setTimeout(r,1500));
    const result=await json(`/api/generate-image?job=${encodeURIComponent(job.jobId)}`);
    if (['done','error'].includes(result.status)) {
      const completed = {jobId:job.jobId,elapsedMs:Date.now()-started,result};
      await writeFile(`${output}/${model}-result.json`,JSON.stringify(completed),{mode:0o600});
      return completed;
    }
  }
  throw Error('Job timed out; do not resubmit without inspecting upstream receipt');
}
const before=await account();
const success=await generate('naumi-image-standard');
assert.equal(success.result.status,'done',success.result.error);
assert.equal(success.result.images.length,1);
assert.equal(success.result.mock,false);
assert.equal(success.result.persisted,true);
const after=await account();
const artwork=after.artworks.find(w=>w.id===success.result.images[0].id);
assert.ok(artwork);
assert.equal(artwork.parentId,parent.id);
assert.equal(artwork.origin,'canvas');
assert.ok(artwork.batchId);
assert.equal(success.result.creditsUsed,6);
assert.equal(available(before)-available(after),6);
const media=await request(success.result.images[0].url);
assert.match(media.headers.get('content-type'),/^image\//);
await writeFile(`${output}/generated-image.bin`,Buffer.from(await media.arrayBuffer()));

// Premium is temporarily in this private instance's catalog but there is no
// eligible premium route: the gateway rejects before any provider submission.
const failure=await generate('naumi-image-premium');
assert.equal(failure.result.status,'error');
const afterFailure=await account();
assert.equal(available(afterFailure),available(after));
assert.equal(afterFailure.artworks.length,after.artworks.length);
const summary={status:'PASS',email,success:{jobId:success.jobId,elapsedMs:success.elapsedMs,artworkId:artwork.id,parentId:parent.id,batchId:artwork.batchId,url:success.result.images[0].url,width:success.result.images[0].width,height:success.result.images[0].height,creditsBefore:available(before),creditsAfter:available(after)},failure:{jobId:failure.jobId,status:failure.result.status,creditsAfter:available(afterFailure),artworkCountUnchanged:true}};
await writeFile(`${output}/summary.json`,JSON.stringify(summary,null,2),{mode:0o600});
console.log(JSON.stringify(summary));
