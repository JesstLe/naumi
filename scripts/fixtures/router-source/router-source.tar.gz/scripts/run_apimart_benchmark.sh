#!/usr/bin/env bash
set -euo pipefail

root_dir=$(cd "$(dirname "$0")/.." && pwd)
fixture=${1:-"$root_dir/benchmarks/apimart-1k-v1.json"}
output_root=${2:-"$root_dir/artifacts"}

if [[ -z "${NAUMI_ROUTER_TOKEN:-}" ]]; then
  echo "NAUMI_ROUTER_TOKEN is required" >&2
  exit 1
fi

run_id="apimart-1k-v1-$(date -u +%Y%m%dT%H%M%SZ)"
run_dir="$output_root/$run_id"
mkdir -p "$run_dir/images" "$run_dir/responses"
cp "$fixture" "$run_dir/fixture.json"
: > "$run_dir/results.jsonl"

case_count=$(jq '.cases | length' "$fixture")
for index in $(seq 0 $((case_count - 1))); do
  case_json=$(jq -c ".cases[$index]" "$fixture")
  case_id=$(jq -r '.id' <<<"$case_json")
  prompt=$(jq -r '.prompt' <<<"$case_json")
  category=$(jq -r '.category' <<<"$case_json")
  acceptance=$(jq -r '.acceptance' <<<"$case_json")
  request_file="$run_dir/request.json"
  response_file="$run_dir/responses/$case_id.json"
  header_file="$run_dir/responses/$case_id.headers"

  jq -n --arg prompt "$prompt" '{
    model: "naumi-image-standard",
    prompt: $prompt,
    size: "1k",
    quality: "standard",
    response_format: "url",
    n: 1
  }' > "$request_file"

  metrics=$(curl --silent --show-error --max-time 120 \
    --dump-header "$header_file" \
    --output "$response_file" \
    --write-out '%{http_code} %{time_total}' \
    http://127.0.0.1:8081/v1/images/generations \
    -H "Authorization: Bearer ${NAUMI_ROUTER_TOKEN}" \
    -H 'Content-Type: application/json' \
    --data-binary "@$request_file" || true)

  http_status=${metrics%% *}
  duration_seconds=${metrics#* }
  request_id=$(awk 'BEGIN{IGNORECASE=1} /^X-Request-Id:/ {gsub("\r", "", $2); print $2}' "$header_file")
  media_url=$(jq -r '.data[0].url // empty' "$response_file" 2>/dev/null || true)
  downloaded=false
  if [[ "$http_status" == "200" && -n "$media_url" ]]; then
    if curl --silent --show-error --fail --location --max-time 60 "$media_url" --output "$run_dir/images/$case_id.png"; then
      downloaded=true
    fi
  fi

  jq -cn \
    --arg id "$case_id" \
    --arg category "$category" \
    --arg prompt "$prompt" \
    --arg acceptance "$acceptance" \
    --arg request_id "$request_id" \
    --arg http_status "$http_status" \
    --arg duration_seconds "$duration_seconds" \
    --arg media_url "$media_url" \
    --argjson downloaded "$downloaded" \
    '{id:$id, category:$category, prompt:$prompt, acceptance:$acceptance, request_id:$request_id, http_status:($http_status|tonumber), duration_seconds:($duration_seconds|tonumber), media_url:$media_url, downloaded:$downloaded}' \
    >> "$run_dir/results.jsonl"

  rm -f "$request_file"
  echo "[$((index + 1))/$case_count] $case_id HTTP $http_status ${duration_seconds}s downloaded=$downloaded"
done

echo "$run_dir"
