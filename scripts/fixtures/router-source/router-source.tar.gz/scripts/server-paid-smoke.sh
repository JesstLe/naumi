#!/usr/bin/env bash
set -euo pipefail

# One explicitly approved 1K generation. Never retry an ambiguous paid request.
output_dir="${1:?usage: server-paid-smoke.sh NEW_OUTPUT_DIRECTORY}"
if [[ -e "$output_dir" ]]; then
  echo 'Refusing to repeat a paid test in an existing output directory' >&2
  exit 1
fi
umask 077
mkdir -p "$output_dir"
source /etc/naumi-gateway/credentials.env
started="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
jq -n --arg id "paid-smoke-$(date +%s)-$$" '{model:"naumi-image-standard",prompt:"Premium ecommerce product photograph of a single emerald green glass cosmetic bottle with a plain blank cream label, standing on an ivory stone pedestal, soft studio lighting, subtle botanical shadow, clean warm white background, realistic materials, square composition, no text, no watermark",size:"1k",quality:"standard",n:1,response_format:"b64_json",extra_fields:{naumi:{operation_id:$id}}}' >"$output_dir/request.json"
set +e
printf 'header = "Authorization: Bearer %s"\n' "$NEW_API_INTERNAL_TOKEN" |
  curl --config - --silent --show-error --connect-timeout 5 --max-time 150 \
    -H 'Content-Type: application/json' \
    --data-binary "@$output_dir/request.json" \
    --output "$output_dir/response.json" \
    --write-out '%{http_code} %{time_total}\n' \
    http://127.0.0.1:3100/v1/images/generations >"$output_dir/http-result.txt"
curl_exit=$?
set -e
journalctl -u naumi-router.service --since "$started" -o cat --no-pager |
  sed -n '/generation completed/p; /provider attempt failed/p; /all eligible routes failed/p' >"$output_dir/router-receipt.log"
read -r http_code duration <"$output_dir/http-result.txt"
jq -n --arg started "$started" --arg code "$http_code" --arg duration "$duration" --argjson exit "$curl_exit" \
  '{started_at:$started,http_code:$code,elapsed_seconds:($duration|tonumber),curl_exit:$exit}' >"$output_dir/summary.json"
if [[ "$curl_exit" != 0 || "$http_code" != 200 ]]; then
  jq . "$output_dir/summary.json"
  jq '{error}' "$output_dir/response.json" 2>/dev/null || true
  echo 'Paid request was not repeated. Inspect receipts before any further submission.' >&2
  exit 1
fi
jq -e '.data | length == 1' "$output_dir/response.json" >/dev/null
jq -er '.data[0].b64_json | select(length > 0)' "$output_dir/response.json" | base64 --decode >"$output_dir/image.png"
sha256sum "$output_dir/image.png"
file "$output_dir/image.png"
jq . "$output_dir/summary.json"
sed -n '1,10p' "$output_dir/router-receipt.log"
