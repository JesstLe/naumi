#!/usr/bin/env bash
# Exercise the actual installer rewrite under a private caller umask.
set -Eeuo pipefail
test "$(id -u)" = 0
id naumi-gateway >/dev/null 2>&1 || useradd --system --shell /usr/sbin/nologin naumi-gateway
release_dir=$(mktemp -d /tmp/naumi-release-config-XXXXXX)
case "$release_dir" in /tmp/naumi-release-config-*) ;; *) exit 1;; esac
trap 'rm -rf -- "$release_dir"' EXIT
chmod 0755 "$release_dir"
install -d -m 0755 "$release_dir/config"
umask 077
printf '%s\n' '{"routes":[{"provider":"apimart","upstream_model":"gpt-image-2.5-ext","supports_edit":true,"estimated_cost_microusd":21000}]}' > "$release_dir/config/routes.fixture.json"
# Reuse production commands, rather than reproducing the chmod fix in this test.
installer=$(cd "$(dirname "$0")/.." && pwd)/deploy/server/install-release.sh
awk '/^for routes_file in / {active=1} active && /^touch / {exit} active {print}' "$installer" > "$release_dir/rewrite.sh"
before=$(jq -c '.routes[0].estimated_cost_microusd' "$release_dir/config/routes.fixture.json")
export release_dir
bash "$release_dir/rewrite.sh"
runuser -u naumi-gateway -- cat "$release_dir/config/routes.fixture.json" >/dev/null
test "$(stat -c '%a' "$release_dir/config/routes.fixture.json")" = 644
test "$(jq -c '.routes[0].estimated_cost_microusd' "$release_dir/config/routes.fixture.json")" = "$before"
jq -e '.routes[0].preserves_identity==true and .routes[0].max_reference_images==15' "$release_dir/config/routes.fixture.json" >/dev/null
printf 'PRIVATE_UMASK_SERVICE_CONFIG_READ=PASS\n'
