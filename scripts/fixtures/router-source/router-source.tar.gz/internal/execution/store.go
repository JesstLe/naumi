// Package execution persists paid attempts before any provider submission.
package execution

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"os"
	"path/filepath"
	"runtime"
	"sync"
	"time"

	"github.com/JesstLe/naumi-router/internal/domain"
	"github.com/JesstLe/naumi-router/internal/routing"
	bolt "go.etcd.io/bbolt"
)

var ErrConflict = errors.New("operation ID is bound to another request")
var ErrBusy = errors.New("operation is already executing")

type Attempt struct {
	CredentialRef string                    `json:"credential_ref,omitempty"`
	Route         routing.Route             `json:"route"`
	Key           string                    `json:"key"`
	Identity      string                    `json:"identity"`
	TaskID        string                    `json:"task_id,omitempty"`
	State         string                    `json:"state"`
	DurationMS    int64                     `json:"duration_ms,omitempty"`
	Receipt       *domain.GenerationReceipt `json:"receipt,omitempty"`
}

type Record struct {
	ConfigDigest string          `json:"config_digest,omitempty"`
	Candidates   []routing.Route `json:"candidates,omitempty"`
	ID           string          `json:"id"`
	Hash         string          `json:"request_hash"`
	State        string          `json:"state"`
	Attempts     []Attempt       `json:"attempts"`
	UpdatedAt    time.Time       `json:"updated_at"`
}

type Store struct {
	db     *bolt.DB
	dir    string
	mu     sync.Mutex
	active map[string]bool
}

type storedResponse struct {
	Response domain.ImageResponse      `json:"response"`
	Receipt  *domain.GenerationReceipt `json:"receipt,omitempty"`
}

func Open(dir string) (*Store, error) {
	if err := os.MkdirAll(dir, 0700); err != nil {
		return nil, err
	}
	if err := os.Chmod(dir, 0700); err != nil {
		return nil, err
	}
	db, err := bolt.Open(filepath.Join(dir, "operations.db"), 0600, &bolt.Options{Timeout: time.Second})
	if err != nil {
		return nil, err
	}
	err = db.Update(func(tx *bolt.Tx) error { _, err := tx.CreateBucketIfNotExists([]byte("operations")); return err })
	if err != nil {
		_ = db.Close()
		return nil, err
	}
	return &Store{db: db, dir: dir, active: map[string]bool{}}, nil
}

func (s *Store) Close() error { return s.db.Close() }

// The database file lock prevents concurrent processes; this claim prevents
// concurrent goroutines. No wall-clock lease can expire during a paid POST.
func (s *Store) Claim(id, hash string) (Record, func(), error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	record, err := s.Load(id)
	if err != nil {
		return Record{}, nil, err
	}
	if record.ID != "" && record.Hash != hash {
		return Record{}, nil, ErrConflict
	}
	if s.active[id] {
		return Record{}, nil, ErrBusy
	}
	if record.ID == "" {
		record = Record{ID: id, Hash: hash, State: "queued"}
		if err := s.Save(record); err != nil {
			return Record{}, nil, err
		}
	}
	s.active[id] = true
	return record, func() { s.mu.Lock(); delete(s.active, id); s.mu.Unlock() }, nil
}

func (s *Store) Load(id string) (Record, error) {
	var record Record
	err := s.db.View(func(tx *bolt.Tx) error {
		data := tx.Bucket([]byte("operations")).Get([]byte(id))
		if data == nil {
			return nil
		}
		return json.Unmarshal(data, &record)
	})
	return record, err
}

func (s *Store) Save(record Record) error {
	record.UpdatedAt = time.Now().UTC()
	data, err := json.Marshal(record)
	if err != nil {
		return err
	}
	return s.db.Update(func(tx *bolt.Tx) error { return tx.Bucket([]byte("operations")).Put([]byte(record.ID), data) })
}

func (s *Store) resultPath(id string) string {
	hash := sha256.Sum256([]byte(id))
	return filepath.Join(s.dir, hex.EncodeToString(hash[:])+".json")
}

func (s *Store) Complete(record Record, response domain.ImageResponse) error {
	// Revised prompts can contain the user's input; only persist delivered assets.
	response.Data = append([]domain.ImageData(nil), response.Data...)
	for i := range response.Data {
		response.Data[i].RevisedPrompt = ""
	}
	data, err := json.Marshal(storedResponse{Response: response, Receipt: response.Receipt})
	if err != nil {
		return err
	}
	file, err := os.CreateTemp(s.dir, "result-*")
	if err != nil {
		return err
	}
	name := file.Name()
	defer os.Remove(name)
	if err = file.Chmod(0600); err == nil {
		_, err = file.Write(data)
	}
	if err == nil {
		err = file.Sync()
	}
	closeErr := file.Close()
	if err != nil {
		return err
	}
	if closeErr != nil {
		return closeErr
	}
	if err := os.Rename(name, s.resultPath(record.ID)); err != nil {
		return err
	}
	// Linux production requires the rename itself to survive power loss before
	// the database points at this result. Windows does not support directory Sync.
	if runtime.GOOS != "windows" {
		dir, err := os.Open(s.dir)
		if err != nil {
			return err
		}
		err = dir.Sync()
		_ = dir.Close()
		if err != nil {
			return err
		}
	}
	record.State = "completed"
	return s.Save(record)
}

func (s *Store) Response(id string) (domain.ImageResponse, error) {
	data, err := os.ReadFile(s.resultPath(id))
	if err != nil {
		return domain.ImageResponse{}, err
	}
	var response storedResponse
	err = json.Unmarshal(data, &response)
	response.Response.Receipt = response.Receipt
	return response.Response, err
}
