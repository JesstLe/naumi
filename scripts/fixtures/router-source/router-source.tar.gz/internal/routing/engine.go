package routing

import (
	"errors"
	"fmt"
	"sort"
	"strconv"
	"strings"
	"unicode"

	"github.com/JesstLe/naumi-router/internal/domain"
)

type Route struct {
	SupportsMask          bool              `json:"supports_mask,omitempty"`
	ResolutionMap         map[string]string `json:"resolution_map,omitempty"`
	MoneyPrices           []MoneyPrice      `json:"money_prices,omitempty"`
	CostCurrency          string            `json:"cost_currency,omitempty"`
	EstimatedCostMicros   int64             `json:"estimated_cost_micros,omitempty"`
	QualityMap            map[string]string `json:"quality_map,omitempty"`
	SupportedQualities    []string          `json:"supported_qualities,omitempty"`
	NativeResolutions     []string          `json:"native_resolutions,omitempty"`
	Prices                []Price           `json:"prices,omitempty"`
	MaxConcurrent         int               `json:"max_concurrent,omitempty"`
	MaxReferenceImages    int               `json:"max_reference_images,omitempty"`
	PreservesIdentity     bool              `json:"preserves_identity,omitempty"`
	EstimateSource        string            `json:"estimate_source,omitempty"`
	ID                    string            `json:"id"`
	Provider              string            `json:"provider"`
	UpstreamModel         string            `json:"upstream_model"`
	Enabled               bool              `json:"enabled"`
	Healthy               bool              `json:"healthy"`
	EstimatedCostMicroUSD int64             `json:"estimated_cost_microusd"`
	ExpectedLatencyMS     int64             `json:"expected_latency_ms"`
	QualityRank           int               `json:"quality_rank"`
	MaxPixels             int64             `json:"max_pixels"`
	TextAccuracy          bool              `json:"text_accuracy"`
	Native4K              bool              `json:"native_4k"`
	SupportsEdit          bool              `json:"supports_edit"`
	UpstreamQuality       string            `json:"upstream_quality,omitempty"`
	UpstreamVersion       string            `json:"upstream_version,omitempty"`
}

// Price is a single-image supplier estimate, independent of customer credits.
type Price struct {
	Resolution   string `json:"resolution"`
	Quality      string `json:"quality"`
	Mode         string `json:"mode"`
	CostMicroUSD int64  `json:"cost_microusd"`
}

type Config struct {
	Routes    []Route          `json:"routes"`
	Providers []ProviderConfig `json:"providers,omitempty"`
}

type ProviderConfig struct {
	ID         string `json:"id"`
	Protocol   string `json:"protocol"`
	BaseURLEnv string `json:"base_url_env"`
	APIKeyEnv  string `json:"api_key_env"`
}

type Requirements struct {
	NeedsNativeResolution bool
	ReferenceCount        int
	PreserveIdentity      bool
	Resolution            string
	MinQualityRank        int
	Pixels                int64
	NeedsText             bool
	NeedsNative4K         bool
	NeedsEdit             bool
}

type Engine struct {
	externalCapacity func(string) (func(), bool)
	aliases          map[string]Alias
	healthKeys       map[string]string
	routes           []Route
	Health           *Health
}

func NewEngine(routes []Route) (*Engine, error) {
	if len(routes) == 0 {
		return nil, errors.New("at least one route is required")
	}
	seen := make(map[string]struct{}, len(routes))
	limits := map[string]int{}
	for _, route := range routes {
		if route.ID == "" || route.Provider == "" || route.UpstreamModel == "" {
			return nil, errors.New("every route requires id, provider, and upstream_model")
		}
		if _, ok := seen[route.ID]; ok {
			return nil, fmt.Errorf("duplicate route id %q", route.ID)
		}
		seen[route.ID] = struct{}{}
		if route.EstimatedCostMicroUSD < 0 || route.ExpectedLatencyMS < 0 {
			return nil, fmt.Errorf("route %q has a negative cost or latency", route.ID)
		}
		if route.QualityRank < 1 || route.QualityRank > 5 {
			return nil, fmt.Errorf("route %q quality_rank must be between 1 and 5", route.ID)
		}
		if route.MaxPixels < 1 {
			return nil, fmt.Errorf("route %q max_pixels must be positive", route.ID)
		}
		if route.MaxConcurrent < 0 || route.MaxReferenceImages < 0 {
			return nil, errors.New("negative route capacity")
		}
		limit := route.MaxConcurrent
		if limit == 0 {
			limit = 4
		}
		if prior, ok := limits[route.Provider]; ok && prior != limit {
			return nil, errors.New("provider routes require the same concurrency limit")
		}
		limits[route.Provider] = limit
		prices := map[string]bool{}
		for _, price := range route.Prices {
			key := price.Resolution + ":" + price.Quality + ":" + price.Mode
			if prices[key] || price.CostMicroUSD < 1 || price.CostMicroUSD > 1_000_000_000 ||
				(price.Resolution != "1K" && price.Resolution != "2K" && price.Resolution != "4K") ||
				(price.Mode != "generate" && price.Mode != "edit") ||
				(price.Quality != "auto" && price.Quality != "low" && price.Quality != "medium" && price.Quality != "high" && price.Quality != "xhigh" && price.Quality != "max" && price.Quality != "standard") {
				return nil, fmt.Errorf("route %q has invalid or duplicate prices", route.ID)
			}
			prices[key] = true
		}
	}
	return &Engine{routes: append([]Route(nil), routes...), Health: NewHealth(limits)}, nil
}

func (e *Engine) Candidates(request domain.ImageRequest) ([]Route, Requirements, error) {
	analysisRequest := request
	if e.aliases != nil {
		analysisRequest.Model = "configured"
	}
	requirements, err := Analyze(analysisRequest)
	if err != nil {
		return nil, Requirements{}, err
	}
	requirements, alias, err := e.configuredRequirements(request, requirements)
	if err != nil {
		return nil, requirements, err
	}

	eligible := make([]Route, 0, len(e.routes))
	for _, route := range e.routes {
		if alias != nil && !contains(alias.Candidates, route.ID) {
			continue
		}
		if requirements.NeedsNativeResolution && (alias != nil || len(route.NativeResolutions) > 0) && !contains(route.NativeResolutions, requirements.Resolution) {
			continue
		}
		if len(route.SupportedQualities) > 0 && !contains(route.SupportedQualities, request.Quality) {
			continue
		}
		if mapped := route.QualityMap[request.Quality]; mapped != "" {
			route.UpstreamQuality = mapped
		}
		if !route.Enabled || !route.Healthy {
			continue
		}
		if route.QualityRank < requirements.MinQualityRank || route.MaxPixels < requirements.Pixels {
			continue
		}
		if requirements.NeedsText && !route.TextAccuracy {
			continue
		}
		if requirements.NeedsNative4K && !route.Native4K {
			continue
		}
		if requirements.NeedsEdit && !route.SupportsEdit {
			continue
		}
		if request.Mask != nil && !route.SupportsMask {
			continue
		}
		if requirements.PreserveIdentity && !route.PreservesIdentity {
			continue
		}
		if (alias != nil || route.MaxReferenceImages > 0) && requirements.ReferenceCount > route.MaxReferenceImages {
			continue
		}
		count := int64(1)
		if request.N != nil {
			count = int64(*request.N)
		}
		route.EstimateSource = "legacy_flat"
		if len(route.Prices) > 0 {
			quality := route.UpstreamQuality
			if quality == "" {
				quality = request.Quality
			}
			mode := "generate"
			if requirements.NeedsEdit {
				mode = "edit"
			}
			matched := false
			for _, price := range route.Prices {
				if price.Resolution == requirements.Resolution && price.Quality == quality && price.Mode == mode {
					route.EstimatedCostMicroUSD = price.CostMicroUSD
					matched = true
					break
				}
			}
			if !matched {
				continue
			}
			route.EstimateSource = "price_matrix"
		}
		if count < 1 || count > 4 || route.EstimatedCostMicroUSD > (1<<63-1)/count {
			continue
		}
		route.EstimatedCostMicroUSD *= count
		if len(route.MoneyPrices) > 0 {
			mode := "generate"
			if requirements.NeedsEdit {
				mode = "edit"
			}
			matched := false
			for _, p := range route.MoneyPrices {
				if p.Resolution == requirements.Resolution && p.Quality == request.Quality && p.Mode == mode {
					route.CostCurrency = p.Currency
					multiplier := count
					if p.Unit == "task" {
						multiplier = 1
					}
					route.EstimatedCostMicros = p.AmountMicros * multiplier
					route.EstimateSource = "billing_reference"
					matched = true
					break
				}
			}
			if !matched && alias != nil && alias.Strategy == "lowest-cost" {
				continue
			}
		}
		eligible = append(eligible, route)
	}

	sort.SliceStable(eligible, func(i, j int) bool {
		if eligible[i].EstimatedCostMicroUSD != eligible[j].EstimatedCostMicroUSD {
			return eligible[i].EstimatedCostMicroUSD < eligible[j].EstimatedCostMicroUSD
		}
		if eligible[i].ExpectedLatencyMS != eligible[j].ExpectedLatencyMS {
			return eligible[i].ExpectedLatencyMS < eligible[j].ExpectedLatencyMS
		}
		return eligible[i].ID < eligible[j].ID
	})
	if err := sortConfigured(eligible, alias); err != nil {
		return nil, requirements, err
	}

	if len(eligible) == 0 {
		return nil, requirements, errors.New("no healthy route satisfies the request")
	}
	return eligible, requirements, nil
}

func Analyze(request domain.ImageRequest) (Requirements, error) {
	pixels, is4K, err := parseSize(request.Size)
	if err != nil {
		return Requirements{}, err
	}

	qualityRank := qualityRankFor(request.Model, request.Quality)
	if request.Naumi.Task == "product" && qualityRank < 2 {
		qualityRank = 2
	}
	if (request.Naumi.Task == "detail" || request.Naumi.Task == "layout") && qualityRank < 2 {
		qualityRank = 2
	}
	needsText := request.Naumi.TextAccuracy == "required" ||
		(request.Naumi.TextAccuracy == "auto" && promptNeedsTextAccuracy(request.Prompt))
	if request.Naumi.Task == "layout" {
		needsText = true
	}
	if request.Model == "naumi-image-auto" || request.Model == "auto" {
		if needsText && qualityRank < 2 {
			qualityRank = 2
		}
	}
	resolution := request.Naumi.Resolution
	if resolution == "" {
		resolution = "1K"
		if pixels > 1536*1024 {
			resolution = "2K"
		}
		if is4K {
			resolution = "4K"
		}
	}
	if resolution == "2K" && pixels < 2048*2048 {
		pixels = 2048 * 2048
	}
	if resolution == "4K" && pixels < 3840*2160 {
		pixels = 3840 * 2160
		is4K = true
	}

	return Requirements{
		NeedsNativeResolution: request.Naumi.NativeResolution,
		ReferenceCount:        len(request.ReferenceImages),
		PreserveIdentity:      request.Naumi.PreserveIdentity,
		Resolution:            resolution,
		MinQualityRank:        qualityRank,
		Pixels:                pixels,
		NeedsText:             needsText,
		NeedsNative4K:         request.Naumi.NativeResolution && is4K,
		NeedsEdit:             len(request.ReferenceImages) > 0,
	}, nil
}

func qualityRankFor(model, quality string) int {
	minimum := 1
	switch model {
	case "naumi-image-economy":
		minimum = 1
	case "naumi-image-standard":
		minimum = 2
	case "naumi-image-premium":
		minimum = 3
	}
	rank := 1
	switch quality {
	case "max":
		rank = 5
	case "xhigh":
		rank = 4
	case "high":
		rank = 3
	case "medium", "standard":
		rank = 2
	}
	if rank < minimum {
		return minimum
	}
	return rank
}

func parseSize(size string) (pixels int64, is4K bool, err error) {
	switch strings.ToLower(size) {
	case "1k":
		return 1024 * 1024, false, nil
	case "2k":
		return 2048 * 2048, false, nil
	case "4k":
		return 3840 * 2160, true, nil
	}

	parts := strings.Split(strings.ToLower(size), "x")
	if len(parts) != 2 {
		return 0, false, errors.New("size must be 1k, 2k, 4k, or WIDTHxHEIGHT")
	}
	width, widthErr := strconv.ParseInt(parts[0], 10, 32)
	height, heightErr := strconv.ParseInt(parts[1], 10, 32)
	if widthErr != nil || heightErr != nil || width < 256 || height < 256 || width > 4096 || height > 4096 {
		return 0, false, errors.New("size dimensions must be between 256 and 4096 pixels")
	}
	pixels = width * height
	return pixels, pixels >= 3840*2160, nil
}

func promptNeedsTextAccuracy(prompt string) bool {
	lower := strings.ToLower(prompt)
	keywords := []string{
		"logo", "label", "slogan", "caption", "headline", "packaging text",
		"文字", "文本", "汉字", "中文", "标签", "标语", "标题", "包装字",
	}
	for _, keyword := range keywords {
		if strings.Contains(lower, keyword) {
			return true
		}
	}

	quoteCount := 0
	for _, r := range prompt {
		if r == '"' || r == '\u201c' || r == '\u201d' || r == '\u300c' || r == '\u300d' {
			quoteCount++
		}
		if unicode.IsControl(r) && !unicode.IsSpace(r) {
			return true
		}
	}
	return quoteCount >= 2
}
