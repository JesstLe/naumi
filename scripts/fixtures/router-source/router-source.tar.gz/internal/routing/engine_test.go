package routing

import (
	"testing"

	"github.com/JesstLe/naumi-router/internal/domain"
)

func TestCandidatesChooseCheapestEligibleRoute(t *testing.T) {
	engine := mustEngine(t, []Route{
		route("budget", 6_000, 1, 4_194_304, false, false),
		route("balanced", 21_000, 2, 8_294_400, true, true),
		route("premium", 100_000, 3, 8_294_400, true, true),
	})
	request := validRequest("A white-background product photo")

	candidates, _, err := engine.Candidates(request)
	if err != nil {
		t.Fatalf("Candidates returned error: %v", err)
	}
	if got, want := candidates[0].ID, "budget"; got != want {
		t.Fatalf("first route = %q, want %q", got, want)
	}
}

func TestCandidatesRequireTextAccurateRoute(t *testing.T) {
	engine := mustEngine(t, []Route{
		route("budget", 6_000, 1, 8_294_400, false, true),
		route("balanced", 21_000, 2, 8_294_400, true, true),
	})
	request := validRequest("在包装上准确写出中文文字“新品上市”")

	candidates, requirements, err := engine.Candidates(request)
	if err != nil {
		t.Fatalf("Candidates returned error: %v", err)
	}
	if !requirements.NeedsText {
		t.Fatal("expected prompt to require text accuracy")
	}
	if got, want := candidates[0].ID, "balanced"; got != want {
		t.Fatalf("first route = %q, want %q", got, want)
	}
}

func TestCandidatesRequireNative4K(t *testing.T) {
	engine := mustEngine(t, []Route{
		route("upscaled", 10_000, 2, 8_294_400, true, false),
		route("native", 21_000, 2, 8_294_400, true, true),
	})
	request := validRequest("Product photo")
	request.Size = "4k"
	request.Quality = "medium"
	request.Naumi.NativeResolution = true

	candidates, requirements, err := engine.Candidates(request)
	if err != nil {
		t.Fatalf("Candidates returned error: %v", err)
	}
	if !requirements.NeedsNative4K {
		t.Fatal("expected native 4K requirement")
	}
	if got, want := candidates[0].ID, "native"; got != want {
		t.Fatalf("first route = %q, want %q", got, want)
	}
}

func TestCandidatesSkipUnhealthyRoute(t *testing.T) {
	cheap := route("cheap", 1_000, 1, 4_194_304, false, false)
	cheap.Healthy = false
	engine := mustEngine(t, []Route{
		cheap,
		route("fallback", 6_000, 1, 4_194_304, false, false),
	})

	candidates, _, err := engine.Candidates(validRequest("Product photo"))
	if err != nil {
		t.Fatalf("Candidates returned error: %v", err)
	}
	if got, want := candidates[0].ID, "fallback"; got != want {
		t.Fatalf("first route = %q, want %q", got, want)
	}
}

func TestCandidatesRequireEditCapableRoute(t *testing.T) {
	textOnly := route("text-only", 1_000, 2, 8_294_400, true, true)
	textOnly.SupportsEdit = false
	edit := route("edit", 2_000, 2, 8_294_400, true, true)
	edit.SupportsEdit = true
	engine := mustEngine(t, []Route{textOnly, edit})
	request := validRequest("Keep the product and replace the background")
	request.ReferenceImages = []domain.ReferenceImage{{Bytes: []byte("image"), MimeType: "image/png"}}

	candidates, requirements, err := engine.Candidates(request)
	if err != nil {
		t.Fatalf("Candidates returned error: %v", err)
	}
	if !requirements.NeedsEdit {
		t.Fatal("expected edit requirement")
	}
	if got, want := candidates[0].ID, "edit"; got != want {
		t.Fatalf("first route = %q, want %q", got, want)
	}
}

func route(id string, cost int64, quality int, maxPixels int64, text, native4K bool) Route {
	return Route{
		ID:                    id,
		Provider:              "mock",
		UpstreamModel:         id + "-model",
		Enabled:               true,
		Healthy:               true,
		EstimatedCostMicroUSD: cost,
		ExpectedLatencyMS:     10_000,
		QualityRank:           quality,
		MaxPixels:             maxPixels,
		TextAccuracy:          text,
		Native4K:              native4K,
		SupportsEdit:          true,
	}
}

func validRequest(prompt string) domain.ImageRequest {
	one := 1
	return domain.ImageRequest{
		Model:          "naumi-image-auto",
		Prompt:         prompt,
		N:              &one,
		Quality:        "auto",
		Size:           "1024x1024",
		ResponseFormat: "b64_json",
		Naumi:          domain.RoutingOptions{TextAccuracy: "auto"},
	}
}

func mustEngine(t *testing.T, routes []Route) *Engine {
	t.Helper()
	engine, err := NewEngine(routes)
	if err != nil {
		t.Fatalf("NewEngine returned error: %v", err)
	}
	return engine
}
