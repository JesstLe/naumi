package routing

import (
	"sync"
	"time"
)

type ProviderHealth struct {
	Active    int       `json:"active"`
	Limit     int       `json:"limit"`
	Failures  int       `json:"failures"`
	OpenUntil time.Time `json:"open_until,omitempty"`
	Probe     bool      `json:"probe"`
}

// Health counts actual calls, never paid health probes. Recovery of accepted
// tasks bypasses the circuit, but still observes the provider concurrency cap.
type Health struct {
	mu        sync.Mutex
	providers map[string]*ProviderHealth
	parents   map[string]string
	now       func() time.Time
	cooldown  time.Duration
}

func NewHealth(limits map[string]int) *Health {
	h := &Health{providers: map[string]*ProviderHealth{}, parents: map[string]string{}, now: time.Now, cooldown: time.Minute}
	for id, limit := range limits {
		h.providers[id] = &ProviderHealth{Limit: limit}
	}
	return h
}

// Historical runtimes share this account budget. Retaining a historical version
// also retains its stricter limit; no active call or circuit state is reset.
func (h *Health) Register(id string, limit int) {
	h.mu.Lock()
	defer h.mu.Unlock()
	id = h.root(id)
	if prior := h.providers[id]; prior != nil {
		if limit < prior.Limit {
			prior.Limit = limit
		}
		return
	}
	h.providers[id] = &ProviderHealth{Limit: limit}
}

func (h *Health) root(id string) string {
	for h.parents[id] != "" && h.parents[id] != id {
		id = h.parents[id]
	}
	return id
}

// Link stable supplier account ids with credential identities. This merges both
// key rotation and duplicate registrations of the exact same account/key.
// Lease completion resolves the root again, so even in-flight leases survive a merge.
func (h *Health) LinkAccounts(identity, stable string) {
	h.mu.Lock()
	defer h.mu.Unlock()
	a, b := h.root(identity), h.root(stable)
	if a == b {
		return
	}
	pa, pb := h.providers[a], h.providers[b]
	if pa == nil {
		h.parents[a] = b
		return
	}
	if pb == nil {
		h.parents[b] = a
		return
	}
	pa.Active += pb.Active
	if pb.Limit < pa.Limit {
		pa.Limit = pb.Limit
	}
	if pb.Failures > pa.Failures {
		pa.Failures = pb.Failures
	}
	if pb.OpenUntil.After(pa.OpenUntil) {
		pa.OpenUntil = pb.OpenUntil
	}
	pa.Probe = pa.Probe || pb.Probe
	h.parents[b] = a
	delete(h.providers, b)
}

func (h *Health) Acquire(id string, recovery bool) (func(bool), bool) {
	h.mu.Lock()
	p := h.providers[h.root(id)]
	if p == nil || p.Active >= p.Limit {
		h.mu.Unlock()
		return nil, false
	}
	probe := false
	if !recovery && !p.OpenUntil.IsZero() {
		if h.now().Before(p.OpenUntil) || p.Probe {
			h.mu.Unlock()
			return nil, false
		}
		probe = true
		p.Probe = true
	}
	p.Active++
	h.mu.Unlock()
	var once sync.Once
	return func(success bool) {
		once.Do(func() {
			h.mu.Lock()
			defer h.mu.Unlock()
			p = h.providers[h.root(id)]
			p.Active--
			if probe {
				p.Probe = false
			}
			if success {
				p.Failures = 0
				p.OpenUntil = time.Time{}
			} else {
				p.Failures++
				if p.Failures >= 3 {
					p.OpenUntil = h.now().Add(h.cooldown)
				}
			}
		})
	}, true
}

func (h *Health) Snapshot() map[string]ProviderHealth {
	h.mu.Lock()
	defer h.mu.Unlock()
	result := map[string]ProviderHealth{}
	for id, state := range h.providers {
		result[id] = *state
	}
	return result
}
