package routing

import "testing"

func TestAccountMergePreservesLiveLeasesAndCooldownAcrossRotation(t *testing.T) {
	h := NewHealth(map[string]int{"old-key": 2})
	h.LinkAccounts("old-key", "stable-supplier")
	first, ok := h.Acquire("old-key", false)
	if !ok {
		t.Fatal("lease")
	}
	h.Register("new-key", 2)
	h.LinkAccounts("new-key", "stable-supplier")
	second, ok := h.Acquire("new-key", false)
	if !ok {
		t.Fatal("rotated lease")
	}
	if release, ok := h.Acquire("old-key", false); ok {
		release(true)
		t.Fatal("account merge lost active lease")
	}
	first(false)
	second(false)
	third, ok := h.Acquire("new-key", false)
	if !ok {
		t.Fatal("released slots lost")
	}
	third(false)
	if release, ok := h.Acquire("old-key", false); ok {
		release(true)
		t.Fatal("old version bypassed shared cooldown")
	}
	recovery, ok := h.Acquire("old-key", true)
	if !ok {
		t.Fatal("accepted recovery could not bypass cooldown")
	}
	recovery(true)
	if s := h.Snapshot(); len(s) != 1 {
		t.Fatal("account states duplicated")
	}
}
