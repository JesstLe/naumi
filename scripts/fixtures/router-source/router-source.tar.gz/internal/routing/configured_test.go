package routing

import (
	"github.com/JesstLe/naumi-router/internal/domain"
	"testing"
)

func configuredRoute(id string) Route {
	return Route{ID: id, Provider: "p1", UpstreamModel: "wire", Enabled: true, Healthy: true, MaxConcurrent: 2, MaxPixels: 4096 * 4096, QualityRank: 5, SupportsEdit: true, MaxReferenceImages: 2, PreservesIdentity: true, TextAccuracy: true, Native4K: true, NativeResolutions: []string{"1K", "2K", "4K"}, SupportedQualities: []string{"low", "medium", "high", "xhigh", "max"}}
}
func TestConfiguredFilteringUsesCapabilitiesRulesAndPolicyInsteadOfAliasName(t *testing.T) {
	route := configuredRoute("u1")
	route.QualityRank = 1
	engine, err := NewConfiguredEngine([]Route{route}, []Alias{{ID: "naumi-image-premium", Strategy: "priority", Candidates: []string{"u1"}, MinQualityRank: 1}}, nil, nil)
	if err != nil {
		t.Fatal(err)
	}
	n := 1
	request := domain.ImageRequest{Model: "naumi-image-premium", Prompt: "studio", N: &n, Size: "1024x1024", Quality: "low", Naumi: domain.RoutingOptions{Task: "draft"}}
	if _, _, err = engine.Candidates(request); err != nil {
		t.Fatal("configured alias inherited a hardcoded legacy minimum")
	}
	route = configuredRoute("u1")
	route.NativeResolutions = []string{"1K"}
	engine, err = NewConfiguredEngine([]Route{route}, []Alias{{ID: "custom", Strategy: "priority", Candidates: []string{"u1"}}}, nil, nil)
	if err != nil {
		t.Fatal(err)
	}
	request.Model = "custom"
	request.Quality = "medium"
	for _, size := range []string{"1K", "2K", "4K"} {
		request.Naumi.Resolution = size
		request.Naumi.NativeResolution = true
		_, _, err = engine.Candidates(request)
		if (err == nil) != (size == "1K") {
			t.Fatalf("native capability %s err=%v", size, err)
		}
	}
	request.Naumi.NativeResolution = false
	request.Naumi.Resolution = "1K"
	for _, quality := range []string{"low", "medium", "high", "xhigh", "max"} {
		request.Quality = quality
		if _, _, err = engine.Candidates(request); err != nil {
			t.Fatalf("quality %s: %v", quality, err)
		}
	}
	request.Quality = "medium"
	request.ReferenceImages = []domain.ReferenceImage{{}, {}, {}}
	if _, _, err = engine.Candidates(request); err == nil {
		t.Fatal("reference image cap ignored")
	}
	route.MaxReferenceImages = 0
	engine, _ = NewConfiguredEngine([]Route{route}, []Alias{{ID: "custom", Strategy: "priority", Candidates: []string{"u1"}}}, nil, nil)
	request.ReferenceImages = []domain.ReferenceImage{{}}
	if _, _, err = engine.Candidates(request); err == nil {
		t.Fatal("configured zero-reference capability was treated as unlimited")
	}
	request.ReferenceImages = nil
	engine, _ = NewConfiguredEngine([]Route{route}, []Alias{{ID: "custom", Strategy: "priority", Candidates: []string{"u1"}, Rules: []Rule{{ID: "product-only", Priority: 100, When: Conditions{Task: []string{"product"}}, Require: Constraints{MinQualityRank: 3}}}}}, nil, nil)
	request.Naumi.Task = "draft"
	if _, _, err = engine.Candidates(request); err == nil {
		t.Fatal("unmatched rule silently routed")
	}
	request.Naumi.Task = "product"
	if _, _, err = engine.Candidates(request); err != nil {
		t.Fatal(err)
	}
}
func TestConfiguredCostSortingDoesNotTreatMissingOrCreditsAsFreeCurrency(t *testing.T) {
	a, b := configuredRoute("a"), configuredRoute("b")
	a.MoneyPrices = []MoneyPrice{{Resolution: "1K", Quality: "medium", Mode: "generate", Currency: "CNY", AmountMicros: 290000}}
	b.MoneyPrices = []MoneyPrice{{Resolution: "1K", Quality: "medium", Mode: "generate", Currency: "CNY", AmountMicros: 247500}}
	a.EstimatedCostMicroUSD = 1
	b.EstimatedCostMicroUSD = 100
	aliases := []Alias{{ID: "custom", Strategy: "lowest-cost", Candidates: []string{"a", "b"}}}
	engine, err := NewConfiguredEngine([]Route{a, b}, aliases, nil, nil)
	if err != nil {
		t.Fatal(err)
	}
	n := 2
	request := domain.ImageRequest{Model: "custom", Prompt: "studio", N: &n, Size: "1024x1024", Quality: "medium"}
	candidates, _, err := engine.Candidates(request)
	if err != nil || len(candidates) != 2 || candidates[0].ID != "b" || candidates[0].CostCurrency != "CNY" || candidates[0].EstimatedCostMicros != 495000 {
		t.Fatalf("candidates=%+v err=%v", candidates, err)
	}
	a.MoneyPrices[0].Unit = "task"
	engine, _ = NewConfiguredEngine([]Route{a, b}, aliases, nil, nil)
	candidates, _, err = engine.Candidates(request)
	if err != nil || candidates[0].ID != "a" || candidates[0].EstimatedCostMicros != 290000 {
		t.Fatal("per-task supplier cost multiplied by generated image count")
	}
	b.MoneyPrices = nil
	engine, _ = NewConfiguredEngine([]Route{a, b}, aliases, nil, nil)
	if _, _, err = engine.Candidates(request); err == nil {
		t.Fatal("missing monetary estimate was accepted as free")
	}
	b.MoneyPrices = []MoneyPrice{{Resolution: "1K", Quality: "medium", Mode: "generate", Currency: "USD", AmountMicros: 1}}
	engine, _ = NewConfiguredEngine([]Route{a, b}, aliases, nil, nil)
	if _, _, err = engine.Candidates(request); err == nil {
		t.Fatal("currencies compared without conversion")
	}
}
