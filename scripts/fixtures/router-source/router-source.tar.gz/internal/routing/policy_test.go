package routing

import (
	"github.com/JesstLe/naumi-router/internal/domain"
	"testing"
	"time"
)

func TestRequestPricesAndCapabilitiesDetermineRoute(t *testing.T) {
	a := route("a", 100, 2, 8_294_400, true, true)
	b := route("b", 200, 2, 8_294_400, true, true)
	a.SupportsEdit = true
	b.SupportsEdit = true
	b.PreservesIdentity = true
	b.MaxReferenceImages = 1
	a.Prices = []Price{{"1K", "auto", "generate", 10}, {"2K", "auto", "generate", 50}}
	b.Prices = []Price{{"1K", "auto", "generate", 20}, {"2K", "auto", "generate", 30}, {"1K", "auto", "edit", 40}}
	e := mustEngine(t, []Route{a, b})
	r := validRequest("product")
	n := 3
	r.N = &n
	r.Naumi.Resolution = "2K"
	candidates, _, err := e.Candidates(r)
	if err != nil || candidates[0].ID != "b" || candidates[0].EstimatedCostMicroUSD != 90 || candidates[0].EstimateSource != "price_matrix" {
		t.Fatalf("wrong price: %+v %v", candidates, err)
	}
	r.Naumi.Resolution = "1K"
	r.Naumi.PreserveIdentity = true
	r.ReferenceImages = []domain.ReferenceImage{{Bytes: []byte{1}}}
	candidates, _, err = e.Candidates(r)
	if err != nil || candidates[0].ID != "b" {
		t.Fatalf("identity route: %+v %v", candidates, err)
	}
	r.ReferenceImages = append(r.ReferenceImages, domain.ReferenceImage{})
	if _, _, err = e.Candidates(r); err == nil {
		t.Fatal("reference limit ignored")
	}
	r.ReferenceImages = nil
	r.Naumi.PreserveIdentity = false
	r.Naumi.Resolution = "4K"
	if _, _, err = e.Candidates(r); err == nil {
		t.Fatal("missing tier incorrectly used flat price")
	}
}

func TestCircuitConcurrencyAndHalfOpenRecovery(t *testing.T) {
	h := NewHealth(map[string]int{"p": 1})
	now := time.Now()
	h.now = func() time.Time { return now }
	for i := 0; i < 3; i++ {
		finish, ok := h.Acquire("p", false)
		if !ok {
			t.Fatal("early circuit")
		}
		if _, ok = h.Acquire("p", false); ok {
			t.Fatal("concurrency limit ignored")
		}
		finish(false)
	}
	if _, ok := h.Acquire("p", false); ok {
		t.Fatal("open circuit ignored")
	}
	finish, ok := h.Acquire("p", true)
	if !ok {
		t.Fatal("accepted recovery blocked")
	}
	finish(false)
	now = now.Add(2 * time.Minute)
	finish, ok = h.Acquire("p", false)
	if !ok {
		t.Fatal("half-open unavailable")
	}
	if _, ok = h.Acquire("p", false); ok {
		t.Fatal("second probe allowed")
	}
	finish(true)
	if h.Snapshot()["p"].Failures != 0 {
		t.Fatal("success did not close circuit")
	}
}
