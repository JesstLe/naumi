package routing

import (
	"errors"
	"sort"
	"sync"

	"github.com/JesstLe/naumi-router/internal/domain"
)

type Alias struct {
	ID             string   `json:"id"`
	Candidates     []string `json:"candidates"`
	Strategy       string   `json:"strategy"`
	MinQualityRank int      `json:"minQualityRank,omitempty"`
	Rules          []Rule   `json:"rules,omitempty"`
}
type Rule struct {
	ID       string      `json:"id"`
	Priority int         `json:"priority"`
	When     Conditions  `json:"when"`
	Require  Constraints `json:"require"`
}
type Conditions struct {
	Task             []string `json:"task,omitempty"`
	Quality          []string `json:"quality,omitempty"`
	Resolution       []string `json:"resolution,omitempty"`
	NeedsEdit        *bool    `json:"needsEdit,omitempty"`
	NeedsText        *bool    `json:"needsText,omitempty"`
	PreserveIdentity *bool    `json:"preserveIdentity,omitempty"`
	NativeResolution *bool    `json:"nativeResolution,omitempty"`
}
type Constraints struct {
	PreserveIdentity bool `json:"preserveIdentity,omitempty"`
	TextAccuracy     bool `json:"textAccuracy,omitempty"`
	MinQualityRank   int  `json:"minQualityRank,omitempty"`
	NativeResolution bool `json:"nativeResolution,omitempty"`
	Edit             bool `json:"edit,omitempty"`
}
type MoneyPrice struct {
	Unit         string `json:"unit,omitempty"`
	Resolution   string `json:"resolution"`
	Quality      string `json:"quality"`
	Mode         string `json:"mode"`
	Currency     string `json:"currency"`
	AmountMicros int64  `json:"amountMicros,string"`
}

func NewConfiguredEngine(routes []Route, aliases []Alias, health *Health, keys map[string]string) (*Engine, error) {
	var engine *Engine
	var err error
	if len(routes) == 0 {
		engine = &Engine{Health: NewHealth(nil)}
	} else {
		engine, err = NewEngine(routes)
		if err != nil {
			return nil, err
		}
	}
	engine.aliases = map[string]Alias{}
	engine.healthKeys = keys
	routeSet := map[string]Route{}
	for _, r := range routes {
		routeSet[r.ID] = r
	}
	for _, a := range aliases {
		if a.ID == "" || len(a.Candidates) == 0 || a.MinQualityRank < 0 || a.MinQualityRank > 5 {
			return nil, errors.New("invalid alias")
		}
		if _, ok := engine.aliases[a.ID]; ok {
			return nil, errors.New("duplicate alias")
		}
		if a.Strategy != "priority" && a.Strategy != "lowest-cost" && a.Strategy != "latency" {
			return nil, errors.New("invalid strategy")
		}
		seen := map[string]bool{}
		for _, id := range a.Candidates {
			if _, ok := routeSet[id]; !ok || seen[id] {
				return nil, errors.New("invalid candidate reference")
			}
			seen[id] = true
		}
		for _, rule := range a.Rules {
			if rule.ID == "" || rule.Priority < 0 || rule.Require.MinQualityRank < 0 || rule.Require.MinQualityRank > 5 {
				return nil, errors.New("invalid rule")
			}
		}
		engine.aliases[a.ID] = a
	}
	if health != nil {
		for _, r := range routes {
			key := keys[r.Provider]
			if key == "" {
				return nil, errors.New("missing provider account identity")
			}
			limit := r.MaxConcurrent
			if limit == 0 {
				limit = 4
			}
			health.Register(key, limit)
		}
		engine.Health = health
	}
	return engine, nil
}
func (e *Engine) AcquireProvider(id string, recovery bool) (func(bool), bool) {
	providerID := id
	if key := e.healthKeys[id]; key != "" {
		id = key
	}
	if e.externalCapacity == nil {
		return e.Health.Acquire(id, recovery)
	}
	release, allowed := e.externalCapacity(providerID)
	if !allowed {
		return nil, false
	}
	finish, allowed := e.Health.Acquire(id, recovery)
	if !allowed {
		release()
		return nil, false
	}
	var once sync.Once
	return func(success bool) { once.Do(func() { release(); finish(success) }) }, true
}

func (e *Engine) SetExternalCapacity(acquire func(string) (func(), bool)) {
	e.externalCapacity = acquire
}

func (e *Engine) UseSharedHealth(health *Health, keys map[string]string) error {
	for _, r := range e.routes {
		key := keys[r.Provider]
		if key == "" {
			if r.Enabled {
				return errors.New("missing legacy identity")
			}
			continue
		}
		limit := r.MaxConcurrent
		if limit == 0 {
			limit = 4
		}
		health.Register(key, limit)
	}
	e.healthKeys = keys
	e.Health = health
	return nil
}
func (e *Engine) Routes() []Route { return append([]Route(nil), e.routes...) }
func (e *Engine) Aliases() []Alias {
	result := make([]Alias, 0, len(e.aliases))
	for _, a := range e.aliases {
		result = append(result, a)
	}
	sort.Slice(result, func(i, j int) bool { return result[i].ID < result[j].ID })
	return result
}
func contains(values []string, value string) bool {
	for _, v := range values {
		if v == value {
			return true
		}
	}
	return false
}
func optionalBool(value *bool, want bool) bool { return value == nil || *value == want }
func ruleMatches(r Rule, req domain.ImageRequest, facts Requirements) bool {
	w := r.When
	return (len(w.Task) == 0 || contains(w.Task, req.Naumi.Task)) && (len(w.Quality) == 0 || contains(w.Quality, req.Quality)) && (len(w.Resolution) == 0 || contains(w.Resolution, facts.Resolution)) && optionalBool(w.NeedsEdit, facts.NeedsEdit) && optionalBool(w.NeedsText, facts.NeedsText) && optionalBool(w.PreserveIdentity, facts.PreserveIdentity) && optionalBool(w.NativeResolution, req.Naumi.NativeResolution)
}
func (e *Engine) configuredRequirements(req domain.ImageRequest, facts Requirements) (Requirements, *Alias, error) {
	if e.aliases == nil {
		return facts, nil, nil
	}
	a, ok := e.aliases[req.Model]
	if !ok {
		return facts, nil, errors.New("unknown model alias")
	}
	if a.MinQualityRank > facts.MinQualityRank {
		facts.MinQualityRank = a.MinQualityRank
	}
	var chosen *Rule
	for i := range a.Rules {
		r := &a.Rules[i]
		if ruleMatches(*r, req, facts) && (chosen == nil || r.Priority > chosen.Priority) {
			chosen = r
		}
	}
	if len(a.Rules) > 0 && chosen == nil {
		return facts, nil, errors.New("no routing rule matches")
	}
	if chosen != nil {
		c := chosen.Require
		facts.PreserveIdentity = facts.PreserveIdentity || c.PreserveIdentity
		facts.NeedsText = facts.NeedsText || c.TextAccuracy
		facts.NeedsEdit = facts.NeedsEdit || c.Edit
		facts.NeedsNativeResolution = req.Naumi.NativeResolution || c.NativeResolution
		if facts.Resolution == "4K" && facts.NeedsNativeResolution {
			facts.NeedsNative4K = true
		}
		if c.MinQualityRank > facts.MinQualityRank {
			facts.MinQualityRank = c.MinQualityRank
		}
	}
	return facts, &a, nil
}
func sortConfigured(routes []Route, a *Alias) error {
	if a == nil {
		return nil
	}
	if a.Strategy == "lowest-cost" {
		currency := ""
		for _, r := range routes {
			if r.CostCurrency == "" || r.EstimatedCostMicros < 1 {
				return errors.New("comparable monetary cost missing")
			}
			if currency != "" && currency != r.CostCurrency {
				return errors.New("cost currencies differ")
			}
			currency = r.CostCurrency
		}
	}
	order := map[string]int{}
	for i, id := range a.Candidates {
		order[id] = i
	}
	sort.SliceStable(routes, func(i, j int) bool {
		switch a.Strategy {
		case "priority":
			if order[routes[i].ID] != order[routes[j].ID] {
				return order[routes[i].ID] < order[routes[j].ID]
			}
		case "lowest-cost":
			if routes[i].EstimatedCostMicros != routes[j].EstimatedCostMicros {
				return routes[i].EstimatedCostMicros < routes[j].EstimatedCostMicros
			}
		case "latency":
			if routes[i].ExpectedLatencyMS != routes[j].ExpectedLatencyMS {
				return routes[i].ExpectedLatencyMS < routes[j].ExpectedLatencyMS
			}
		}
		return routes[i].ID < routes[j].ID
	})
	return nil
}
