package provider

import (
	"bytes"
	"context"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"image"
	_ "image/jpeg"
	_ "image/png"
	"io"
	"net/http"
	"net/url"
	"regexp"
	"strconv"
	"strings"
	"time"

	"github.com/JesstLe/naumi-router/internal/domain"
	"github.com/JesstLe/naumi-router/internal/routing"
)

const (
	falQueueBaseURL     = "https://queue.fal.run"
	maxFalJSONBytes     = 64 << 20
	maxImageHeaderBytes = 2 << 20
)

var falRequestIDPattern = regexp.MustCompile(`^[A-Za-z0-9_-]{1,128}$`)

var allowedFalModels = map[string]struct{}{
	"openai/gpt-image-2.5/flare/text-to-image":    {},
	"openai/gpt-image-2.5/sunburst/text-to-image": {},
}

type Fal struct {
	ConfiguredModels  map[string]bool
	MediaClient       *http.Client
	Key               string
	BaseURL           string
	Client            *http.Client
	PollInterval      time.Duration
	AllowedMediaHosts map[string]bool
}

type falInput struct {
	Prompt       string `json:"prompt"`
	ImageSize    any    `json:"image_size"`
	Quality      string `json:"quality"`
	NumImages    int    `json:"num_images"`
	OutputFormat string `json:"output_format"`
	SyncMode     bool   `json:"sync_mode"`
}

type falSubmitResponse struct {
	RequestID string `json:"request_id"`
}

type falStatusResponse struct {
	Status    string `json:"status"`
	RequestID string `json:"request_id"`
	Error     string `json:"error"`
	ErrorType string `json:"error_type"`
}

type falResult struct {
	Images []falImage `json:"images"`
}

type falImage struct {
	URL         string `json:"url"`
	Width       int    `json:"width"`
	Height      int    `json:"height"`
	ContentType string `json:"content_type"`
}

func NewFal(key string) *Fal {
	return &Fal{
		Key:          key,
		BaseURL:      falQueueBaseURL,
		Client:       &http.Client{Timeout: 45 * time.Second},
		PollInterval: time.Second,
	}
}

func (f *Fal) Generate(ctx context.Context, route routing.Route, request domain.ImageRequest) (domain.ImageResponse, error) {
	if f.Key == "" {
		return domain.ImageResponse{}, fallbackSafeError(errors.New("FAL_KEY is not configured"))
	}
	_, legacyAllowed := allowedFalModels[route.UpstreamModel]
	if (f.ConfiguredModels == nil && !legacyAllowed) || (f.ConfiguredModels != nil && !f.ConfiguredModels[route.UpstreamModel]) {
		return domain.ImageResponse{}, fallbackSafeError(fmt.Errorf("unsupported fal model %q", route.UpstreamModel))
	}

	imageSize, expectedWidth, expectedHeight, err := falImageSize(request.Size)
	if err != nil {
		return domain.ImageResponse{}, fallbackSafeError(err)
	}
	if request.Naumi.Resolution == "2K" || request.Naumi.Resolution == "4K" {
		target := 2048
		if request.Naumi.Resolution == "4K" {
			target = 3840
		}
		longEdge := expectedWidth
		if expectedHeight > longEdge {
			longEdge = expectedHeight
		}
		if longEdge < target {
			width := ((expectedWidth*target/longEdge + 15) / 16) * 16
			height := ((expectedHeight*target/longEdge + 15) / 16) * 16
			imageSize, expectedWidth, expectedHeight, err = falImageSize(fmt.Sprintf("%dx%d", width, height))
			if err != nil {
				return domain.ImageResponse{}, fallbackSafeError(err)
			}
		}
	}
	quality, err := falQuality(route.UpstreamQuality, request.Quality)
	if err != nil {
		return domain.ImageResponse{}, fallbackSafeError(err)
	}
	count := 1
	if request.N != nil {
		count = *request.N
	}
	input := falInput{
		Prompt:       request.Prompt,
		ImageSize:    imageSize,
		Quality:      quality,
		NumImages:    count,
		OutputFormat: "png",
		SyncMode:     request.ResponseFormat == "b64_json",
	}

	var submit falSubmitResponse
	if request.Execution != nil {
		submit.RequestID = request.Execution.TaskID
	}
	submitURL := f.endpoint(route.UpstreamModel)
	status := http.StatusOK
	if submit.RequestID == "" {
		status, err = f.doJSON(ctx, http.MethodPost, submitURL, input, &submit)
		if err != nil {
			return domain.ImageResponse{}, &AttemptError{Err: fmt.Errorf("submit fal request: %w", err), FallbackSafe: false}
		}
		if status < 200 || status >= 300 {
			safe := rejectedSubmission(status)
			return domain.ImageResponse{}, &AttemptError{
				Err:          fmt.Errorf("fal submit returned HTTP %d", status),
				FallbackSafe: safe,
			}
		}
		if !falRequestIDPattern.MatchString(submit.RequestID) {
			return domain.ImageResponse{}, &AttemptError{Err: errors.New("fal returned an invalid request id"), FallbackSafe: false}
		}
		if err := SubmissionCheckpoint(request, submit.RequestID); err != nil {
			return domain.ImageResponse{}, &AttemptError{Err: errors.New("paid submission checkpoint failed"), FallbackSafe: false}
		}
	}

	if err := f.waitForCompletion(ctx, route.UpstreamModel, submit.RequestID); err != nil {
		return domain.ImageResponse{}, &AttemptError{Err: err, FallbackSafe: false}
	}

	var result falResult
	resultURL := f.requestEndpoint(route.UpstreamModel, submit.RequestID)
	status, err = f.doJSON(ctx, http.MethodGet, resultURL, nil, &result)
	if err != nil {
		return domain.ImageResponse{}, &AttemptError{Err: fmt.Errorf("fetch fal result: %w", err), FallbackSafe: false}
	}
	if status < 200 || status >= 300 {
		return domain.ImageResponse{}, &AttemptError{Err: fmt.Errorf("fal result returned HTTP %d", status), FallbackSafe: false}
	}
	if len(result.Images) != count {
		return domain.ImageResponse{}, &AttemptError{
			Err:          fmt.Errorf("fal returned %d images, expected %d", len(result.Images), count),
			FallbackSafe: false,
		}
	}

	data := make([]domain.ImageData, 0, len(result.Images))
	for _, output := range result.Images {
		item, transformErr := f.transformImage(ctx, output, request, expectedWidth, expectedHeight)
		if transformErr != nil {
			return domain.ImageResponse{}, &AttemptError{Err: transformErr, FallbackSafe: false}
		}
		data = append(data, item)
	}
	return domain.ImageResponse{Created: time.Now().Unix(), Data: data}, nil
}

func (f *Fal) waitForCompletion(ctx context.Context, model, requestID string) error {
	interval := f.PollInterval
	if interval <= 0 {
		interval = time.Second
	}
	statusURL := f.requestEndpoint(model, requestID) + "/status"
	for {
		var queueStatus falStatusResponse
		status, err := f.doJSON(ctx, http.MethodGet, statusURL, nil, &queueStatus)
		if err != nil {
			return fmt.Errorf("poll fal request: %w", err)
		}
		if status < 200 || status >= 300 {
			return fmt.Errorf("fal status returned HTTP %d", status)
		}
		switch queueStatus.Status {
		case "COMPLETED":
			if queueStatus.Error != "" {
				return fmt.Errorf("fal request failed: %s", queueStatus.ErrorType)
			}
			return nil
		case "IN_QUEUE", "IN_PROGRESS":
		case "":
			return errors.New("fal status response omitted status")
		default:
			return fmt.Errorf("unknown fal status %q", queueStatus.Status)
		}

		timer := time.NewTimer(interval)
		select {
		case <-ctx.Done():
			if !timer.Stop() {
				<-timer.C
			}
			return ctx.Err()
		case <-timer.C:
		}
	}
}

func (f *Fal) transformImage(ctx context.Context, output falImage, request domain.ImageRequest, expectedWidth, expectedHeight int) (domain.ImageData, error) {
	if output.Width < 1 || output.Height < 1 || output.Width > 3840 || output.Height > 3840 || int64(output.Width)*int64(output.Height) > 8_294_400 {
		return domain.ImageData{}, errors.New("fal returned invalid image dimensions")
	}
	if expectedWidth != 0 && (output.Width != expectedWidth || output.Height != expectedHeight) {
		return domain.ImageData{}, fmt.Errorf("fal returned %dx%d, expected %dx%d", output.Width, output.Height, expectedWidth, expectedHeight)
	}

	item := domain.ImageData{RevisedPrompt: request.Prompt}
	if request.ResponseFormat == "b64_json" {
		payload, err := decodeDataURI(output.URL)
		if err != nil {
			return domain.ImageData{}, fmt.Errorf("decode fal data URI: %w", err)
		}
		if err := validateImageBytes(payload, output.Width, output.Height); err != nil {
			return domain.ImageData{}, err
		}
		item.B64JSON = base64.StdEncoding.EncodeToString(payload)
		return item, nil
	}

	parsed, err := url.Parse(output.URL)
	if err != nil || parsed.Scheme != "https" || !f.mediaHostAllowed(parsed.Hostname()) {
		return domain.ImageData{}, errors.New("fal returned an untrusted media URL")
	}
	if err := f.validateRemoteImage(ctx, output.URL, output.Width, output.Height); err != nil {
		return domain.ImageData{}, err
	}
	item.URL = output.URL
	return item, nil
}

func (f *Fal) validateRemoteImage(ctx context.Context, mediaURL string, expectedWidth, expectedHeight int) error {
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, mediaURL, nil)
	if err != nil {
		return fmt.Errorf("create media verification request: %w", err)
	}
	client := f.MediaClient
	if client == nil {
		client = f.httpClient()
	}
	response, err := client.Do(req)
	if err != nil {
		return fmt.Errorf("download fal image header: %w", err)
	}
	defer response.Body.Close()
	if response.StatusCode < 200 || response.StatusCode >= 300 {
		return fmt.Errorf("fal media download returned HTTP %d", response.StatusCode)
	}
	config, _, err := image.DecodeConfig(io.LimitReader(response.Body, maxImageHeaderBytes))
	if err != nil {
		return fmt.Errorf("decode fal image header: %w", err)
	}
	if config.Width != expectedWidth || config.Height != expectedHeight {
		return fmt.Errorf("fal media is %dx%d, metadata claimed %dx%d", config.Width, config.Height, expectedWidth, expectedHeight)
	}
	return nil
}

func (f *Fal) doJSON(ctx context.Context, method, endpoint string, input, output any) (int, error) {
	var body io.Reader
	if input != nil {
		encoded, err := json.Marshal(input)
		if err != nil {
			return 0, err
		}
		body = bytes.NewReader(encoded)
	}
	req, err := http.NewRequestWithContext(ctx, method, endpoint, body)
	if err != nil {
		return 0, err
	}
	req.Header.Set("Authorization", "Key "+f.Key)
	if input != nil {
		req.Header.Set("Content-Type", "application/json")
	}
	response, err := f.httpClient().Do(req)
	if err != nil {
		return 0, err
	}
	defer response.Body.Close()
	limited := io.LimitReader(response.Body, maxFalJSONBytes)
	if response.StatusCode < 200 || response.StatusCode >= 300 {
		_, _ = io.Copy(io.Discard, limited)
		return response.StatusCode, nil
	}
	if output == nil {
		_, _ = io.Copy(io.Discard, limited)
		return response.StatusCode, nil
	}
	if err := json.NewDecoder(limited).Decode(output); err != nil {
		return response.StatusCode, err
	}
	return response.StatusCode, nil
}

func (f *Fal) endpoint(model string) string {
	return strings.TrimRight(f.baseURL(), "/") + "/" + model
}

func (f *Fal) requestEndpoint(model, requestID string) string {
	return f.endpoint(model) + "/requests/" + url.PathEscape(requestID)
}

func (f *Fal) baseURL() string {
	if f.BaseURL != "" {
		return f.BaseURL
	}
	return falQueueBaseURL
}

func (f *Fal) httpClient() *http.Client {
	if f.Client != nil {
		return f.Client
	}
	return http.DefaultClient
}

func (f *Fal) mediaHostAllowed(host string) bool {
	if f.AllowedMediaHosts[host] {
		return true
	}
	return host == "fal.media" || strings.HasSuffix(host, ".fal.media")
}

func falImageSize(size string) (value any, width, height int, err error) {
	switch strings.ToLower(size) {
	case "1k":
		width, height = 1024, 1024
	case "2k":
		width, height = 2048, 2048
	case "4k":
		width, height = 3840, 2160
	default:
		parts := strings.Split(strings.ToLower(size), "x")
		if len(parts) != 2 {
			return nil, 0, 0, errors.New("fal requires WIDTHxHEIGHT or a 1k, 2k, 4k preset")
		}
		width, err = strconv.Atoi(parts[0])
		if err != nil {
			return nil, 0, 0, errors.New("invalid fal image width")
		}
		height, err = strconv.Atoi(parts[1])
		if err != nil {
			return nil, 0, 0, errors.New("invalid fal image height")
		}
	}

	pixels := int64(width) * int64(height)
	longEdge, shortEdge := width, height
	if height > width {
		longEdge, shortEdge = height, width
	}
	if width%16 != 0 || height%16 != 0 || longEdge > 3840 || shortEdge < 1 || float64(longEdge)/float64(shortEdge) > 3 || pixels < 655_360 || pixels > 8_294_400 {
		return nil, 0, 0, errors.New("image size is outside fal GPT Image 2.5 limits")
	}
	return map[string]int{"width": width, "height": height}, width, height, nil
}

func falQuality(configured, requested string) (string, error) {
	quality := configured
	if quality == "" {
		quality = requested
	}
	if quality == "standard" {
		quality = "medium"
	}
	switch quality {
	case "auto", "low", "medium", "high", "xhigh", "max":
		return quality, nil
	default:
		return "", fmt.Errorf("unsupported fal quality %q", quality)
	}
}

func fallbackSafeError(err error) error {
	return &AttemptError{Err: fmt.Errorf("%w: %v", ErrFallbackSafe, err), FallbackSafe: true}
}

func decodeDataURI(value string) ([]byte, error) {
	const marker = ";base64,"
	index := strings.Index(value, marker)
	if !strings.HasPrefix(value, "data:image/") || index < 0 {
		return nil, errors.New("expected a base64 image data URI")
	}
	decoded, err := base64.StdEncoding.DecodeString(value[index+len(marker):])
	if err != nil {
		return nil, err
	}
	return decoded, nil
}

func validateImageBytes(payload []byte, expectedWidth, expectedHeight int) error {
	config, _, err := image.DecodeConfig(bytes.NewReader(payload))
	if err != nil {
		return fmt.Errorf("decode fal image: %w", err)
	}
	if config.Width != expectedWidth || config.Height != expectedHeight {
		return fmt.Errorf("fal image is %dx%d, metadata claimed %dx%d", config.Width, config.Height, expectedWidth, expectedHeight)
	}
	return nil
}
