package provider

import (
	"bytes"
	"context"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"image"
	"io"
	"mime/multipart"
	"net/http"
	"net/url"
	"strings"
	"time"

	"github.com/JesstLe/naumi-router/internal/domain"
	"github.com/JesstLe/naumi-router/internal/routing"
)

// OpenAIImages uses a single paid synchronous POST. Unknown outcomes never
// permit resubmission, regardless of whether an upstream accepts the key header.
type OpenAIImages struct {
	Key, BaseURL string
	Client       *http.Client
	TrustedHTTP  bool // Set only by the server's exact-origin allowlist, never by request fields.
}

func (a *OpenAIImages) Identity() string { return credentialIdentity(a.BaseURL, a.Key) }

func (a *OpenAIImages) Generate(ctx context.Context, route routing.Route, request domain.ImageRequest) (domain.ImageResponse, error) {
	endpoint, err := url.Parse(a.BaseURL)
	if err != nil || (endpoint.Scheme != "https" && !(a.TrustedHTTP && endpoint.Scheme == "http")) || endpoint.Host == "" || endpoint.User != nil || endpoint.RawQuery != "" || endpoint.Fragment != "" || a.Key == "" {
		return domain.ImageResponse{}, fallbackSafeError(errors.New("invalid configured OpenAI Images endpoint"))
	}
	// Generic OpenAI sizes are authoritative; higher native tiers require a
	// provider-specific adapter, rather than silently sending a 1K paid request.
	if (request.Naumi.Resolution == "2K" || request.Naumi.Resolution == "4K") && route.ResolutionMap[request.Naumi.Resolution] == "" {
		return domain.ImageResponse{}, fallbackSafeError(errors.New("generic adapter does not support resolution tiers"))
	}
	quality := request.Quality
	if route.UpstreamQuality != "" {
		quality = route.UpstreamQuality
	}
	count := 1
	if request.N != nil {
		count = *request.N
	}
	fields := map[string]any{"model": route.UpstreamModel, "prompt": request.Prompt, "n": count, "size": request.Size, "quality": quality}
	if mapped := route.ResolutionMap[request.Naumi.Resolution]; mapped != "" {
		fields["size"] = mapped
	}
	if !strings.HasPrefix(route.UpstreamModel, "gpt-image") && route.UpstreamModel != "chatgpt-image-latest" {
		fields["response_format"] = "b64_json"
	}
	var body bytes.Buffer
	contentType, path := "application/json", "/images/generations"
	if len(request.ReferenceImages) == 0 {
		err = json.NewEncoder(&body).Encode(fields)
	} else {
		path = "/images/edits"
		writer := multipart.NewWriter(&body)
		for key, value := range fields {
			if err = writer.WriteField(key, fmt.Sprint(value)); err != nil {
				break
			}
		}
		if err == nil {
			for i, reference := range request.ReferenceImages {
				ext := ".png"
				if reference.MimeType == "image/jpeg" {
					ext = ".jpg"
				}
				if reference.MimeType == "image/webp" {
					ext = ".webp"
				}
				part, e := writer.CreateFormFile("image[]", fmt.Sprintf("reference-%d%s", i, ext))
				if e != nil {
					err = e
					break
				}
				if _, err = part.Write(reference.Bytes); err != nil {
					break
				}
			}
		}
		if err == nil && request.Mask != nil {
			if !route.SupportsMask {
				return domain.ImageResponse{}, fallbackSafeError(errors.New("masked edits are not supported by this route"))
			}
			part, e := writer.CreateFormFile("mask", "mask.png")
			if e != nil {
				err = e
			} else {
				_, err = part.Write(request.Mask.Bytes)
			}
		}
		closeErr := writer.Close()
		if err == nil {
			err = closeErr
		}
		contentType = writer.FormDataContentType()
	}
	if err != nil {
		return domain.ImageResponse{}, fallbackSafeError(errors.New("cannot encode image request"))
	}
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, strings.TrimRight(a.BaseURL, "/")+path, &body)
	if err != nil {
		return domain.ImageResponse{}, fallbackSafeError(err)
	}
	req.Header.Set("Authorization", "Bearer "+a.Key)
	req.Header.Set("Content-Type", contentType)
	if request.Execution != nil {
		req.Header.Set("Idempotency-Key", request.Execution.AttemptKey)
	}
	client := a.Client
	if client == nil {
		client = &http.Client{Timeout: 115 * time.Second, CheckRedirect: func(*http.Request, []*http.Request) error { return http.ErrUseLastResponse }}
	}
	res, err := client.Do(req)
	if err != nil {
		return domain.ImageResponse{}, &AttemptError{Err: errors.New("OpenAI Images submission outcome unknown")}
	}
	defer res.Body.Close()
	if res.StatusCode < 200 || res.StatusCode >= 300 {
		return domain.ImageResponse{}, &AttemptError{Err: fmt.Errorf("OpenAI Images HTTP %d", res.StatusCode), FallbackSafe: rejectedSubmission(res.StatusCode)}
	}
	const maxResponse = 96 << 20
	data, err := io.ReadAll(io.LimitReader(res.Body, maxResponse+1))
	var response domain.ImageResponse
	if err != nil || len(data) > maxResponse || json.Unmarshal(data, &response) != nil || len(response.Data) != count {
		return domain.ImageResponse{}, &AttemptError{Err: errors.New("paid image result is invalid")}
	}
	for _, result := range response.Data {
		decoded, e := base64.StdEncoding.DecodeString(result.B64JSON)
		if e != nil || len(decoded) == 0 {
			return domain.ImageResponse{}, &AttemptError{Err: errors.New("provider must return base64 image results")}
		}
		config, _, e := image.DecodeConfig(bytes.NewReader(decoded))
		if e != nil || config.Width < 1 || config.Height < 1 || int64(config.Width)*int64(config.Height) > 16_777_216 {
			return domain.ImageResponse{}, &AttemptError{Err: errors.New("invalid provider image")}
		}
		if request.Naumi.NativeResolution && request.Naumi.Resolution == "2K" && (max(config.Width, config.Height) < 2048 || min(config.Width, config.Height) < 1024) || request.Naumi.NativeResolution && request.Naumi.Resolution == "4K" && (max(config.Width, config.Height) < 3840 || min(config.Width, config.Height) < 2160) {
			return domain.ImageResponse{}, &AttemptError{Err: errors.New("paid native image size does not match the configured tier")}
		}
	}
	return response, nil
}
