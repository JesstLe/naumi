package provider

import (
	"context"
	"encoding/base64"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"sync/atomic"
	"testing"

	"github.com/JesstLe/naumi-router/internal/domain"
	"github.com/JesstLe/naumi-router/internal/routing"
)

func TestOpenAIImagesJSONAndMultipartMatchGPTImageContract(t *testing.T) {
	data := testPNG(t, 1024, 1024)
	var calls atomic.Int32
	server := httptest.NewTLSServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		calls.Add(1)
		if r.Header.Get("Idempotency-Key") != "stable-key" {
			t.Error("missing attempt key")
		}
		if r.URL.Path == "/v1/images/edits" {
			if err := r.ParseMultipartForm(2 << 20); err != nil {
				t.Error(err)
			}
			defer r.MultipartForm.RemoveAll()
			if r.FormValue("response_format") != "" || r.FormValue("quality") != "medium" || len(r.MultipartForm.File["image[]"]) != 1 {
				t.Error("bad multipart contract")
			}
		} else {
			var body map[string]any
			_ = json.NewDecoder(r.Body).Decode(&body)
			if _, ok := body["response_format"]; ok {
				t.Error("GPT image rejects legacy response_format")
			}
			if body["model"] != "gpt-image-1" || body["quality"] != "medium" {
				t.Error("bad generation contract")
			}
		}
		_ = json.NewEncoder(w).Encode(domain.ImageResponse{Data: []domain.ImageData{{B64JSON: base64.StdEncoding.EncodeToString(data)}}})
	}))
	defer server.Close()
	a := &OpenAIImages{Key: "fixture", BaseURL: server.URL + "/v1", Client: server.Client()}
	n := 1
	request := domain.ImageRequest{Prompt: "product", Quality: "medium", Size: "1024x1024", N: &n, Execution: &domain.Execution{AttemptKey: "stable-key"}}
	for _, edit := range []bool{false, true} {
		if edit {
			request.ReferenceImages = []domain.ReferenceImage{{Bytes: data, MimeType: "image/png"}}
		}
		if _, err := a.Generate(context.Background(), routing.Route{UpstreamModel: "gpt-image-1"}, request); err != nil {
			t.Fatal(err)
		}
	}
	if calls.Load() != 2 {
		t.Fatal("extra paid call")
	}
	request.Naumi.Resolution = "2K"
	if _, err := a.Generate(context.Background(), routing.Route{UpstreamModel: "gpt-image-1"}, request); err == nil || !CanFallback(err) {
		t.Fatal("unsupported native tier accepted")
	}
	if calls.Load() != 2 {
		t.Fatal("paid unsupported tier")
	}
}

func TestOpenAIImagesUnknownSubmissionNeverRetries(t *testing.T) {
	var calls atomic.Int32
	server := httptest.NewTLSServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) { calls.Add(1); w.WriteHeader(503) }))
	defer server.Close()
	a := &OpenAIImages{Key: "fixture", BaseURL: server.URL, Client: server.Client()}
	n := 1
	_, err := a.Generate(context.Background(), routing.Route{UpstreamModel: "gpt-image-1"}, domain.ImageRequest{Prompt: "product", Quality: "medium", Size: "1024x1024", N: &n})
	if err == nil || CanFallback(err) || calls.Load() != 1 {
		t.Fatalf("unsafe retry/fallback: %v calls=%d", err, calls.Load())
	}
}

func TestOpenAIImagesForwardsMaskedEdit(t *testing.T) {
	data := testPNG(t, 1024, 1024)
	server := httptest.NewTLSServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if err := r.ParseMultipartForm(4 << 20); err != nil {
			t.Fatal(err)
		}
		if len(r.MultipartForm.File["mask"]) != 1 {
			t.Error("mask was not forwarded to the selected supplier")
		}
		_ = json.NewEncoder(w).Encode(domain.ImageResponse{Data: []domain.ImageData{{B64JSON: base64.StdEncoding.EncodeToString(data)}}})
	}))
	defer server.Close()
	a := &OpenAIImages{Key: "fixture", BaseURL: server.URL, Client: server.Client()}
	n := 1
	mask := domain.ReferenceImage{Bytes: data, MimeType: "image/png"}
	_, err := a.Generate(context.Background(), routing.Route{UpstreamModel: "gpt-image-1", SupportsMask: true}, domain.ImageRequest{Prompt: "product", Quality: "medium", Size: "1024x1024", N: &n, ReferenceImages: []domain.ReferenceImage{mask}, Mask: &mask})
	if err != nil {
		t.Fatal(err)
	}
}

func TestOpenAIImagesHTTPRequiresOperatorTrust(t *testing.T) {
	data := testPNG(t, 1024, 1024)
	var calls atomic.Int32
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		calls.Add(1)
		_ = json.NewEncoder(w).Encode(domain.ImageResponse{Data: []domain.ImageData{{B64JSON: base64.StdEncoding.EncodeToString(data)}}})
	}))
	defer server.Close()
	n := 1
	input := domain.ImageRequest{Prompt: "fixture", Quality: "medium", Size: "1024x1024", N: &n}
	a := &OpenAIImages{Key: "fixture", BaseURL: server.URL, Client: server.Client()}
	if _, err := a.Generate(context.Background(), routing.Route{UpstreamModel: "fixture"}, input); err == nil || calls.Load() != 0 {
		t.Fatal("untrusted HTTP called")
	}
	a.TrustedHTTP = true
	if _, err := a.Generate(context.Background(), routing.Route{UpstreamModel: "fixture"}, input); err != nil || calls.Load() != 1 {
		t.Fatalf("operator-trusted HTTP failed: %v", err)
	}
}

func TestConfiguredOpenAIImagesNativeMappingAndPaidMismatch(t *testing.T) {
	var calls atomic.Int32
	var tooSmall atomic.Bool
	native := testPNG(t, 2048, 2048)
	small := testPNG(t, 1024, 1024)
	server := httptest.NewTLSServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		calls.Add(1)
		var body map[string]any
		_ = json.NewDecoder(r.Body).Decode(&body)
		if body["size"] != "2048x2048" || body["model"] != "compatible-native-image" {
			t.Error("native mapped parameter was not sent")
		}
		data := native
		if tooSmall.Load() {
			data = small
		}
		_ = json.NewEncoder(w).Encode(domain.ImageResponse{Data: []domain.ImageData{{B64JSON: base64.StdEncoding.EncodeToString(data)}}})
	}))
	defer server.Close()
	adapter := &OpenAIImages{Key: "fixture", BaseURL: server.URL + "/v1", Client: server.Client()}
	route := routing.Route{UpstreamModel: "compatible-native-image", ResolutionMap: map[string]string{"2K": "2048x2048"}}
	request := domain.ImageRequest{Model: "registered-native", Prompt: "product", Size: "1024x1024", Quality: "high", Naumi: domain.RoutingOptions{Resolution: "2K", NativeResolution: true}}
	if _, err := adapter.Generate(context.Background(), route, request); err != nil {
		t.Fatal(err)
	}
	tooSmall.Store(true)
	if _, err := adapter.Generate(context.Background(), route, request); err == nil || CanFallback(err) {
		t.Fatal("paid size mismatch must stay unresolved and never permit another paid route")
	}
	if calls.Load() != 2 {
		t.Fatal("extra native paid submission")
	}
}
