package provider

import (
	"net"
	"net/url"
	"os"
	"strings"
)

// Only explicitly approved server-side origins may bypass direct DNS pinning.
func ApprovedModelProxy(target *url.URL) *url.URL {
	if target == nil || target.Scheme != "https" || target.User != nil {
		return nil
	}
	allowed := false
	for _, origin := range strings.FieldsFunc(os.Getenv("NAUMI_MODEL_PROXY_ORIGINS"), func(r rune) bool { return r == ',' || r == ' ' || r == '\n' }) {
		if origin == target.Scheme+"://"+target.Host {
			allowed = true
			break
		}
	}
	if !allowed {
		return nil
	}
	p, err := url.Parse(os.Getenv("NAUMI_MODEL_PROXY_URL"))
	if err != nil || p.Hostname() == "" || (p.Scheme != "http" && p.Scheme != "https") || p.RawQuery != "" || p.Fragment != "" {
		return nil
	}
	return p
}

func ApprovedProxyAddress(address string) bool {
	p, err := url.Parse(os.Getenv("NAUMI_MODEL_PROXY_URL"))
	if err != nil || p.Hostname() == "" {
		return false
	}
	port := p.Port()
	if port == "" {
		if p.Scheme == "https" {
			port = "443"
		} else {
			port = "80"
		}
	}
	return address == net.JoinHostPort(p.Hostname(), port)
}

func modelProxyConfigured() bool {
	return os.Getenv("NAUMI_MODEL_PROXY_URL") != "" && os.Getenv("NAUMI_MODEL_PROXY_ORIGINS") != ""
}
