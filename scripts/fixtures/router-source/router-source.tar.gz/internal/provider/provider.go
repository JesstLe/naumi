package provider

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"errors"

	"github.com/JesstLe/naumi-router/internal/domain"
	"github.com/JesstLe/naumi-router/internal/routing"
)

var ErrFallbackSafe = errors.New("provider failure is safe to route elsewhere")

type AttemptError struct {
	Err          error
	FallbackSafe bool
	Receipt      *domain.GenerationReceipt
}

func (e *AttemptError) Error() string {
	return e.Err.Error()
}

func (e *AttemptError) Unwrap() error {
	return e.Err
}

func CanFallback(err error) bool {
	var attemptError *AttemptError
	return errors.As(err, &attemptError) && attemptError.FallbackSafe
}

func ReceiptFromError(err error) *domain.GenerationReceipt {
	var attemptError *AttemptError
	if errors.As(err, &attemptError) {
		return attemptError.Receipt
	}
	return nil
}

type Generator interface {
	Generate(context.Context, routing.Route, domain.ImageRequest) (domain.ImageResponse, error)
}

type Registry map[string]Generator

// Identity binds recovery to the same account/endpoint without storing secrets.
func Identity(generator Generator) string {
	if identified, ok := generator.(interface{ Identity() string }); ok {
		return identified.Identity()
	}
	return ""
}

func credentialIdentity(endpoint, key string) string {
	hash := sha256.Sum256([]byte(endpoint + "\x00" + key))
	return hex.EncodeToString(hash[:])
}

func (a *APIMart) Identity() string { return credentialIdentity(a.baseURL(), a.Key) }
func (f *Fal) Identity() string     { return credentialIdentity(f.baseURL(), f.Key) }

func rejectedSubmission(status int) bool {
	// Timeout/conflict responses do not prove that a paid task was rejected.
	return status == 400 || status == 401 || status == 403 || status == 404 || status == 422 || status == 429
}

func SubmissionCheckpoint(request domain.ImageRequest, taskID string) error {
	if request.Execution != nil && request.Execution.Submitted != nil {
		return request.Execution.Submitted(taskID)
	}
	return nil
}
