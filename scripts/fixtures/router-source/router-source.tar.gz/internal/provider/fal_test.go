package provider

import (
	"bytes"
	"context"
	"encoding/base64"
	"encoding/json"
	"image"
	"image/color"
	"image/png"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync/atomic"
	"testing"
	"time"

	"github.com/JesstLe/naumi-router/internal/domain"
	"github.com/JesstLe/naumi-router/internal/routing"
)

func TestFalGenerateUsesQueueAndValidatesImage(t *testing.T) {
	pngBytes := testPNG(t, 1024, 1024)
	dataURI := "data:image/png;base64," + base64.StdEncoding.EncodeToString(pngBytes)
	var statusCalls atomic.Int32

	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if got, want := r.Header.Get("Authorization"), "Key test-fal-key"; got != want {
			t.Errorf("authorization = %q, want %q", got, want)
		}
		switch {
		case r.Method == http.MethodPost && r.URL.Path == "/openai/gpt-image-2.5/flare/text-to-image":
			var input falInput
			if err := json.NewDecoder(r.Body).Decode(&input); err != nil {
				t.Fatalf("decode fal input: %v", err)
			}
			if got, want := input.Quality, "medium"; got != want {
				t.Errorf("quality = %q, want %q", got, want)
			}
			if !input.SyncMode {
				t.Error("expected sync_mode for b64_json response")
			}
			writeTestJSON(t, w, falSubmitResponse{RequestID: "request_123"})
		case r.Method == http.MethodGet && strings.HasSuffix(r.URL.Path, "/request_123/status"):
			if statusCalls.Add(1) == 1 {
				writeTestJSON(t, w, falStatusResponse{Status: "IN_QUEUE", RequestID: "request_123"})
				return
			}
			writeTestJSON(t, w, falStatusResponse{Status: "COMPLETED", RequestID: "request_123"})
		case r.Method == http.MethodGet && strings.HasSuffix(r.URL.Path, "/request_123"):
			writeTestJSON(t, w, falResult{Images: []falImage{{
				URL: dataURI, Width: 1024, Height: 1024, ContentType: "image/png",
			}}})
		default:
			http.NotFound(w, r)
		}
	}))
	defer server.Close()

	client := NewFal("test-fal-key")
	client.BaseURL = server.URL
	client.Client = server.Client()
	client.PollInterval = time.Millisecond

	response, err := client.Generate(context.Background(), testFalRoute(), testFalRequest())
	if err != nil {
		t.Fatalf("Generate returned error: %v", err)
	}
	if got, want := len(response.Data), 1; got != want {
		t.Fatalf("image count = %d, want %d", got, want)
	}
	if response.Data[0].B64JSON == "" {
		t.Fatal("expected b64_json output")
	}
}

func TestFalGenerateRejectsDimensionMismatchWithoutFallback(t *testing.T) {
	pngBytes := testPNG(t, 512, 512)
	dataURI := "data:image/png;base64," + base64.StdEncoding.EncodeToString(pngBytes)
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch {
		case r.Method == http.MethodPost:
			writeTestJSON(t, w, falSubmitResponse{RequestID: "request_456"})
		case strings.HasSuffix(r.URL.Path, "/status"):
			writeTestJSON(t, w, falStatusResponse{Status: "COMPLETED", RequestID: "request_456"})
		default:
			writeTestJSON(t, w, falResult{Images: []falImage{{
				URL: dataURI, Width: 512, Height: 512, ContentType: "image/png",
			}}})
		}
	}))
	defer server.Close()

	client := NewFal("test-fal-key")
	client.BaseURL = server.URL
	client.Client = server.Client()
	client.PollInterval = time.Millisecond

	_, err := client.Generate(context.Background(), testFalRoute(), testFalRequest())
	if err == nil {
		t.Fatal("expected dimension validation error")
	}
	if CanFallback(err) {
		t.Fatal("accepted paid request must not be automatically submitted elsewhere")
	}
}

func TestFalClientErrorBeforeAcceptanceAllowsFallback(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		w.WriteHeader(http.StatusUnprocessableEntity)
	}))
	defer server.Close()

	client := NewFal("test-fal-key")
	client.BaseURL = server.URL
	client.Client = server.Client()

	_, err := client.Generate(context.Background(), testFalRoute(), testFalRequest())
	if err == nil {
		t.Fatal("expected fal submit error")
	}
	if !CanFallback(err) {
		t.Fatal("explicit pre-acceptance 4xx should allow another eligible route")
	}
}

func testFalRoute() routing.Route {
	return routing.Route{
		ID:                    "fal-flare-medium",
		Provider:              "fal",
		UpstreamModel:         "openai/gpt-image-2.5/flare/text-to-image",
		UpstreamQuality:       "medium",
		Enabled:               true,
		Healthy:               true,
		EstimatedCostMicroUSD: 25_950,
		ExpectedLatencyMS:     20_000,
		QualityRank:           2,
		MaxPixels:             8_294_400,
		TextAccuracy:          true,
		Native4K:              true,
	}
}

func testFalRequest() domain.ImageRequest {
	one := 1
	return domain.ImageRequest{
		Model:          "naumi-image-standard",
		Prompt:         "A product photo",
		N:              &one,
		Quality:        "medium",
		Size:           "1024x1024",
		ResponseFormat: "b64_json",
		Naumi:          domain.RoutingOptions{TextAccuracy: "auto"},
	}
}

func testPNG(t *testing.T, width, height int) []byte {
	t.Helper()
	canvas := image.NewRGBA(image.Rect(0, 0, width, height))
	canvas.Set(0, 0, color.RGBA{R: 255, A: 255})
	var buffer bytes.Buffer
	if err := png.Encode(&buffer, canvas); err != nil {
		t.Fatalf("encode PNG: %v", err)
	}
	return buffer.Bytes()
}

func writeTestJSON(t *testing.T, w http.ResponseWriter, value any) {
	t.Helper()
	w.Header().Set("Content-Type", "application/json")
	if err := json.NewEncoder(w).Encode(value); err != nil {
		t.Fatalf("encode JSON: %v", err)
	}
}
