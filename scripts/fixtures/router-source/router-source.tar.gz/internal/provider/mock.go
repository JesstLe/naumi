package provider

// Mock has no paid account, but still has a stable execution identity.

import (
	"context"
	"fmt"
	"time"

	"github.com/JesstLe/naumi-router/internal/domain"
	"github.com/JesstLe/naumi-router/internal/routing"
)

// A valid one-pixel transparent PNG. The mock adapter proves the end-to-end
// response shape without calling an external service.
const transparentPNG = "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII="

type Mock struct {
	FailRoutes map[string]bool
}

func (m *Mock) Identity() string { return "mock" }

func (m *Mock) Generate(_ context.Context, route routing.Route, request domain.ImageRequest) (domain.ImageResponse, error) {
	if m.FailRoutes[route.ID] {
		return domain.ImageResponse{}, &AttemptError{
			Err:          fmt.Errorf("%w: mock route unavailable", ErrFallbackSafe),
			FallbackSafe: true,
		}
	}

	count := 1
	if request.N != nil {
		count = *request.N
	}
	data := make([]domain.ImageData, 0, count)
	for range count {
		item := domain.ImageData{RevisedPrompt: request.Prompt}
		if request.ResponseFormat == "url" {
			item.URL = "data:image/png;base64," + transparentPNG
		} else {
			item.B64JSON = transparentPNG
		}
		data = append(data, item)
	}
	return domain.ImageResponse{Created: time.Now().Unix(), Data: data}, nil
}
