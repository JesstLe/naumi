package provider

import (
	"context"
	"encoding/base64"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync/atomic"
	"testing"
	"time"

	"github.com/JesstLe/naumi-router/internal/domain"
	"github.com/JesstLe/naumi-router/internal/routing"
)

func TestAcceptedProviderTasksRecoverByGETOnly(t *testing.T) {
	for _, name := range []string{"apimart", "fal"} {
		t.Run(name, func(t *testing.T) {
			data := testPNG(t, 1024, 1024)
			var posts atomic.Int32
			var server *httptest.Server
			server = httptest.NewTLSServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				if r.Method == http.MethodPost {
					posts.Add(1)
					w.WriteHeader(500)
					return
				}
				w.Header().Set("Content-Type", "application/json")
				switch {
				case strings.HasSuffix(r.URL.Path, "/media.png"):
					_, _ = w.Write(data)
				case strings.HasPrefix(r.URL.Path, "/v1/tasks/"):
					_ = json.NewEncoder(w).Encode(map[string]any{"code": 200, "data": map[string]any{"id": "task_saved", "status": "completed", "cost": 0.021, "result": map[string]any{"images": []any{map[string]any{"url": []string{server.URL + "/media.png"}}}}}})
				case strings.HasSuffix(r.URL.Path, "/status"):
					_ = json.NewEncoder(w).Encode(falStatusResponse{Status: "COMPLETED", RequestID: "task_saved"})
				default:
					_ = json.NewEncoder(w).Encode(falResult{Images: []falImage{{URL: "data:image/png;base64," + base64.StdEncoding.EncodeToString(data), Width: 1024, Height: 1024}}})
				}
			}))
			defer server.Close()
			n := 1
			request := domain.ImageRequest{Prompt: "product", Size: "1024x1024", Quality: "medium", N: &n, ResponseFormat: "b64_json", Execution: &domain.Execution{AttemptKey: "same-key", TaskID: "task_saved", Submitted: func(string) error { t.Error("recovery attempted a new submission checkpoint"); return nil }}}
			var adapter Generator
			var route routing.Route
			if name == "apimart" {
				adapter = &APIMart{Key: "fixture", BaseURL: server.URL, Client: server.Client(), MediaClient: server.Client(), PollInterval: time.Millisecond}
				route = routing.Route{UpstreamModel: "gpt-image-2.5-ext"}
			} else {
				adapter = &Fal{Key: "fixture", BaseURL: server.URL, Client: server.Client(), PollInterval: time.Millisecond}
				route = testFalRoute()
			}
			response, err := adapter.Generate(context.Background(), route, request)
			if err != nil || len(response.Data) != 1 || posts.Load() != 0 {
				t.Fatalf("recovery resubmitted or failed: %v posts=%d", err, posts.Load())
			}
		})
	}
}
