package provider

import (
	"net/url"
	"testing"
)

func TestProxyOriginIsolationAndAPIMartBase(t *testing.T) {
	t.Setenv("NAUMI_MODEL_PROXY_URL", "http://127.0.0.1:7897")
	t.Setenv("NAUMI_MODEL_PROXY_ORIGINS", "https://api.apimart.ai")
	for _, raw := range []string{"http://api.apimart.ai", "https://api.apimart.ai.evil.test", "https://127.0.0.1", "https://api.apimart.ai@evil.test"} {
		u, _ := url.Parse(raw)
		if ApprovedModelProxy(u) != nil {
			t.Fatalf("unapproved origin accepted %s", raw)
		}
	}
	u, _ := url.Parse("https://api.apimart.ai/v1/models")
	if ApprovedModelProxy(u) == nil {
		t.Fatal("approved origin missing proxy")
	}
	for _, base := range []string{"https://api.apimart.ai", "https://api.apimart.ai/v1", "https://api.apimart.ai/v1/"} {
		if (&APIMart{BaseURL: base}).baseURL() != "https://api.apimart.ai" {
			t.Fatal("APIMart version duplicated")
		}
	}
}
