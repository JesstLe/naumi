package provider

import (
	"bytes"
	"context"
	"crypto/rand"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"image"
	"io"
	"net"
	"net/http"
	"net/url"
	"regexp"
	"strconv"
	"strings"
	"time"

	"github.com/JesstLe/naumi-router/internal/domain"
	"github.com/JesstLe/naumi-router/internal/routing"
)

const (
	apimartBaseURL         = "https://api.apimart.ai"
	apimartResponseVersion = "2026-07-27"
	maxAPIMartJSONBytes    = 2 << 20
	maxAPIMartImageBytes   = 64 << 20
)

var apimartTaskIDPattern = regexp.MustCompile(`^[A-Za-z0-9_-]{1,128}$`)

type APIMart struct {
	ConfiguredModels map[string]bool
	Key              string
	BaseURL          string
	Client           *http.Client
	MediaClient      *http.Client
	PollInterval     time.Duration
}

type apimartInput struct {
	Model      string   `json:"model"`
	Version    string   `json:"version"`
	Prompt     string   `json:"prompt"`
	Size       string   `json:"size"`
	Resolution string   `json:"resolution"`
	N          int      `json:"n"`
	ImageURLs  []string `json:"image_urls,omitempty"`
}

type apimartSubmitEnvelope struct {
	Code int             `json:"code"`
	Data json.RawMessage `json:"data"`
}

type apimartSubmittedTask struct {
	ID     string `json:"id"`
	TaskID string `json:"task_id"`
	Status string `json:"status"`
}

type apimartTaskEnvelope struct {
	Code int         `json:"code"`
	Data apimartTask `json:"data"`
}

type apimartTask struct {
	ID          string            `json:"id"`
	Status      string            `json:"status"`
	Progress    int               `json:"progress"`
	Cost        *float64          `json:"cost"`
	CreditsCost float64           `json:"credits_cost"`
	Result      apimartTaskResult `json:"result"`
	Error       apimartTaskError  `json:"error"`
}

type apimartTaskResult struct {
	Images []apimartTaskImages `json:"images"`
}

type apimartTaskImages struct {
	URLs      []string `json:"url"`
	ExpiresAt int64    `json:"expires_at"`
}

type apimartTaskError struct {
	Message string `json:"message"`
}

type apimartSize struct {
	AspectRatio string
	Resolution  string
	Width       int
	Height      int
}

func NewAPIMart(key string) *APIMart {
	return &APIMart{
		Key:          key,
		BaseURL:      apimartBaseURL,
		Client:       &http.Client{Timeout: 45 * time.Second},
		PollInterval: 3 * time.Second,
	}
}

func (a *APIMart) Generate(ctx context.Context, route routing.Route, request domain.ImageRequest) (domain.ImageResponse, error) {
	if a.Key == "" {
		return domain.ImageResponse{}, fallbackSafeError(errors.New("APIMART_KEY is not configured"))
	}
	if (a.ConfiguredModels == nil && route.UpstreamModel != "gpt-image-2.5-ext") || (a.ConfiguredModels != nil && !a.ConfiguredModels[route.UpstreamModel]) {
		return domain.ImageResponse{}, fallbackSafeError(fmt.Errorf("unsupported APIMart model %q", route.UpstreamModel))
	}
	version := route.UpstreamVersion
	if version == "" {
		version = "flare"
	}
	if a.ConfiguredModels == nil && version != "flare" && version != "sunburst" {
		return domain.ImageResponse{}, fallbackSafeError(fmt.Errorf("unsupported APIMart version %q", version))
	}

	size, err := apimartImageSize(request.Size)
	if err != nil {
		return domain.ImageResponse{}, fallbackSafeError(err)
	}
	if request.Naumi.Resolution != "" {
		size.Resolution = request.Naumi.Resolution
	}
	count := 1
	if request.N != nil {
		count = *request.N
	}
	payload := apimartInput{
		Model:      route.UpstreamModel,
		Version:    version,
		Prompt:     request.Prompt,
		Size:       size.AspectRatio,
		Resolution: size.Resolution,
		N:          count,
	}
	if len(request.ReferenceImages) > 0 {
		payload.ImageURLs = apimartReferenceDataURLs(request.ReferenceImages)
	}
	idempotencyKey := ""
	taskID := ""
	if request.Execution != nil {
		idempotencyKey = request.Execution.AttemptKey
		taskID = request.Execution.TaskID
	}
	if idempotencyKey == "" {
		idempotencyKey, err = newUUID()
		if err != nil {
			return domain.ImageResponse{}, fallbackSafeError(err)
		}
	}
	if taskID == "" {
		taskID, err = a.submit(ctx, payload, idempotencyKey)
		if err != nil {
			return domain.ImageResponse{}, err
		}
		if err := SubmissionCheckpoint(request, taskID); err != nil {
			return domain.ImageResponse{}, &AttemptError{Err: errors.New("paid submission checkpoint failed"), FallbackSafe: false}
		}
	}
	task, err := a.waitForCompletion(ctx, taskID)
	if err != nil {
		return domain.ImageResponse{}, err
	}

	urls := flattenAPIMartURLs(task.Result.Images)
	receipt := apimartReceipt(task)
	if len(urls) != count {
		return domain.ImageResponse{}, &AttemptError{
			Err:          fmt.Errorf("APIMart returned %d images, expected %d", len(urls), count),
			FallbackSafe: false,
			Receipt:      receipt,
		}
	}
	data := make([]domain.ImageData, 0, len(urls))
	for _, mediaURL := range urls {
		item, transformErr := a.transformImage(ctx, mediaURL, request, size)
		if transformErr != nil {
			return domain.ImageResponse{}, &AttemptError{Err: transformErr, FallbackSafe: false, Receipt: receipt}
		}
		data = append(data, item)
	}

	return domain.ImageResponse{
		Created: time.Now().Unix(),
		Data:    data,
		Receipt: receipt,
	}, nil
}

func apimartReferenceDataURLs(references []domain.ReferenceImage) []string {
	urls := make([]string, 0, len(references))
	for _, reference := range references {
		urls = append(urls, "data:"+reference.MimeType+";base64,"+base64.StdEncoding.EncodeToString(reference.Bytes))
	}
	return urls
}

func (a *APIMart) submit(ctx context.Context, input apimartInput, idempotencyKey string) (string, error) {
	endpoint := strings.TrimRight(a.baseURL(), "/") + "/v1/images/generations"
	var envelope apimartSubmitEnvelope
	status, err := a.doJSON(ctx, http.MethodPost, endpoint, input, &envelope, idempotencyKey)
	if err != nil {
		return "", &AttemptError{Err: fmt.Errorf("submit APIMart request: %w", err)}
	}
	if status >= 200 && status < 300 {
		taskID, err := parseAPIMartTaskID(envelope.Data)
		if err != nil {
			return "", &AttemptError{Err: err}
		}
		return taskID, nil
	}
	// No repeated POST after a network error or 5xx: the supplier's deduplication
	// window is not a durable execution guarantee. Known task IDs recover by GET.
	return "", &AttemptError{Err: fmt.Errorf("APIMart submit returned HTTP %d", status), FallbackSafe: rejectedSubmission(status)}
}

func (a *APIMart) waitForCompletion(ctx context.Context, taskID string) (apimartTask, error) {
	interval := a.PollInterval
	if interval <= 0 {
		interval = 3 * time.Second
	}
	endpoint := strings.TrimRight(a.baseURL(), "/") + "/v1/tasks/" + url.PathEscape(taskID)
	for {
		var envelope apimartTaskEnvelope
		status, err := a.doJSON(ctx, http.MethodGet, endpoint, nil, &envelope, "")
		if err != nil {
			return apimartTask{}, &AttemptError{Err: fmt.Errorf("poll APIMart task: %w", err), FallbackSafe: false}
		}
		if status < 200 || status >= 300 {
			return apimartTask{}, &AttemptError{Err: fmt.Errorf("APIMart task returned HTTP %d", status), FallbackSafe: false}
		}
		task := envelope.Data
		if task.ID == "" {
			task.ID = taskID
		}
		switch strings.ToLower(task.Status) {
		case "completed", "succeeded", "success":
			return task, nil
		case "failed", "cancelled", "canceled":
			message := strings.TrimSpace(task.Error.Message)
			if message == "" {
				message = "task failed"
			}
			// A failed status alone does not prove that the account was refunded.
			// Require an explicit zero-cost terminal receipt before switching.
			safe := task.Cost != nil && *task.Cost == 0 && task.CreditsCost == 0
			return apimartTask{}, &AttemptError{Err: fmt.Errorf("APIMart %s: %s", task.Status, message), FallbackSafe: safe, Receipt: apimartReceipt(task)}
		case "pending", "submitted", "processing", "running", "queued":
		case "":
			return apimartTask{}, &AttemptError{Err: errors.New("APIMart task response omitted status"), FallbackSafe: false}
		default:
			return apimartTask{}, &AttemptError{Err: fmt.Errorf("unknown APIMart task status %q", task.Status), FallbackSafe: false}
		}

		timer := time.NewTimer(interval)
		select {
		case <-ctx.Done():
			if !timer.Stop() {
				<-timer.C
			}
			return apimartTask{}, &AttemptError{Err: ctx.Err(), FallbackSafe: false}
		case <-timer.C:
		}
	}
}

func apimartReceipt(task apimartTask) *domain.GenerationReceipt {
	receipt := &domain.GenerationReceipt{Provider: "apimart", TaskID: task.ID, CreditsCost: task.CreditsCost, ReportedStatus: task.Status}
	if task.Cost != nil {
		receipt.CostUSD = *task.Cost
		receipt.CostReported = true
	}
	return receipt
}

func (a *APIMart) transformImage(ctx context.Context, mediaURL string, request domain.ImageRequest, expected apimartSize) (domain.ImageData, error) {
	parsed, err := url.Parse(mediaURL)
	if err != nil || parsed.Scheme != "https" || parsed.Hostname() == "" {
		return domain.ImageData{}, errors.New("APIMart returned an untrusted media URL")
	}
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, mediaURL, nil)
	if err != nil {
		return domain.ImageData{}, fmt.Errorf("create APIMart media request: %w", err)
	}
	response, err := a.mediaHTTPClient().Do(req)
	if err != nil {
		return domain.ImageData{}, fmt.Errorf("download APIMart image: %w", err)
	}
	defer response.Body.Close()
	if response.Request == nil || response.Request.URL == nil || response.Request.URL.Scheme != "https" || response.Request.URL.Hostname() == "" {
		return domain.ImageData{}, errors.New("APIMart media redirect left HTTPS")
	}
	if response.StatusCode < 200 || response.StatusCode >= 300 {
		return domain.ImageData{}, fmt.Errorf("APIMart media download returned HTTP %d", response.StatusCode)
	}
	payload, err := io.ReadAll(io.LimitReader(response.Body, maxAPIMartImageBytes+1))
	if err != nil {
		return domain.ImageData{}, fmt.Errorf("read APIMart image: %w", err)
	}
	if len(payload) > maxAPIMartImageBytes {
		return domain.ImageData{}, errors.New("APIMart image exceeds the 64 MiB limit")
	}
	config, _, err := image.DecodeConfig(bytes.NewReader(payload))
	if err != nil {
		return domain.ImageData{}, fmt.Errorf("decode APIMart image: %w", err)
	}
	if err := validateAPIMartDimensions(config.Width, config.Height, expected); err != nil {
		return domain.ImageData{}, err
	}

	item := domain.ImageData{RevisedPrompt: request.Prompt}
	if request.ResponseFormat == "b64_json" {
		item.B64JSON = base64.StdEncoding.EncodeToString(payload)
	} else {
		item.URL = mediaURL
	}
	return item, nil
}

func (a *APIMart) doJSON(ctx context.Context, method, endpoint string, input, output any, idempotencyKey string) (int, error) {
	var body io.Reader
	if input != nil {
		encoded, err := json.Marshal(input)
		if err != nil {
			return 0, err
		}
		body = bytes.NewReader(encoded)
	}
	req, err := http.NewRequestWithContext(ctx, method, endpoint, body)
	if err != nil {
		return 0, err
	}
	req.Header.Set("Authorization", "Bearer "+a.Key)
	if input != nil {
		req.Header.Set("Content-Type", "application/json")
		req.Header.Set("X-APIMart-Response-Version", apimartResponseVersion)
		req.Header.Set("Idempotency-Key", idempotencyKey)
	}
	response, err := a.httpClient().Do(req)
	if err != nil {
		return 0, err
	}
	defer response.Body.Close()
	limited := io.LimitReader(response.Body, maxAPIMartJSONBytes)
	if response.StatusCode < 200 || response.StatusCode >= 300 {
		_, _ = io.Copy(io.Discard, limited)
		return response.StatusCode, nil
	}
	if err := json.NewDecoder(limited).Decode(output); err != nil {
		return response.StatusCode, err
	}
	return response.StatusCode, nil
}

func parseAPIMartTaskID(raw json.RawMessage) (string, error) {
	trimmed := bytes.TrimSpace(raw)
	if len(trimmed) == 0 {
		return "", errors.New("APIMart submission omitted task data")
	}
	var taskID string
	switch trimmed[0] {
	case '{':
		var task apimartSubmittedTask
		if err := json.Unmarshal(trimmed, &task); err != nil {
			return "", fmt.Errorf("decode APIMart task: %w", err)
		}
		taskID = task.ID
		if taskID == "" {
			taskID = task.TaskID
		}
	case '[':
		var tasks []apimartSubmittedTask
		if err := json.Unmarshal(trimmed, &tasks); err != nil {
			return "", fmt.Errorf("decode APIMart tasks: %w", err)
		}
		if len(tasks) != 1 {
			return "", errors.New("APIMart submission returned an unexpected task count")
		}
		taskID = tasks[0].TaskID
		if taskID == "" {
			taskID = tasks[0].ID
		}
	default:
		return "", errors.New("APIMart submission returned invalid task data")
	}
	if !apimartTaskIDPattern.MatchString(taskID) {
		return "", errors.New("APIMart returned an invalid task id")
	}
	return taskID, nil
}

func apimartImageSize(value string) (apimartSize, error) {
	if strings.EqualFold(value, "1k") {
		return apimartSize{AspectRatio: "1:1", Resolution: "1K", Width: 1024, Height: 1024}, nil
	}
	if strings.EqualFold(value, "2k") {
		return apimartSize{AspectRatio: "1:1", Resolution: "2K", Width: 2048, Height: 2048}, nil
	}
	if strings.EqualFold(value, "4k") {
		return apimartSize{AspectRatio: "16:9", Resolution: "4K", Width: 3840, Height: 2160}, nil
	}
	parts := strings.Split(strings.ToLower(value), "x")
	if len(parts) != 2 {
		return apimartSize{}, errors.New("APIMart requires 1k, 2k, 4k, or WIDTHxHEIGHT")
	}
	width, err := strconv.Atoi(parts[0])
	if err != nil {
		return apimartSize{}, errors.New("invalid APIMart image width")
	}
	height, err := strconv.Atoi(parts[1])
	if err != nil {
		return apimartSize{}, errors.New("invalid APIMart image height")
	}
	ratio, ok := closestAPIMartRatio(width, height)
	if !ok {
		return apimartSize{}, errors.New("image aspect ratio is unsupported by APIMart GPT Image 2.5 Ext")
	}
	longEdge := width
	if height > longEdge {
		longEdge = height
	}
	resolution := "1K"
	if longEdge > 1536 {
		resolution = "2K"
	}
	if longEdge > 2560 {
		resolution = "4K"
	}
	return apimartSize{AspectRatio: ratio, Resolution: resolution, Width: width, Height: height}, nil
}

func closestAPIMartRatio(width, height int) (string, bool) {
	type ratio struct {
		name string
		w    int
		h    int
	}
	ratios := []ratio{{"1:1", 1, 1}, {"16:9", 16, 9}, {"9:16", 9, 16}, {"4:3", 4, 3}, {"3:4", 3, 4}, {"3:2", 3, 2}, {"2:3", 2, 3}, {"5:4", 5, 4}, {"4:5", 4, 5}, {"21:9", 21, 9}}
	actual := float64(width) / float64(height)
	bestName := ""
	bestDelta := 1.0
	for _, candidate := range ratios {
		delta := actual/(float64(candidate.w)/float64(candidate.h)) - 1
		if delta < 0 {
			delta = -delta
		}
		if delta < bestDelta {
			bestDelta = delta
			bestName = candidate.name
		}
	}
	return bestName, bestDelta <= 0.03
}

func validateAPIMartDimensions(width, height int, expected apimartSize) error {
	if width < 256 || height < 256 || width > 8192 || height > 8192 || int64(width)*int64(height) > 40_000_000 {
		return errors.New("APIMart returned invalid image dimensions")
	}
	actualRatio := float64(width) / float64(height)
	expectedRatio := float64(expected.Width) / float64(expected.Height)
	delta := actualRatio/expectedRatio - 1
	if delta < 0 {
		delta = -delta
	}
	if delta > 0.03 {
		return fmt.Errorf("APIMart returned aspect ratio %.3f, expected %.3f", actualRatio, expectedRatio)
	}
	longEdge := width
	if height > longEdge {
		longEdge = height
	}
	minimum := map[string]int{"1K": 900, "2K": 1800, "4K": 3500}[expected.Resolution]
	if longEdge < minimum {
		return fmt.Errorf("APIMart returned %dx%d, below the declared %s tier", width, height, expected.Resolution)
	}
	return nil
}

func flattenAPIMartURLs(groups []apimartTaskImages) []string {
	var urls []string
	for _, group := range groups {
		urls = append(urls, group.URLs...)
	}
	return urls
}

func newUUID() (string, error) {
	var value [16]byte
	if _, err := rand.Read(value[:]); err != nil {
		return "", err
	}
	value[6] = (value[6] & 0x0f) | 0x40
	value[8] = (value[8] & 0x3f) | 0x80
	encoded := make([]byte, 36)
	hex.Encode(encoded[0:8], value[0:4])
	encoded[8] = '-'
	hex.Encode(encoded[9:13], value[4:6])
	encoded[13] = '-'
	hex.Encode(encoded[14:18], value[6:8])
	encoded[18] = '-'
	hex.Encode(encoded[19:23], value[8:10])
	encoded[23] = '-'
	hex.Encode(encoded[24:36], value[10:16])
	return string(encoded), nil
}

func (a *APIMart) baseURL() string {
	if a.BaseURL != "" {
		return a.BaseURL
	}
	return apimartBaseURL
}

func (a *APIMart) httpClient() *http.Client {
	if a.Client != nil {
		return a.Client
	}
	return http.DefaultClient
}

func (a *APIMart) mediaHTTPClient() *http.Client {
	if a.MediaClient != nil {
		return a.MediaClient
	}
	transport := http.DefaultTransport.(*http.Transport).Clone()
	// API traffic may use HTTPS_PROXY, but media must dial the validated public
	// IP directly. Applying an environment proxy here would validate the proxy
	// address instead of the media destination and break SSRF protection.
	transport.Proxy = nil
	dialer := &net.Dialer{Timeout: 15 * time.Second, KeepAlive: 30 * time.Second}
	transport.DialContext = func(ctx context.Context, network, address string) (net.Conn, error) {
		host, port, err := net.SplitHostPort(address)
		if err != nil {
			return nil, err
		}
		addresses, err := net.DefaultResolver.LookupIPAddr(ctx, host)
		if err != nil {
			return nil, err
		}
		if len(addresses) == 0 {
			return nil, errors.New("media host resolved to no addresses")
		}
		for _, candidate := range addresses {
			if !isPublicIP(candidate.IP) {
				return nil, errors.New("media host resolved to a non-public address")
			}
		}
		return dialer.DialContext(ctx, network, net.JoinHostPort(addresses[0].IP.String(), port))
	}
	return &http.Client{
		Transport: transport,
		Timeout:   45 * time.Second,
		CheckRedirect: func(req *http.Request, via []*http.Request) error {
			if len(via) >= 5 {
				return errors.New("too many media redirects")
			}
			if req.URL.Scheme != "https" || req.URL.Hostname() == "" {
				return errors.New("media redirect must remain HTTPS")
			}
			return nil
		},
	}
}

func isPublicIP(ip net.IP) bool {
	return ip != nil && !ip.IsLoopback() && !ip.IsPrivate() && !ip.IsUnspecified() &&
		!ip.IsLinkLocalUnicast() && !ip.IsLinkLocalMulticast() && !ip.IsMulticast()
}
