package provider

import (
	"bytes"
	"context"
	"encoding/json"
	"net"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync"
	"testing"
	"time"

	"github.com/JesstLe/naumi-router/internal/domain"
	"github.com/JesstLe/naumi-router/internal/routing"
)

func TestAPIMartGenerateModernResponseAndReceipt(t *testing.T) {
	t.Parallel()

	imageBytes := testPNG(t, 1024, 1024)
	var server *httptest.Server
	server = httptest.NewTLSServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if strings.HasPrefix(r.URL.Path, "/v1/") && r.Header.Get("Authorization") != "Bearer test-key" {
			t.Fatalf("unexpected authorization header")
		}
		switch {
		case r.Method == http.MethodPost && r.URL.Path == "/v1/images/generations":
			if r.Header.Get("X-APIMart-Response-Version") != apimartResponseVersion {
				t.Fatalf("missing response version header")
			}
			if !strings.Contains(r.Header.Get("Idempotency-Key"), "-") {
				t.Fatalf("missing idempotency key")
			}
			var input apimartInput
			if err := json.NewDecoder(r.Body).Decode(&input); err != nil {
				t.Fatal(err)
			}
			if input.Model != "gpt-image-2.5-ext" || input.Version != "flare" || input.Size != "1:1" || input.Resolution != "1K" || input.N != 1 {
				t.Fatalf("unexpected input: %+v", input)
			}
			w.WriteHeader(http.StatusAccepted)
			_, _ = w.Write([]byte(`{"code":202,"data":{"id":"task_01TEST","status":"pending"}}`))
		case r.Method == http.MethodGet && r.URL.Path == "/v1/tasks/task_01TEST":
			_ = json.NewEncoder(w).Encode(map[string]any{
				"code": 200,
				"data": map[string]any{
					"id":           "task_01TEST",
					"status":       "completed",
					"cost":         0.0085,
					"credits_cost": 0.085,
					"result": map[string]any{"images": []any{
						map[string]any{"url": []string{server.URL + "/media/output.png"}},
					}},
				},
			})
		case r.Method == http.MethodGet && r.URL.Path == "/media/output.png":
			w.Header().Set("Content-Type", "image/png")
			_, _ = w.Write(imageBytes)
		default:
			http.NotFound(w, r)
		}
	}))
	defer server.Close()

	adapter := &APIMart{
		Key:          "test-key",
		BaseURL:      server.URL,
		Client:       server.Client(),
		MediaClient:  server.Client(),
		PollInterval: time.Millisecond,
	}
	count := 1
	response, err := adapter.Generate(context.Background(), routing.Route{
		UpstreamModel:   "gpt-image-2.5-ext",
		UpstreamVersion: "flare",
	}, domain.ImageRequest{
		Prompt:         "test prompt",
		Size:           "1024x1024",
		ResponseFormat: "b64_json",
		N:              &count,
	})
	if err != nil {
		t.Fatal(err)
	}
	if len(response.Data) != 1 || response.Data[0].B64JSON == "" {
		t.Fatalf("unexpected response: %+v", response)
	}
	if response.Receipt == nil || response.Receipt.Provider != "apimart" || response.Receipt.TaskID != "task_01TEST" || response.Receipt.CostUSD != 0.0085 {
		t.Fatalf("unexpected receipt: %+v", response.Receipt)
	}

	encoded, err := json.Marshal(response)
	if err != nil {
		t.Fatal(err)
	}
	if bytes.Contains(encoded, []byte("task_01TEST")) || bytes.Contains(encoded, []byte("0.0085")) {
		t.Fatalf("internal receipt leaked into public response: %s", encoded)
	}
}

func TestAPIMartMediaDoesNotUseAPIProxy(t *testing.T) {
	t.Setenv("HTTPS_PROXY", "http://127.0.0.1:17890")
	client := NewAPIMart("test-key").mediaHTTPClient()
	transport := client.Transport.(*http.Transport)
	if transport.Proxy != nil {
		t.Fatal("media must not inherit the API proxy")
	}
	for _, address := range []string{"127.0.0.1:443", "10.0.0.1:443", "[::1]:443", "169.254.169.254:443"} {
		conn, err := transport.DialContext(context.Background(), "tcp", address)
		if conn != nil {
			conn.Close()
		}
		if err == nil || !strings.Contains(err.Error(), "non-public") {
			t.Fatalf("private media destination %s not blocked: %v", address, err)
		}
	}
}

func TestAPIMartReferenceImagesUseDataURLs(t *testing.T) {
	references := []domain.ReferenceImage{
		{Bytes: []byte{0x89, 0x50, 0x4e, 0x47}, MimeType: "image/png"},
		{Bytes: []byte{0xff, 0xd8, 0xff}, MimeType: "image/jpeg"},
	}
	urls := apimartReferenceDataURLs(references)
	if len(urls) != 2 {
		t.Fatalf("got %d URLs, want 2", len(urls))
	}
	if got, want := urls[0], "data:image/png;base64,iVBORw=="; got != want {
		t.Fatalf("first URL = %q, want %q", got, want)
	}
	if got, want := urls[1], "data:image/jpeg;base64,/9j/"; got != want {
		t.Fatalf("second URL = %q, want %q", got, want)
	}
}

func TestAPIMartAmbiguousSubmitDoesNotRepeatPOST(t *testing.T) {
	t.Parallel()

	var mu sync.Mutex
	var keys []string
	server := httptest.NewTLSServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		mu.Lock()
		keys = append(keys, r.Header.Get("Idempotency-Key"))
		attempt := len(keys)
		mu.Unlock()
		if attempt == 1 {
			http.Error(w, "temporary", http.StatusInternalServerError)
			return
		}
		_, _ = w.Write([]byte(`{"code":202,"data":{"id":"task_RETRY","status":"pending"}}`))
	}))
	defer server.Close()

	adapter := &APIMart{Key: "test-key", BaseURL: server.URL, Client: server.Client()}
	taskID, err := adapter.submit(context.Background(), apimartInput{Model: "gpt-image-2.5-ext"}, "fixed-idempotency-key")
	if err == nil || CanFallback(err) || taskID != "" {
		t.Fatalf("ambiguous result must stop: task=%q err=%v", taskID, err)
	}
	mu.Lock()
	defer mu.Unlock()
	if len(keys) != 1 || keys[0] != "fixed-idempotency-key" {
		t.Fatalf("repeated an ambiguous paid POST: %#v", keys)
	}
}

func TestAPIMartConfirmedFailureIsFallbackSafe(t *testing.T) {
	t.Parallel()

	server := httptest.NewTLSServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		_ = json.NewEncoder(w).Encode(map[string]any{
			"code": 200,
			"data": map[string]any{
				"id":     "task_FAILED",
				"status": "failed",
				"cost":   0,
				"error":  map[string]string{"message": "generation failed"},
			},
		})
	}))
	defer server.Close()

	adapter := &APIMart{Key: "test-key", BaseURL: server.URL, Client: server.Client(), PollInterval: time.Millisecond}
	_, err := adapter.waitForCompletion(context.Background(), "task_FAILED")
	if err == nil || !CanFallback(err) {
		t.Fatalf("expected a fallback-safe terminal failure, got %v", err)
	}
}

func TestAPIMartUnknownSubmitOutcomeIsNotFallbackSafe(t *testing.T) {
	t.Parallel()

	adapter := &APIMart{
		Key:     "test-key",
		BaseURL: "https://127.0.0.1:1",
		Client:  &http.Client{Timeout: 100 * time.Millisecond},
	}
	_, err := adapter.submit(context.Background(), apimartInput{Model: "gpt-image-2.5-ext"}, "fixed-idempotency-key")
	if err == nil || CanFallback(err) {
		t.Fatalf("ambiguous submit outcome must not trigger another paid provider: %v", err)
	}
}

func TestAPIMartFailureWithoutZeroCostCannotFallback(t *testing.T) {
	for _, cost := range []any{nil, 0.02} {
		server := httptest.NewTLSServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			data := map[string]any{"id": "task_FAILED", "status": "failed"}
			if cost != nil {
				data["cost"] = cost
			}
			_ = json.NewEncoder(w).Encode(map[string]any{"code": 200, "data": data})
		}))
		adapter := &APIMart{Key: "test", BaseURL: server.URL, Client: server.Client(), PollInterval: time.Millisecond}
		_, err := adapter.waitForCompletion(context.Background(), "task_FAILED")
		server.Close()
		if err == nil || CanFallback(err) {
			t.Fatalf("cost=%v must require reconciliation, got %v", cost, err)
		}
	}
}

func TestAPIMartMediaIPPolicy(t *testing.T) {
	t.Parallel()
	tests := []struct {
		address string
		want    bool
	}{
		{address: "8.8.8.8", want: true},
		{address: "1.1.1.1", want: true},
		{address: "127.0.0.1", want: false},
		{address: "10.0.0.1", want: false},
		{address: "172.16.0.1", want: false},
		{address: "192.168.1.1", want: false},
		{address: "169.254.169.254", want: false},
		{address: "::1", want: false},
		{address: "fc00::1", want: false},
		{address: "fe80::1", want: false},
	}
	for _, test := range tests {
		t.Run(test.address, func(t *testing.T) {
			if got := isPublicIP(net.ParseIP(test.address)); got != test.want {
				t.Fatalf("isPublicIP(%q) = %v, want %v", test.address, got, test.want)
			}
		})
	}
}
