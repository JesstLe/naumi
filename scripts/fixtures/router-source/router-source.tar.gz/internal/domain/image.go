package domain

import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"regexp"
	"strings"
)

const MaxPromptBytes = 20_000

type ImageRequest struct {
	Model           string           `json:"model"`
	Prompt          string           `json:"prompt"`
	N               *int             `json:"n,omitempty"`
	Quality         string           `json:"quality,omitempty"`
	Size            string           `json:"size,omitempty"`
	ResponseFormat  string           `json:"response_format,omitempty"`
	Naumi           RoutingOptions   `json:"naumi,omitempty"`
	ExtraFields     json.RawMessage  `json:"extra_fields,omitempty"`
	ReferenceImages []ReferenceImage `json:"-"`
	Mask            *ReferenceImage  `json:"-"`
	Execution       *Execution       `json:"-"`
}

type Execution struct {
	AttemptKey string
	TaskID     string
	Submitted  func(string) error
}

// ReferenceImage is an in-memory edit input. It is never serialized into logs
// or API responses; provider adapters translate it into their native format.
type ReferenceImage struct {
	Bytes    []byte
	MimeType string
}

type RoutingOptions struct {
	ConfigDigest     string `json:"config_digest,omitempty"`
	OperationID      string `json:"operation_id,omitempty"`
	Resolution       string `json:"resolution,omitempty"`
	Task             string `json:"task,omitempty"`
	PreserveIdentity bool   `json:"preserve_identity,omitempty"`
	NativeResolution bool   `json:"native_resolution,omitempty"`
	TextAccuracy     string `json:"text_accuracy,omitempty"`
}

type ImageData struct {
	URL           string `json:"url,omitempty"`
	B64JSON       string `json:"b64_json,omitempty"`
	RevisedPrompt string `json:"revised_prompt,omitempty"`
}

type ImageResponse struct {
	Created int64              `json:"created"`
	Data    []ImageData        `json:"data"`
	Receipt *GenerationReceipt `json:"-"`
}

// GenerationReceipt is internal-only upstream billing telemetry. It is logged
// by the router and never exposed in the OpenAI-compatible response.
type GenerationReceipt struct {
	CostReported   bool
	Provider       string
	TaskID         string
	CostUSD        float64
	CreditsCost    float64
	ReportedStatus string
}

func (r *ImageRequest) ApplyDefaults() error {
	if err := r.applyExtraRoutingOptions(); err != nil {
		return err
	}
	if r.Model == "" {
		r.Model = "naumi-image-auto"
	}
	if r.Quality == "" {
		r.Quality = "auto"
	}
	if r.Size == "" {
		r.Size = "1024x1024"
	}
	if r.ResponseFormat == "" {
		r.ResponseFormat = "b64_json"
	}
	if r.Naumi.TextAccuracy == "" {
		r.Naumi.TextAccuracy = "auto"
	}
	if r.N == nil {
		one := 1
		r.N = &one
	}
	return nil
}

func (r *ImageRequest) applyExtraRoutingOptions() error {
	if len(r.ExtraFields) == 0 || bytes.Equal(bytes.TrimSpace(r.ExtraFields), []byte("null")) {
		return nil
	}
	var envelope struct {
		Naumi *RoutingOptions `json:"naumi"`
	}
	if err := json.Unmarshal(r.ExtraFields, &envelope); err != nil {
		return errors.New("extra_fields must be a JSON object")
	}
	options := envelope.Naumi
	if options == nil {
		var direct RoutingOptions
		if err := json.Unmarshal(r.ExtraFields, &direct); err != nil {
			return errors.New("extra_fields must contain routing options")
		}
		options = &direct
	}
	if r.Naumi.ConfigDigest != "" && options.ConfigDigest != "" && r.Naumi.ConfigDigest != options.ConfigDigest {
		return errors.New("configuration identities differ")
	}
	if r.Naumi.ConfigDigest == "" {
		r.Naumi.ConfigDigest = options.ConfigDigest
	}
	if !r.Naumi.NativeResolution {
		r.Naumi.NativeResolution = options.NativeResolution
	}
	if r.Naumi.TextAccuracy == "" {
		r.Naumi.TextAccuracy = options.TextAccuracy
	}
	if r.Naumi.OperationID == "" {
		r.Naumi.OperationID = options.OperationID
	}
	if r.Naumi.Resolution == "" {
		r.Naumi.Resolution = options.Resolution
	}
	if r.Naumi.Task == "" {
		r.Naumi.Task = options.Task
	}
	if !r.Naumi.PreserveIdentity {
		r.Naumi.PreserveIdentity = options.PreserveIdentity
	}
	return nil
}

func (r ImageRequest) Validate() error {
	if strings.TrimSpace(r.Prompt) == "" {
		return errors.New("prompt is required")
	}
	if len(r.Prompt) > MaxPromptBytes {
		return fmt.Errorf("prompt exceeds %d bytes", MaxPromptBytes)
	}
	if r.N == nil || *r.N < 1 || *r.N > 4 {
		return errors.New("n must be between 1 and 4")
	}
	if r.Naumi.ConfigDigest == "" && !oneOf(r.Model, "auto", "naumi-image-auto", "naumi-image-economy", "naumi-image-standard", "naumi-image-premium") {
		return errors.New("unsupported model alias")
	}
	if r.Naumi.ConfigDigest != "" && (!regexp.MustCompile(`^[a-f0-9]{64}$`).MatchString(r.Naumi.ConfigDigest) || !regexp.MustCompile(`^[A-Za-z0-9][A-Za-z0-9._:-]{0,99}$`).MatchString(r.Model)) {
		return errors.New("invalid configuration identity")
	}
	if !oneOf(r.Quality, "auto", "low", "medium", "high", "xhigh", "max", "standard") {
		return errors.New("unsupported quality")
	}
	if !oneOf(r.ResponseFormat, "b64_json", "url") {
		return errors.New("response_format must be b64_json or url")
	}
	if !oneOf(r.Naumi.TextAccuracy, "auto", "required", "best_effort") {
		return errors.New("naumi.text_accuracy must be auto, required, or best_effort")
	}
	if !oneOf(r.Naumi.Resolution, "", "1K", "2K", "4K") {
		return errors.New("naumi.resolution must be 1K, 2K, or 4K")
	}
	if !oneOf(r.Naumi.Task, "", "draft", "product", "detail", "layout") {
		return errors.New("unsupported naumi.task")
	}
	return nil
}

func oneOf(value string, allowed ...string) bool {
	for _, candidate := range allowed {
		if value == candidate {
			return true
		}
	}
	return false
}
