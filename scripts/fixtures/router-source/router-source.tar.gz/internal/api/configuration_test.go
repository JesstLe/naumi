package api

import (
	"bytes"
	"encoding/json"
	"image"
	"image/png"
	"net/http"
	"net/http/httptest"
	"path/filepath"
	"strings"
	"sync/atomic"
	"testing"

	"github.com/JesstLe/naumi-router/internal/configuration"
	"github.com/JesstLe/naumi-router/internal/routing"
)

const configurationSecret = "fixture-envelope-secret-independent-20261004"

func configuredFixture(t *testing.T, version uint64, endpoint, ref string) configuration.PreparedConfig {
	t.Helper()
	seal, err := configuration.SealCredential(configurationSecret, "supplier", ref, "fixture-account")
	if err != nil {
		t.Fatal(err)
	}
	r := routing.Route{ID: "upstream", Provider: "supplier", UpstreamModel: "gpt-image-2.5-ext", UpstreamVersion: "flare", Enabled: true, Healthy: true, QualityRank: 3, MaxPixels: 4096 * 4096, MaxConcurrent: 2, SupportsEdit: true, Native4K: true}
	p := configuration.PreparedConfig{ModelVersion: version, BillingVersion: 1, Config: configuration.Projection{Routes: []routing.Route{r}, Providers: []configuration.ProviderSpec{{ID: "supplier", Protocol: "apimart-images", BaseURL: endpoint, CredentialRef: ref, TimeoutMS: 120000, MaxConcurrent: 2}}, Aliases: []routing.Alias{{ID: "custom-image", Candidates: []string{"upstream"}, Strategy: "priority"}}}, Credentials: []configuration.SealedCredential{seal}}
	p.Digest, err = configuration.Digest(p)
	if err != nil {
		t.Fatal(err)
	}
	return p
}
func managementCall(t *testing.T, s *Server, token, method, path string, body any) *httptest.ResponseRecorder {
	t.Helper()
	raw, _ := json.Marshal(body)
	req := httptest.NewRequest(method, path, bytes.NewReader(raw))
	req.Header.Set("Authorization", "Bearer "+token)
	req.Header.Set("Content-Type", "application/json")
	out := httptest.NewRecorder()
	handler, err := s.ManagementHandler()
	if err != nil {
		t.Fatal(err)
	}
	handler.ServeHTTP(out, req)
	return out
}
func managedExecute(t *testing.T, s *Server, id, digest string) *httptest.ResponseRecorder {
	t.Helper()
	body := map[string]any{"model": "custom-image", "prompt": "product photo", "quality": "medium", "size": "1024x1024", "extra_fields": map[string]any{"naumi": map[string]any{"operation_id": id, "config_digest": digest}}}
	raw, _ := json.Marshal(body)
	req := httptest.NewRequest("POST", "/v1/images/generations", bytes.NewReader(raw))
	req.Header.Set("Authorization", "Bearer "+s.Token)
	req.Header.Set("Content-Type", "application/json")
	out := httptest.NewRecorder()
	s.Handler().ServeHTTP(out, req)
	return out
}
func TestManagementListenerHasSeparateCredentialAndExactEndpoints(t *testing.T) {
	supplier := httptest.NewTLSServer(http.HandlerFunc(func(http.ResponseWriter, *http.Request) { t.Error("simulation attempted a paid call") }))
	defer supplier.Close()
	manager, err := configuration.Open(t.TempDir(), configuration.Options{EnvelopeSecret: configurationSecret, TrustedOrigins: []string{supplier.URL}, HTTPClient: supplier.Client()})
	if err != nil {
		t.Fatal(err)
	}
	defer manager.Close()
	s := testServer(t, nil)
	s.Configurations = manager
	s.ManagementToken = "fixture-management-token-independent-20261004"
	input := configuredFixture(t, 1, supplier.URL, "credential-one")
	if w := managementCall(t, s, s.Token, "POST", "/internal/config/prepare", input); w.Code != 401 {
		t.Fatalf("generation token could prepare: %d", w.Code)
	}
	if w := managementCall(t, s, s.ManagementToken, "POST", "/internal/config/prepare", input); w.Code != 200 {
		t.Fatalf("prepare: %d %s", w.Code, w.Body.String())
	}
	activation := map[string]string{"id": "first", "expectedDigest": "", "digest": input.Digest}
	for i := 0; i < 2; i++ {
		if w := managementCall(t, s, s.ManagementToken, "POST", "/internal/config/activate", activation); w.Code != 200 {
			t.Fatalf("activate %d %s", w.Code, w.Body.String())
		}
	}
	if w := managementCall(t, s, s.ManagementToken, "GET", "/internal/config/publications/first", nil); w.Code != 200 || bytes.Contains(w.Body.Bytes(), []byte("ciphertext")) {
		t.Fatalf("status %d", w.Code)
	}
	snapshot, _ := manager.ByDigest(input.Digest)
	before, _ := json.Marshal(snapshot.Engine.Health.Snapshot())
	for i := 0; i < 3; i++ {
		simulation := map[string]any{"digest": input.Digest, "request": map[string]any{"model": "custom-image", "prompt": "product photo", "size": "1024x1024", "quality": "medium"}}
		if w := managementCall(t, s, s.ManagementToken, "POST", "/internal/config/simulate", simulation); w.Code != 200 {
			t.Fatalf("simulation: %d %s", w.Code, w.Body.String())
		}
	}
	after, _ := json.Marshal(snapshot.Engine.Health.Snapshot())
	if !bytes.Equal(before, after) {
		t.Fatal("simulation mutated account health")
	}
	if w := managementCall(t, s, s.ManagementToken, "POST", "/v1/images/generations", input); w.Code != 404 {
		t.Fatal("management listener exposes generation")
	}
	req := httptest.NewRequest("POST", "/internal/config/prepare", bytes.NewReader([]byte("{}")))
	req.Header.Set("Authorization", "Bearer "+s.Token)
	out := httptest.NewRecorder()
	s.Handler().ServeHTTP(out, req)
	if out.Code != 404 {
		t.Fatal("generation listener exposes management")
	}
	unknown := map[string]any{"digest": input.Digest, "modelVersion": 1, "billingVersion": 1, "config": input.Config, "credentials": input.Credentials, "script": "bad"}
	if w := managementCall(t, s, s.ManagementToken, "POST", "/internal/config/prepare", unknown); w.Code != 400 {
		t.Fatal("unknown field accepted")
	}
	activation["digest"] = strings.Repeat("a", 64)
	if w := managementCall(t, s, s.ManagementToken, "POST", "/internal/config/activate", activation); w.Code == 200 {
		t.Fatal("activation operation rebound")
	}
	s.ManagementToken = s.Token
	if _, err = s.ManagementHandler(); err == nil {
		t.Fatal("generation token reused for management")
	}
	s.ManagementToken = ""
	if _, err = s.ManagementHandler(); err == nil {
		t.Fatal("missing management token enabled listener")
	}
}
func TestConfigSwapKeepsAcceptedTaskAndOriginalAccountAfterRestart(t *testing.T) {
	var createsOld, createsNew, polls atomic.Int32
	var ready atomic.Bool
	var data bytes.Buffer
	if err := png.Encode(&data, image.NewNRGBA(image.Rect(0, 0, 1024, 1024))); err != nil {
		t.Fatal(err)
	}
	var old *httptest.Server
	old = httptest.NewTLSServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if strings.HasPrefix(r.URL.Path, "/v1/") && r.Header.Get("Authorization") != "Bearer fixture-account" {
			t.Error("old task used rotated credentials")
			w.WriteHeader(401)
			return
		}
		if r.Method == "POST" {
			var body struct {
				Model   string `json:"model"`
				Version string `json:"version"`
			}
			json.NewDecoder(r.Body).Decode(&body)
			if body.Model != "compatible-image-next" || body.Version != "next-v1" {
				t.Errorf("configuration was not used for actual request: model=%s version=%s", body.Model, body.Version)
			}
			createsOld.Add(1)
			w.WriteHeader(202)
			w.Write([]byte(`{"code":202,"data":{"id":"task_fixture","status":"pending"}}`))
			return
		}
		if r.URL.Path == "/v1/tasks/task_fixture" {
			polls.Add(1)
			if !ready.Load() {
				w.WriteHeader(502)
				return
			}
			json.NewEncoder(w).Encode(map[string]any{"code": 200, "data": map[string]any{"id": "task_fixture", "status": "completed", "result": map[string]any{"images": []any{map[string]any{"url": []string{old.URL + "/media/result.png"}}}}}})
			return
		}
		if r.URL.Path == "/media/result.png" {
			w.Header().Set("Content-Type", "image/png")
			w.Write(data.Bytes())
			return
		}
		http.NotFound(w, r)
	}))
	defer old.Close()
	replacement := httptest.NewTLSServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) { createsNew.Add(1); w.WriteHeader(500) }))
	defer replacement.Close()
	options := configuration.Options{EnvelopeSecret: configurationSecret, TrustedOrigins: []string{old.URL, replacement.URL}, HTTPClient: old.Client()}
	dir := filepath.Join(t.TempDir(), "configuration")
	manager, err := configuration.Open(dir, options)
	if err != nil {
		t.Fatal(err)
	}
	defer func() {
		if manager != nil {
			_ = manager.Close()
		}
	}()
	s := testServer(t, nil)
	s.Configurations = manager
	first := configuredFixture(t, 1, old.URL, "credential-one")
	first.Config.Routes[0].UpstreamModel = "compatible-image-next"
	first.Config.Routes[0].UpstreamVersion = "next-v1"
	first.Digest, _ = configuration.Digest(first)
	second := configuredFixture(t, 2, replacement.URL, "credential-two")
	rotated, err := configuration.SealCredential(configurationSecret, "supplier", "credential-two", "fixture-new-account-key")
	if err != nil {
		t.Fatal(err)
	}
	second.Credentials = []configuration.SealedCredential{rotated}
	if err = manager.Prepare(first); err != nil {
		t.Fatal(err)
	}
	if err = manager.Activate("first", "", first.Digest); err != nil {
		t.Fatal(err)
	}
	if w := managedExecute(t, s, "frozen-config-task", first.Digest); w.Code != 504 {
		t.Fatalf("accepted: %d %s", w.Code, w.Body.String())
	}
	if err = manager.Prepare(second); err != nil {
		t.Fatal(err)
	}
	if err = manager.Activate("second", first.Digest, second.Digest); err != nil {
		t.Fatal(err)
	}
	if err = manager.Close(); err != nil {
		t.Fatal(err)
	}
	manager, err = configuration.Open(dir, options)
	if err != nil {
		t.Fatal(err)
	}
	defer manager.Close()
	s.Configurations = manager
	ready.Store(true)
	if w := managedExecute(t, s, "frozen-config-task", first.Digest); w.Code != 200 {
		t.Fatalf("recovery: %d %s", w.Code, w.Body.String())
	}
	if createsOld.Load() != 1 || createsNew.Load() != 0 || polls.Load() != 2 {
		t.Fatalf("old create=%d replacement=%d polls=%d", createsOld.Load(), createsNew.Load(), polls.Load())
	}
	row, err := s.Store.Load("frozen-config-task")
	if err != nil || row.ConfigDigest != first.Digest || row.Attempts[0].CredentialRef != "credential-one" {
		t.Fatal("frozen configuration was lost")
	}
	if w := managedExecute(t, s, "frozen-config-task", second.Digest); w.Code != 409 {
		t.Fatal("existing operation changed version")
	}
	if w := managedExecute(t, s, "unprepared-config-task", strings.Repeat("f", 64)); w.Code != 422 {
		t.Fatal("unknown digest fell back to current")
	}
	if w := managedExecute(t, s, "new-config-task", second.Digest); w.Code != 504 {
		t.Fatalf("new task %d", w.Code)
	}
	if createsNew.Load() != 1 || createsOld.Load() != 1 {
		t.Fatal("new task did not use the new supplier exclusively")
	}
}

func TestConfiguredUnknownSubmissionNeverResubmitsAfterSwap(t *testing.T) {
	var calls atomic.Int32
	upstream := httptest.NewTLSServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		calls.Add(1)
		conn, _, err := w.(http.Hijacker).Hijack()
		if err == nil {
			conn.Close()
		}
	}))
	defer upstream.Close()
	manager, err := configuration.Open(t.TempDir(), configuration.Options{EnvelopeSecret: configurationSecret, TrustedOrigins: []string{upstream.URL}, HTTPClient: upstream.Client()})
	if err != nil {
		t.Fatal(err)
	}
	defer manager.Close()
	s := testServer(t, nil)
	s.Configurations = manager
	first := configuredFixture(t, 1, upstream.URL, "credential-one")
	second := configuredFixture(t, 2, upstream.URL, "credential-two")
	if err = manager.Prepare(first); err != nil {
		t.Fatal(err)
	}
	if w := managedExecute(t, s, "unknown-frozen-task", first.Digest); w.Code != 504 {
		t.Fatalf("unknown %d", w.Code)
	}
	if err = manager.Prepare(second); err != nil {
		t.Fatal(err)
	}
	if err = manager.Activate("replacement", "", second.Digest); err != nil {
		t.Fatal(err)
	}
	for i := 0; i < 3; i++ {
		if w := managedExecute(t, s, "unknown-frozen-task", first.Digest); w.Code != 504 {
			t.Fatalf("unknown resume %d", w.Code)
		}
	}
	if calls.Load() != 1 {
		t.Fatalf("uncertain submission repeated %d calls", calls.Load())
	}
}
