package api

import (
	"crypto/subtle"
	"encoding/json"
	"errors"
	"net/http"
	"strings"

	"github.com/JesstLe/naumi-router/internal/configuration"
	"github.com/JesstLe/naumi-router/internal/domain"
)

// This is a separate listener. The generation handler never registers these paths.
func (s *Server) ManagementHandler() (http.Handler, error) {
	if len(s.ManagementToken) < 32 || s.ManagementToken == s.Token || s.Configurations == nil {
		return nil, configuration.ErrInvalid
	}
	mux := http.NewServeMux()
	mux.HandleFunc("POST /internal/config/prepare", func(w http.ResponseWriter, r *http.Request) {
		var input configuration.PreparedConfig
		if !decodeConfiguration(w, r, &input) {
			return
		}
		if err := s.Configurations.Prepare(input); err != nil {
			configurationError(w, err)
			return
		}
		writeJSON(w, 200, map[string]string{"digest": input.Digest, "phase": "prepared"})
	})
	mux.HandleFunc("POST /internal/config/activate", func(w http.ResponseWriter, r *http.Request) {
		var input struct {
			ID             string `json:"id"`
			ExpectedDigest string `json:"expectedDigest"`
			Digest         string `json:"digest"`
		}
		if !decodeConfiguration(w, r, &input) {
			return
		}
		if err := s.Configurations.Activate(input.ID, input.ExpectedDigest, input.Digest); err != nil {
			configurationError(w, err)
			return
		}
		status, err := s.Configurations.Status(input.ID)
		if err != nil {
			configurationError(w, err)
			return
		}
		writeJSON(w, 200, status)
	})
	mux.HandleFunc("GET /internal/config/publications/{id}", func(w http.ResponseWriter, r *http.Request) {
		status, err := s.Configurations.Status(r.PathValue("id"))
		if err != nil {
			configurationError(w, err)
			return
		}
		writeJSON(w, 200, status)
	})
	mux.HandleFunc("GET /internal/config/state", func(w http.ResponseWriter, r *http.Request) {
		digest, err := s.Configurations.ActiveDigest()
		if err != nil {
			configurationError(w, err)
			return
		}
		writeJSON(w, 200, map[string]string{"digest": digest})
	})
	mux.HandleFunc("POST /internal/config/simulate", func(w http.ResponseWriter, r *http.Request) {
		var input struct {
			Digest  string              `json:"digest"`
			Request domain.ImageRequest `json:"request"`
		}
		if !decodeConfiguration(w, r, &input) {
			return
		}
		runtime, err := s.Configurations.ByDigest(input.Digest)
		if err != nil {
			configurationError(w, err)
			return
		}
		input.Request.Naumi.ConfigDigest = input.Digest
		if input.Request.ApplyDefaults() != nil || input.Request.Validate() != nil {
			configurationError(w, configuration.ErrInvalid)
			return
		}
		routes, _, err := runtime.Engine.Candidates(input.Request)
		if err != nil {
			writeJSON(w, 422, map[string]any{"digest": input.Digest, "eligible": []string{}, "code": "NO_ELIGIBLE_ROUTE"})
			return
		}
		ids := make([]string, 0, len(routes))
		for _, r := range routes {
			ids = append(ids, r.ID)
		}
		writeJSON(w, 200, map[string]any{"digest": input.Digest, "eligible": ids})
	})
	mux.HandleFunc("GET /internal/config/legacy", func(w http.ResponseWriter, r *http.Request) {
		projection, _, err := s.Configurations.ExportLegacy(s.Engine, s.Providers)
		if err != nil {
			configurationError(w, err)
			return
		}
		writeJSON(w, 200, projection)
	})
	mux.HandleFunc("GET /internal/config/legacy/credentials", func(w http.ResponseWriter, r *http.Request) {
		_, credentials, err := s.Configurations.ExportLegacy(s.Engine, s.Providers)
		if err != nil {
			configurationError(w, err)
			return
		}
		writeJSON(w, 200, map[string]any{"credentials": credentials})
	})
	handler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		provided := strings.TrimPrefix(r.Header.Get("Authorization"), "Bearer ")
		if provided == "" || subtle.ConstantTimeCompare([]byte(provided), []byte(s.ManagementToken)) != 1 {
			writeError(w, 401, "invalid management credential", "authentication_error", "invalid_api_key", "")
			return
		}
		mux.ServeHTTP(w, r)
	})
	return s.requestMetadata(handler), nil
}
func decodeConfiguration(w http.ResponseWriter, r *http.Request, value any) bool {
	if !strings.HasPrefix(r.Header.Get("Content-Type"), "application/json") {
		writeError(w, 415, "JSON required", "invalid_request_error", "invalid_content_type", "")
		return false
	}
	body := http.MaxBytesReader(w, r.Body, 512*1024)
	defer body.Close()
	decoder := json.NewDecoder(body)
	decoder.DisallowUnknownFields()
	if err := decoder.Decode(value); err != nil {
		var tooLarge *http.MaxBytesError
		if errors.As(err, &tooLarge) {
			writeError(w, 413, "configuration too large", "invalid_request_error", "request_too_large", "")
		} else {
			configurationError(w, configuration.ErrInvalid)
		}
		return false
	}
	if ensureSingleJSONValue(decoder) != nil {
		configurationError(w, configuration.ErrInvalid)
		return false
	}
	return true
}
func configurationError(w http.ResponseWriter, err error) {
	status, code := 503, "CONFIG_UNAVAILABLE"
	if errors.Is(err, configuration.ErrInvalid) {
		status, code = 400, "INVALID_CONFIG"
	}
	if errors.Is(err, configuration.ErrConflict) {
		status, code = 409, "CONFIG_CONFLICT"
	}
	if errors.Is(err, configuration.ErrNotFound) {
		status, code = 404, "CONFIG_NOT_FOUND"
	}
	writeError(w, status, "configuration operation could not be completed", "configuration_error", code, "")
}
