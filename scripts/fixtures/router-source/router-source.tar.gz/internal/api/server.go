package api

import (
	"bytes"
	"context"
	"crypto/subtle"
	"encoding/json"
	"errors"
	"fmt"
	"image"
	_ "image/jpeg"
	_ "image/png"
	"io"
	"log/slog"
	"mime/multipart"
	"net/http"
	"strconv"
	"strings"
	"time"

	"github.com/JesstLe/naumi-router/internal/configuration"
	"github.com/JesstLe/naumi-router/internal/domain"
	"github.com/JesstLe/naumi-router/internal/execution"
	"github.com/JesstLe/naumi-router/internal/provider"
	"github.com/JesstLe/naumi-router/internal/routing"
)

const (
	maxRequestBodyBytes     = 1 << 20
	maxEditRequestBodyBytes = 96 << 20
	maxEditImageBytes       = 20 << 20
	maxEditImages           = 15
)

var publicImageModels = []string{
	"naumi-image-auto",
	"naumi-image-economy",
	"naumi-image-standard",
	"naumi-image-premium",
}

type Server struct {
	Configurations     *configuration.Manager
	ManagementToken    string
	Version            string
	Token              string
	ExposeRouteDebug   bool
	Engine             *routing.Engine
	Providers          provider.Registry
	Logger             *slog.Logger
	Store              *execution.Store
	RequireOperationID bool
}

type errorEnvelope struct {
	Error errorBody `json:"error"`
}

type errorBody struct {
	Message string `json:"message"`
	Type    string `json:"type"`
	Param   string `json:"param,omitempty"`
	Code    string `json:"code"`
}

func (s *Server) Handler() http.Handler {
	mux := http.NewServeMux()
	mux.HandleFunc("GET /healthz", s.health)
	mux.HandleFunc("GET /readyz", s.ready)
	mux.Handle("GET /v1/models", s.authenticate(http.HandlerFunc(s.models)))
	mux.Handle("POST /v1/images/generations", s.authenticate(http.HandlerFunc(s.generate)))
	mux.Handle("POST /v1/images/edits", s.authenticate(http.HandlerFunc(s.edit)))
	mux.Handle("GET /internal/operations/{id}", s.authenticate(http.HandlerFunc(s.operation)))
	mux.Handle("GET /internal/health", s.authenticate(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) { writeJSON(w, 200, s.Engine.Health.Snapshot()) })))
	return s.requestMetadata(mux)
}

func (s *Server) health(w http.ResponseWriter, _ *http.Request) {
	writeJSON(w, http.StatusOK, map[string]string{"status": "ok", "version": s.Version})
}

func (s *Server) ready(w http.ResponseWriter, _ *http.Request) {
	if s.Engine == nil || len(s.Providers) == 0 || s.Token == "" || s.Store == nil {
		writeError(w, http.StatusServiceUnavailable, "router is not ready", "server_error", "not_ready", "")
		return
	}
	writeJSON(w, http.StatusOK, map[string]string{"status": "ready", "version": s.Version})
}

func (s *Server) authenticate(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		provided := strings.TrimPrefix(r.Header.Get("Authorization"), "Bearer ")
		if provided == "" || subtle.ConstantTimeCompare([]byte(provided), []byte(s.Token)) != 1 {
			writeError(w, http.StatusUnauthorized, "invalid service credential", "authentication_error", "invalid_api_key", "")
			return
		}
		next.ServeHTTP(w, r)
	})
}

func (s *Server) models(w http.ResponseWriter, _ *http.Request) {
	models := publicImageModels
	if s.Configurations != nil {
		digest, err := s.Configurations.ActiveDigest()
		if err != nil {
			writeError(w, 503, "model catalog unavailable", "server_error", "configuration_unavailable", "")
			return
		}
		if digest != "" {
			snapshot, err := s.Configurations.ByDigest(digest)
			if err != nil {
				writeError(w, 503, "model catalog unavailable", "server_error", "configuration_unavailable", "")
				return
			}
			models = []string{}
			for _, alias := range snapshot.Engine.Aliases() {
				models = append(models, alias.ID)
			}
		}
	}
	created := time.Now().Unix()
	data := make([]map[string]any, 0, len(models))
	for _, id := range models {
		data = append(data, map[string]any{
			"id":       id,
			"object":   "model",
			"created":  created,
			"owned_by": "naumi",
		})
	}
	writeJSON(w, http.StatusOK, map[string]any{"object": "list", "data": data})
}

func (s *Server) generate(w http.ResponseWriter, r *http.Request) {
	if contentType := r.Header.Get("Content-Type"); !strings.HasPrefix(contentType, "application/json") {
		writeError(w, http.StatusUnsupportedMediaType, "Content-Type must be application/json", "invalid_request_error", "unsupported_media_type", "")
		return
	}

	body := http.MaxBytesReader(w, r.Body, maxRequestBodyBytes)
	defer body.Close()
	var request domain.ImageRequest
	decoder := json.NewDecoder(body)
	if err := decoder.Decode(&request); err != nil {
		var maxBytesError *http.MaxBytesError
		if errors.As(err, &maxBytesError) {
			writeError(w, http.StatusRequestEntityTooLarge, "request body is too large", "invalid_request_error", "request_too_large", "")
			return
		}
		writeError(w, http.StatusBadRequest, "invalid JSON body", "invalid_request_error", "invalid_json", "")
		return
	}
	if err := ensureSingleJSONValue(decoder); err != nil {
		writeError(w, http.StatusBadRequest, "request body must contain one JSON object", "invalid_request_error", "invalid_json", "")
		return
	}
	s.processImage(w, r, request)
}

func (s *Server) edit(w http.ResponseWriter, r *http.Request) {
	if contentType := r.Header.Get("Content-Type"); !strings.HasPrefix(contentType, "multipart/form-data") {
		writeError(w, http.StatusUnsupportedMediaType, "Content-Type must be multipart/form-data", "invalid_request_error", "unsupported_media_type", "")
		return
	}
	r.Body = http.MaxBytesReader(w, r.Body, maxEditRequestBodyBytes)
	if err := r.ParseMultipartForm(8 << 20); err != nil {
		status := http.StatusBadRequest
		code := "invalid_multipart"
		if strings.Contains(strings.ToLower(err.Error()), "request body too large") {
			status = http.StatusRequestEntityTooLarge
			code = "request_too_large"
		}
		writeError(w, status, "invalid multipart body", "invalid_request_error", code, "")
		return
	}
	if r.MultipartForm != nil {
		defer r.MultipartForm.RemoveAll()
	}
	var imageHeaders []*multipart.FileHeader
	if r.MultipartForm != nil {
		imageHeaders = append(imageHeaders, r.MultipartForm.File["image"]...)
		imageHeaders = append(imageHeaders, r.MultipartForm.File["image[]"]...)
	}
	if len(imageHeaders) == 0 {
		writeError(w, http.StatusUnprocessableEntity, "at least one image is required", "invalid_request_error", "validation_error", "image")
		return
	}
	if len(imageHeaders) > maxEditImages {
		writeError(w, http.StatusUnprocessableEntity, "at most 15 reference images are supported", "invalid_request_error", "validation_error", "image")
		return
	}
	maskHeaders := append(r.MultipartForm.File["mask"], r.MultipartForm.File["mask[]"]...)
	if len(maskHeaders) > 1 {
		writeError(w, http.StatusUnprocessableEntity, "at most one mask is supported", "invalid_request_error", "unsupported_parameter", "mask")
		return
	}
	var mask *domain.ReferenceImage
	if len(maskHeaders) == 1 {
		file, e := maskHeaders[0].Open()
		if e != nil {
			writeError(w, 400, "unable to read mask", "invalid_request_error", "invalid_image", "mask")
			return
		}
		payload, e := io.ReadAll(io.LimitReader(file, maxEditImageBytes+1))
		_ = file.Close()
		if e != nil || len(payload) == 0 || len(payload) > maxEditImageBytes || http.DetectContentType(payload) != "image/png" {
			writeError(w, 422, "mask must be PNG within 20 MiB", "invalid_request_error", "invalid_image", "mask")
			return
		}
		config, _, e := image.DecodeConfig(bytes.NewReader(payload))
		if e != nil || config.Width < 1 || config.Height < 1 || int64(config.Width)*int64(config.Height) > 16777216 {
			writeError(w, 422, "invalid mask dimensions", "invalid_request_error", "invalid_image", "mask")
			return
		}
		mask = &domain.ReferenceImage{Bytes: payload, MimeType: "image/png"}
	}

	references := make([]domain.ReferenceImage, 0, len(imageHeaders))
	for _, header := range imageHeaders {
		file, err := header.Open()
		if err != nil {
			writeError(w, http.StatusBadRequest, "unable to read reference image", "invalid_request_error", "invalid_image", "image")
			return
		}
		payload, readErr := io.ReadAll(io.LimitReader(file, maxEditImageBytes+1))
		_ = file.Close()
		if readErr != nil || len(payload) == 0 {
			writeError(w, http.StatusBadRequest, "unable to read reference image", "invalid_request_error", "invalid_image", "image")
			return
		}
		if len(payload) > maxEditImageBytes {
			writeError(w, http.StatusRequestEntityTooLarge, "reference image exceeds 20 MiB", "invalid_request_error", "image_too_large", "image")
			return
		}
		mimeType := strings.Split(http.DetectContentType(payload), ";")[0]
		if mimeType != "image/png" && mimeType != "image/jpeg" && mimeType != "image/webp" {
			writeError(w, http.StatusUnprocessableEntity, "reference image must be PNG, JPEG, or WebP", "invalid_request_error", "invalid_image", "image")
			return
		}
		references = append(references, domain.ReferenceImage{Bytes: payload, MimeType: mimeType})
	}

	count := 1
	if raw := strings.TrimSpace(r.FormValue("n")); raw != "" {
		parsed, err := strconv.Atoi(raw)
		if err != nil {
			writeError(w, http.StatusUnprocessableEntity, "n must be an integer", "invalid_request_error", "validation_error", "n")
			return
		}
		count = parsed
	}
	size := strings.TrimSpace(r.FormValue("size"))
	if size == "" || size == "auto" {
		config, _, err := image.DecodeConfig(bytes.NewReader(references[0].Bytes))
		if err != nil || config.Width < 1 || config.Height < 1 {
			writeError(w, http.StatusUnprocessableEntity, "size=auto requires a decodable PNG or JPEG reference", "invalid_request_error", "invalid_image", "image")
			return
		}
		size = fmt.Sprintf("%dx%d", config.Width, config.Height)
	}
	request := domain.ImageRequest{
		Model:           strings.TrimSpace(r.FormValue("model")),
		Prompt:          strings.TrimSpace(r.FormValue("prompt")),
		N:               &count,
		Quality:         strings.TrimSpace(r.FormValue("quality")),
		Size:            size,
		ResponseFormat:  "b64_json",
		ReferenceImages: references,
		Mask:            mask,
		ExtraFields:     json.RawMessage(r.FormValue("extra_fields")),
	}
	s.processImage(w, r, request)
}

func (s *Server) processImage(w http.ResponseWriter, r *http.Request, request domain.ImageRequest) {

	if err := request.ApplyDefaults(); err != nil {
		writeError(w, http.StatusUnprocessableEntity, err.Error(), "invalid_request_error", "validation_error", "extra_fields")
		return
	}
	if err := request.Validate(); err != nil {
		writeError(w, http.StatusUnprocessableEntity, err.Error(), "invalid_request_error", "validation_error", "")
		return
	}

	s.executeImage(w, r, request)

}

func receiptProvider(receipt *domain.GenerationReceipt) string {
	if receipt == nil {
		return ""
	}
	return receipt.Provider
}

func receiptTaskID(receipt *domain.GenerationReceipt) string {
	if receipt == nil {
		return ""
	}
	return receipt.TaskID
}

func receiptCostUSD(receipt *domain.GenerationReceipt) float64 {
	if receipt == nil {
		return 0
	}
	return receipt.CostUSD
}

func receiptCreditsCost(receipt *domain.GenerationReceipt) float64 {
	if receipt == nil {
		return 0
	}
	return receipt.CreditsCost
}

func ensureSingleJSONValue(decoder *json.Decoder) error {
	var extra any
	err := decoder.Decode(&extra)
	if errors.Is(err, io.EOF) {
		return nil
	}
	if err == nil {
		return errors.New("extra JSON value")
	}
	return err
}

func (s *Server) requestMetadata(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		requestID := newRequestID()
		w.Header().Set("X-Request-Id", requestID)
		w.Header().Set("X-Content-Type-Options", "nosniff")
		w.Header().Set("Cache-Control", "no-store")
		ctx := context.WithValue(r.Context(), requestIDKey{}, requestID)
		next.ServeHTTP(w, r.WithContext(ctx))
	})
}

func (s *Server) logger() *slog.Logger {
	if s.Logger != nil {
		return s.Logger
	}
	return slog.Default()
}

func writeError(w http.ResponseWriter, status int, message, errorType, code, param string) {
	writeJSON(w, status, errorEnvelope{Error: errorBody{
		Message: message,
		Type:    errorType,
		Param:   param,
		Code:    code,
	}})
}

func writeJSON(w http.ResponseWriter, status int, value any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	if err := json.NewEncoder(w).Encode(value); err != nil {
		slog.Error("failed to encode response", "error", err)
	}
}
