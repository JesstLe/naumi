package api

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"net/http"
	"regexp"
	"time"

	"github.com/JesstLe/naumi-router/internal/domain"
	"github.com/JesstLe/naumi-router/internal/execution"
	"github.com/JesstLe/naumi-router/internal/provider"
)

var operationPattern = regexp.MustCompile(`^[A-Za-z0-9._:-]{8,160}$`)

func requestHash(request domain.ImageRequest) string {
	request.ExtraFields = nil
	request.Execution = nil
	data, _ := json.Marshal(request)
	hash := sha256.New()
	_, _ = hash.Write(data)
	for _, reference := range request.ReferenceImages {
		imageHash := sha256.Sum256(reference.Bytes)
		encoded, _ := json.Marshal([]string{reference.MimeType, hex.EncodeToString(imageHash[:])})
		_, _ = hash.Write(encoded)
	}
	if request.Mask != nil {
		maskHash := sha256.Sum256(request.Mask.Bytes)
		_, _ = hash.Write([]byte("mask:"))
		_, _ = hash.Write(maskHash[:])
	}
	return hex.EncodeToString(hash.Sum(nil))
}

func attemptKey(id, route string) string {
	hash := sha256.Sum256([]byte(id + "\x00" + route))
	hash[6] = (hash[6] & 0x0f) | 0x40
	hash[8] = (hash[8] & 0x3f) | 0x80
	value := hex.EncodeToString(hash[:16])
	return value[:8] + "-" + value[8:12] + "-" + value[12:16] + "-" + value[16:20] + "-" + value[20:]
}

func (s *Server) operation(w http.ResponseWriter, r *http.Request) {
	if s.Store == nil {
		writeError(w, 503, "execution store is unavailable", "server_error", "state_unavailable", "")
		return
	}
	record, err := s.Store.Load(r.PathValue("id"))
	if err != nil {
		writeError(w, 503, "execution store is unavailable", "server_error", "state_unavailable", "")
		return
	}
	if record.ID == "" {
		writeError(w, 404, "operation not found", "invalid_request_error", "not_found", "")
		return
	}
	writeJSON(w, 200, record)
}

func (s *Server) executeImage(w http.ResponseWriter, r *http.Request, request domain.ImageRequest) {
	if s.Store == nil {
		writeError(w, 503, "execution store is unavailable", "server_error", "state_unavailable", "")
		return
	}
	id := request.Naumi.OperationID
	headerID := r.Header.Get("Idempotency-Key")
	if id != "" && headerID != "" && id != headerID {
		writeError(w, 409, "operation identities differ", "invalid_request_error", "idempotency_conflict", "")
		return
	}
	if id == "" {
		id = headerID
	}
	if id == "" && !s.RequireOperationID {
		id = newRequestID()
	}
	if !operationPattern.MatchString(id) {
		writeError(w, 422, "a stable operation_id is required", "invalid_request_error", "operation_id_required", "extra_fields.naumi.operation_id")
		return
	}
	request.Naumi.OperationID = id
	engine, providers := s.Engine, s.Providers
	credentialRefs := map[string]string{}
	if request.Naumi.ConfigDigest != "" {
		if s.Configurations == nil {
			writeError(w, 422, "configuration is not prepared", "invalid_request_error", "unknown_configuration", "")
			return
		}
		snapshot, err := s.Configurations.ByDigest(request.Naumi.ConfigDigest)
		if err != nil {
			writeError(w, 422, "configuration is not prepared", "invalid_request_error", "unknown_configuration", "")
			return
		}
		engine, providers, credentialRefs = snapshot.Engine, snapshot.Providers, snapshot.CredentialRefs
	}
	w.Header().Set("X-Naumi-Operation-ID", id)
	record, release, err := s.Store.Claim(id, requestHash(request))
	if err != nil {
		status, code := 503, "state_unavailable"
		if errors.Is(err, execution.ErrConflict) {
			status, code = 409, "idempotency_conflict"
		}
		if errors.Is(err, execution.ErrBusy) {
			status, code = 504, "operation_in_progress"
		}
		writeError(w, status, "operation cannot be executed", "server_error", code, "")
		return
	}
	defer release()
	if request.Naumi.ConfigDigest != "" && record.ConfigDigest == "" {
		record.ConfigDigest = request.Naumi.ConfigDigest
		if s.Store.Save(record) != nil {
			writeError(w, 503, "configuration checkpoint unavailable", "server_error", "state_unavailable", "")
			return
		}
	}
	// A crash may occur after the atomic result rename but before the database
	// commit. Recover that result before considering any provider interaction.
	if record.State != "completed" && len(record.Attempts) > 0 {
		if response, err := s.Store.Response(id); err == nil {
			record.State = "completed"
			record.Attempts[len(record.Attempts)-1].State = "completed"
			record.Attempts[len(record.Attempts)-1].Receipt = response.Receipt
			if s.Store.Save(record) != nil {
				writeError(w, 504, "result state unavailable", "server_error", "state_unavailable", "")
				return
			}
			writeJSON(w, 200, response)
			return
		}
	}
	if record.State == "completed" {
		response, err := s.Store.Response(id)
		if err != nil {
			writeError(w, 504, "completed result is temporarily unavailable", "server_error", "result_unavailable", "")
			return
		}
		writeJSON(w, 200, response)
		return
	}
	if record.State == "failed" {
		writeError(w, 422, "operation has failed; use a new ID for a new task", "server_error", "operation_failed", "")
		return
	}
	ctx, cancel := context.WithTimeout(r.Context(), 120*time.Second)
	defer cancel()
	for {
		var finish func(bool)
		resume := len(record.Attempts) > 0 && record.Attempts[len(record.Attempts)-1].State != "failed"
		if !resume {
			candidates := record.Candidates
			if record.ConfigDigest == "" || candidates == nil {
				var err error
				candidates, _, err = engine.Candidates(request)
				if err != nil {
					writeError(w, 422, "no route satisfies the requested capabilities", "invalid_request_error", "no_eligible_route", "")
					return
				}
				if record.ConfigDigest != "" {
					record.Candidates = candidates
					if s.Store.Save(record) != nil {
						writeError(w, 503, "candidate checkpoint unavailable", "server_error", "state_unavailable", "")
						return
					}
				}
			}
			found := false
			temporarilyUnavailable := false
			for _, route := range candidates {
				used := false
				for _, attempt := range record.Attempts {
					if attempt.Route.ID == route.ID {
						used = true
						break
					}
				}
				if used {
					continue
				}
				generator := providers[route.Provider]
				if generator == nil || provider.Identity(generator) == "" {
					continue
				}
				var acquired bool
				finish, acquired = engine.AcquireProvider(route.Provider, false)
				if !acquired {
					temporarilyUnavailable = true
					continue
				}
				record.Attempts = append(record.Attempts, execution.Attempt{Route: route, Key: attemptKey(id, route.ID), Identity: provider.Identity(generator), CredentialRef: credentialRefs[route.Provider], State: "submitting"})
				record.State = "executing"
				if err := s.Store.Save(record); err != nil {
					finish(true)
					writeError(w, 503, "attempt cannot be persisted", "server_error", "state_unavailable", "")
					return
				}
				found = true
				break
			}
			if !found {
				if temporarilyUnavailable {
					writeError(w, 503, "eligible providers are cooling down or at capacity", "server_error", "provider_capacity", "")
					return
				}
				record.State = "failed"
				if s.Store.Save(record) != nil {
					writeError(w, 503, "state unavailable", "server_error", "state_unavailable", "")
					return
				}
				writeError(w, 422, "eligible routes exhausted", "server_error", "operation_failed", "")
				return
			}
		}
		index := len(record.Attempts) - 1
		attempt := &record.Attempts[index]
		generator := providers[attempt.Route.Provider]
		if generator == nil || provider.Identity(generator) != attempt.Identity {
			writeError(w, 504, "original provider account is unavailable", "server_error", "recovery_unavailable", "")
			return
		}
		if resume && attempt.TaskID == "" {
			resumable, ok := generator.(interface{ CanResumeSubmission() bool })
			if !ok || !resumable.CanResumeSubmission() {
				writeError(w, 504, "submission outcome requires reconciliation", "server_error", "submission_unknown", "")
				return
			}
		}
		if resume {
			var acquired bool
			finish, acquired = engine.AcquireProvider(attempt.Route.Provider, true)
			if !acquired {
				writeError(w, 504, "original provider is at capacity", "server_error", "operation_in_progress", "")
				return
			}
		}
		request.Execution = &domain.Execution{AttemptKey: attempt.Key, TaskID: attempt.TaskID, Submitted: func(taskID string) error {
			record.Attempts[index].TaskID = taskID
			record.Attempts[index].State = "accepted"
			return s.Store.Save(record)
		}}
		started := time.Now()
		response, generateErr := generator.Generate(ctx, attempt.Route, request)
		finish(generateErr == nil)
		record.Attempts[index].DurationMS += time.Since(started).Milliseconds()
		if generateErr != nil {
			record.Attempts[index].Receipt = provider.ReceiptFromError(generateErr)
			if provider.CanFallback(generateErr) {
				record.Attempts[index].State = "failed"
			} else {
				record.State = "uncertain"
			}
			if s.Store.Save(record) != nil {
				writeError(w, 504, "paid attempt state is unavailable", "server_error", "state_unavailable", "")
				return
			}
			s.logger().Warn("image attempt failed", "operation_id", id, "route", attempt.Route.ID, "fallback_safe", provider.CanFallback(generateErr))
			if provider.CanFallback(generateErr) {
				continue
			}
			writeError(w, 504, "provider outcome is pending; retry only with the same operation ID", "server_error", "provider_outcome_unknown", "")
			return
		}
		record.Attempts[index].State = "completed"
		record.Attempts[index].Receipt = response.Receipt
		if s.Store.Complete(record, response) != nil {
			writeError(w, 504, "paid result checkpoint failed", "server_error", "result_unavailable", "")
			return
		}
		s.logger().Info("generation completed", "operation_id", id, "route", attempt.Route.ID, "duration_ms", record.Attempts[index].DurationMS)
		if s.ExposeRouteDebug {
			w.Header().Set("X-Naumi-Route", attempt.Route.ID)
		}
		writeJSON(w, 200, response)
		return
	}
}
