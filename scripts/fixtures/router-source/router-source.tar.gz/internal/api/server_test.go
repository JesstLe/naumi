package api

import (
	"bytes"
	"encoding/json"
	"image"
	"image/color"
	"image/png"
	"io"
	"log/slog"
	"mime/multipart"
	"net/http"
	"net/http/httptest"
	"path/filepath"
	"testing"

	"github.com/JesstLe/naumi-router/internal/domain"
	"github.com/JesstLe/naumi-router/internal/execution"
	"github.com/JesstLe/naumi-router/internal/provider"
	"github.com/JesstLe/naumi-router/internal/routing"
)

func TestModelsRequiresAuthenticationAndListsNaumiAliases(t *testing.T) {
	server := testServer(t, nil)
	unauthorized := httptest.NewRequest(http.MethodGet, "/v1/models", nil)
	unauthorizedResponse := httptest.NewRecorder()
	server.Handler().ServeHTTP(unauthorizedResponse, unauthorized)
	if unauthorizedResponse.Code != http.StatusUnauthorized {
		t.Fatalf("unauthorized status = %d, want %d", unauthorizedResponse.Code, http.StatusUnauthorized)
	}

	request := httptest.NewRequest(http.MethodGet, "/v1/models", nil)
	request.Header.Set("Authorization", "Bearer test-service-token-with-24-chars")
	response := httptest.NewRecorder()
	server.Handler().ServeHTTP(response, request)
	if response.Code != http.StatusOK {
		t.Fatalf("status = %d, want %d; body=%s", response.Code, http.StatusOK, response.Body.String())
	}
	if !bytes.Contains(response.Body.Bytes(), []byte(`"id":"naumi-image-standard"`)) {
		t.Fatalf("model list omitted standard alias: %s", response.Body.String())
	}
}

func TestGenerationRequiresAuthentication(t *testing.T) {
	server := testServer(t, nil)
	request := httptest.NewRequest(http.MethodPost, "/v1/images/generations", bytes.NewBufferString(`{"prompt":"test"}`))
	request.Header.Set("Content-Type", "application/json")
	response := httptest.NewRecorder()

	server.Handler().ServeHTTP(response, request)

	if response.Code != http.StatusUnauthorized {
		t.Fatalf("status = %d, want %d", response.Code, http.StatusUnauthorized)
	}
}

func TestGenerationFallsBackAfterProviderFailure(t *testing.T) {
	failingRoute := testRoute("first", 1_000)
	fallbackRoute := testRoute("second", 2_000)
	server := testServer(t, []routing.Route{failingRoute, fallbackRoute})
	server.ExposeRouteDebug = true
	server.Providers["mock"] = &provider.Mock{FailRoutes: map[string]bool{"first": true}}

	body := map[string]any{
		"model":           "naumi-image-auto",
		"prompt":          "A product photo",
		"size":            "1024x1024",
		"quality":         "auto",
		"response_format": "b64_json",
	}
	encoded, err := json.Marshal(body)
	if err != nil {
		t.Fatalf("marshal body: %v", err)
	}
	request := httptest.NewRequest(http.MethodPost, "/v1/images/generations", bytes.NewReader(encoded))
	request.Header.Set("Content-Type", "application/json")
	request.Header.Set("Authorization", "Bearer test-service-token-with-24-chars")
	response := httptest.NewRecorder()

	server.Handler().ServeHTTP(response, request)

	if response.Code != http.StatusOK {
		t.Fatalf("status = %d, want %d; body=%s", response.Code, http.StatusOK, response.Body.String())
	}
	if got, want := response.Header().Get("X-Naumi-Route"), "second"; got != want {
		t.Fatalf("route header = %q, want %q", got, want)
	}
}

func TestGenerationAcceptsRoutingOptionsThroughExtraFields(t *testing.T) {
	server := testServer(t, nil)
	server.ExposeRouteDebug = true
	body := `{
		"model":"naumi-image-auto",
		"prompt":"A package",
		"size":"4k",
		"quality":"medium",
		"extra_fields":{"naumi":{"native_resolution":true,"text_accuracy":"required"}}
	}`
	request := httptest.NewRequest(http.MethodPost, "/v1/images/generations", bytes.NewBufferString(body))
	request.Header.Set("Content-Type", "application/json")
	request.Header.Set("Authorization", "Bearer test-service-token-with-24-chars")
	response := httptest.NewRecorder()

	server.Handler().ServeHTTP(response, request)

	if response.Code != http.StatusOK {
		t.Fatalf("status = %d, want %d; body=%s", response.Code, http.StatusOK, response.Body.String())
	}
}

func TestEditAcceptsOpenAIMultipartAndRoutesReferenceImage(t *testing.T) {
	server := testServer(t, nil)
	var body bytes.Buffer
	writer := multipart.NewWriter(&body)
	_ = writer.WriteField("model", "naumi-image-standard")
	_ = writer.WriteField("prompt", "Put the product on a white background")
	_ = writer.WriteField("size", "1024x1024")
	_ = writer.WriteField("quality", "medium")
	part, err := writer.CreateFormFile("image[]", "product.png")
	if err != nil {
		t.Fatal(err)
	}
	input := image.NewNRGBA(image.Rect(0, 0, 2, 2))
	input.Set(0, 0, color.NRGBA{R: 255, A: 255})
	if err := png.Encode(part, input); err != nil {
		t.Fatal(err)
	}
	if err := writer.Close(); err != nil {
		t.Fatal(err)
	}

	request := httptest.NewRequest(http.MethodPost, "/v1/images/edits", &body)
	request.Header.Set("Authorization", "Bearer test-service-token-with-24-chars")
	request.Header.Set("Content-Type", writer.FormDataContentType())
	response := httptest.NewRecorder()
	server.Handler().ServeHTTP(response, request)
	if response.Code != http.StatusOK {
		t.Fatalf("status = %d, want %d; body=%s", response.Code, http.StatusOK, response.Body.String())
	}
}

func TestMaskedEditFiltersRoutesAndHashesMask(t *testing.T) {
	for _, supported := range []bool{false, true} {
		route := testRoute("masked", 1000)
		route.SupportsMask = supported
		server := testServer(t, []routing.Route{route})
		var body bytes.Buffer
		writer := multipart.NewWriter(&body)
		for key, value := range map[string]string{"model": "naumi-image-standard", "prompt": "masked product", "size": "1024x1024", "quality": "medium"} {
			_ = writer.WriteField(key, value)
		}
		for _, field := range []string{"image", "mask"} {
			part, _ := writer.CreateFormFile(field, field+".png")
			_ = png.Encode(part, image.NewNRGBA(image.Rect(0, 0, 2, 2)))
		}
		_ = writer.Close()
		request := httptest.NewRequest(http.MethodPost, "/v1/images/edits", &body)
		request.Header.Set("Authorization", "Bearer test-service-token-with-24-chars")
		request.Header.Set("Content-Type", writer.FormDataContentType())
		response := httptest.NewRecorder()
		server.Handler().ServeHTTP(response, request)
		if (response.Code == 200) != supported {
			t.Fatalf("mask supported=%v status=%d body=%s", supported, response.Code, response.Body.String())
		}
	}
	request := domain.ImageRequest{Prompt: "same paid intent", Mask: &domain.ReferenceImage{Bytes: []byte("mask-one")}}
	first := requestHash(request)
	request.Mask.Bytes = []byte("mask-two")
	if first == requestHash(request) {
		t.Fatal("changed masks share a paid idempotency identity")
	}
}

func testServer(t *testing.T, routes []routing.Route) *Server {
	t.Helper()
	if routes == nil {
		routes = []routing.Route{testRoute("default", 1_000)}
	}
	engine, err := routing.NewEngine(routes)
	if err != nil {
		t.Fatalf("NewEngine: %v", err)
	}
	return &Server{
		Store:     testStore(t),
		Token:     "test-service-token-with-24-chars",
		Engine:    engine,
		Providers: provider.Registry{"mock": &provider.Mock{}},
		Logger:    slog.New(slog.NewTextHandler(io.Discard, nil)),
	}
}

func testStore(t *testing.T) *execution.Store {
	t.Helper()
	store, err := execution.Open(filepath.Join(t.TempDir(), "state"))
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { _ = store.Close() })
	return store
}

func testRoute(id string, cost int64) routing.Route {
	return routing.Route{
		ID:                    id,
		Provider:              "mock",
		UpstreamModel:         id + "-model",
		Enabled:               true,
		Healthy:               true,
		EstimatedCostMicroUSD: cost,
		ExpectedLatencyMS:     1,
		QualityRank:           2,
		MaxPixels:             8_294_400,
		TextAccuracy:          true,
		Native4K:              true,
		SupportsEdit:          true,
	}
}
