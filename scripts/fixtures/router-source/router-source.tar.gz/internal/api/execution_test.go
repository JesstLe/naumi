package api

import (
	"bytes"
	"context"
	"errors"
	"net/http/httptest"
	"path/filepath"
	"sync/atomic"
	"testing"

	"github.com/JesstLe/naumi-router/internal/domain"
	"github.com/JesstLe/naumi-router/internal/execution"
	"github.com/JesstLe/naumi-router/internal/provider"
	"github.com/JesstLe/naumi-router/internal/routing"
)

type recoveryProvider struct {
	posts    atomic.Int32
	queries  atomic.Int32
	unknown  bool
	accepted chan struct{}
	release  chan struct{}
}

func (*recoveryProvider) Identity() string { return "account-1" }
func (p *recoveryProvider) Generate(_ context.Context, _ routing.Route, request domain.ImageRequest) (domain.ImageResponse, error) {
	if request.Execution.TaskID != "" {
		p.queries.Add(1)
		return domain.ImageResponse{Data: []domain.ImageData{{B64JSON: "stored-image"}}, Receipt: &domain.GenerationReceipt{TaskID: request.Execution.TaskID, CostUSD: 0.021}}, nil
	}
	p.posts.Add(1)
	if p.accepted != nil {
		close(p.accepted)
		<-p.release
	}
	if !p.unknown {
		if err := provider.SubmissionCheckpoint(request, "task-123"); err != nil {
			return domain.ImageResponse{}, err
		}
	}
	return domain.ImageResponse{}, &provider.AttemptError{Err: errors.New("poll interrupted")}
}

func execute(t *testing.T, s *Server, id, prompt string) *httptest.ResponseRecorder {
	t.Helper()
	body := `{"model":"naumi-image-auto","prompt":"` + prompt + `","extra_fields":{"naumi":{"operation_id":"` + id + `"}}}`
	r := httptest.NewRequest("POST", "/v1/images/generations", bytes.NewBufferString(body))
	r.Header.Set("Content-Type", "application/json")
	r.Header.Set("Authorization", "Bearer "+s.Token)
	w := httptest.NewRecorder()
	s.Handler().ServeHTTP(w, r)
	return w
}

func reopen(t *testing.T, s *Server, dir string) {
	t.Helper()
	if s.Store != nil {
		if err := s.Store.Close(); err != nil {
			t.Fatal(err)
		}
	}
	store, err := execution.Open(dir)
	if err != nil {
		t.Fatal(err)
	}
	s.Store = store
}

func TestPaidOperationRecoversAfterRestartAndReplaysWithoutSubmission(t *testing.T) {
	s := testServer(t, nil)
	dir := filepath.Join(t.TempDir(), "ledger")
	reopen(t, s, dir)
	t.Cleanup(func() { _ = s.Store.Close() })
	p := &recoveryProvider{}
	s.Providers["mock"] = p
	if w := execute(t, s, "stable-image-01", "product"); w.Code != 504 {
		t.Fatalf("first: %d %s", w.Code, w.Body.String())
	}
	reopen(t, s, dir)
	if w := execute(t, s, "stable-image-01", "product"); w.Code != 200 {
		t.Fatalf("recovery: %d %s", w.Code, w.Body.String())
	}
	reopen(t, s, dir)
	if w := execute(t, s, "stable-image-01", "product"); w.Code != 200 {
		t.Fatalf("replay: %d", w.Code)
	}
	if p.posts.Load() != 1 || p.queries.Load() != 1 {
		t.Fatalf("posts=%d queries=%d", p.posts.Load(), p.queries.Load())
	}
	record, err := s.Store.Load("stable-image-01")
	if err != nil || record.State != "completed" || record.Attempts[0].Receipt.CostUSD != 0.021 {
		t.Fatalf("missing paid receipt: %+v %v", record, err)
	}
	if w := execute(t, s, "stable-image-01", "changed"); w.Code != 409 {
		t.Fatalf("conflict: %d", w.Code)
	}
}

func TestUnknownSubmissionNeverResubmitsOrFallsBack(t *testing.T) {
	s := testServer(t, []routing.Route{testRoute("first", 1), testRoute("second", 2)})
	p := &recoveryProvider{unknown: true}
	s.Providers["mock"] = p
	for i := 0; i < 3; i++ {
		if w := execute(t, s, "unknown-image-01", "product"); w.Code != 504 {
			t.Fatalf("unknown: %d", w.Code)
		}
	}
	if p.posts.Load() != 1 {
		t.Fatalf("duplicate paid submissions: %d", p.posts.Load())
	}
}

func TestOrphanResultRetainsReceiptAcrossRestart(t *testing.T) {
	s := testServer(t, nil)
	dir := filepath.Join(t.TempDir(), "ledger")
	reopen(t, s, dir)
	t.Cleanup(func() { _ = s.Store.Close() })
	p := &recoveryProvider{}
	s.Providers["mock"] = p
	_ = execute(t, s, "orphan-image-01", "product")
	record, err := s.Store.Load("orphan-image-01")
	if err != nil {
		t.Fatal(err)
	}
	response := domain.ImageResponse{Data: []domain.ImageData{{B64JSON: "paid"}}, Receipt: &domain.GenerationReceipt{TaskID: "task-123", CostUSD: 0.028}}
	if err = s.Store.Complete(record, response); err != nil {
		t.Fatal(err)
	}
	// Simulate the database retaining accepted state after the result rename.
	if err = s.Store.Save(record); err != nil {
		t.Fatal(err)
	}
	reopen(t, s, dir)
	if w := execute(t, s, "orphan-image-01", "product"); w.Code != 200 {
		t.Fatalf("orphan recovery: %d", w.Code)
	}
	record, _ = s.Store.Load("orphan-image-01")
	if record.Attempts[0].Receipt == nil || record.Attempts[0].Receipt.CostUSD != 0.028 || p.queries.Load() != 0 || p.posts.Load() != 1 {
		t.Fatalf("lost receipt or repeated provider interaction: %+v", record)
	}
}

func TestConcurrentSameOperationHasOnePaidSubmission(t *testing.T) {
	s := testServer(t, nil)
	p := &recoveryProvider{accepted: make(chan struct{}), release: make(chan struct{})}
	s.Providers["mock"] = p
	done := make(chan *httptest.ResponseRecorder, 1)
	go func() { done <- execute(t, s, "concurrent-image-01", "product") }()
	<-p.accepted
	if w := execute(t, s, "concurrent-image-01", "product"); w.Code != 504 {
		t.Fatalf("concurrent: %d", w.Code)
	}
	close(p.release)
	<-done
	if p.posts.Load() != 1 {
		t.Fatalf("duplicate: %d", p.posts.Load())
	}
}

func TestStoreFailureAndMissingIdentityFailBeforePaidPOST(t *testing.T) {
	s := testServer(t, nil)
	p := &recoveryProvider{}
	s.Providers["mock"] = p
	_ = s.Store.Close()
	if w := execute(t, s, "storage-image-01", "product"); w.Code != 503 {
		t.Fatalf("storage failure: %d", w.Code)
	}
	if p.posts.Load() != 0 {
		t.Fatal("submitted without durable state")
	}
	s.RequireOperationID = true
	if w := execute(t, s, "", "product"); w.Code != 422 {
		t.Fatalf("required identity: %d", w.Code)
	}
}
