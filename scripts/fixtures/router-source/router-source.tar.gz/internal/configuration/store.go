package configuration

import (
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"os"
	"path/filepath"
	"sync"
	"time"

	"github.com/JesstLe/naumi-router/internal/routing"
	bolt "go.etcd.io/bbolt"
)

type Manager struct {
	mu       sync.Mutex
	db       *bolt.DB
	options  Options
	runtimes map[string]*RuntimeSnapshot
	health   *routing.Health
}

func Open(dir string, options Options) (*Manager, error) {
	if len(options.EnvelopeSecret) < 32 {
		return nil, ErrInvalid
	}
	if err := os.MkdirAll(dir, 0700); err != nil {
		return nil, ErrUnavailable
	}
	if err := os.Chmod(dir, 0700); err != nil {
		return nil, ErrUnavailable
	}
	db, err := bolt.Open(filepath.Join(dir, "configurations.db"), 0600, &bolt.Options{Timeout: time.Second})
	if err != nil {
		return nil, ErrUnavailable
	}
	err = db.Update(func(tx *bolt.Tx) error {
		for _, name := range []string{"versions", "credentials", "publications", "state"} {
			if _, err := tx.CreateBucketIfNotExists([]byte(name)); err != nil {
				return err
			}
		}
		return nil
	})
	if err != nil {
		db.Close()
		return nil, ErrUnavailable
	}
	m := &Manager{db: db, options: options, runtimes: map[string]*RuntimeSnapshot{}, health: routing.NewHealth(nil)}
	// Rebuild all retained budgets before any request, so a restart cannot grant
	// a new version more capacity than an older recoverable version.
	err = db.View(func(tx *bolt.Tx) error {
		return tx.Bucket([]byte("versions")).ForEach(func(_ []byte, data []byte) error {
			var input PreparedConfig
			if json.Unmarshal(data, &input) != nil {
				return ErrUnavailable
			}
			runtime, err := m.build(input)
			if err != nil {
				return ErrUnavailable
			}
			m.runtimes[input.Digest] = runtime
			return nil
		})
	})
	if err != nil {
		db.Close()
		return nil, ErrUnavailable
	}
	return m, nil
}
func (m *Manager) Close() error { return m.db.Close() }
func Digest(input PreparedConfig) (string, error) {
	// Digest excludes the randomized encryption envelope, but includes immutable credential refs.
	payload := struct {
		ModelVersion   uint64     `json:"modelVersion"`
		BillingVersion uint64     `json:"billingVersion"`
		Config         Projection `json:"config"`
	}{input.ModelVersion, input.BillingVersion, input.Config}
	raw, err := json.Marshal(payload)
	if err != nil {
		return "", ErrInvalid
	}
	var generic any
	if json.Unmarshal(raw, &generic) != nil {
		return "", ErrInvalid
	}
	var buffer bytes.Buffer
	encoder := json.NewEncoder(&buffer)
	encoder.SetEscapeHTML(false)
	if encoder.Encode(generic) != nil {
		return "", ErrInvalid
	}
	hash := sha256.Sum256(bytes.TrimSuffix(buffer.Bytes(), []byte("\n")))
	return hex.EncodeToString(hash[:]), nil
}
func (m *Manager) Prepare(input PreparedConfig) error {
	// Copy the caller's slices/maps before making an immutable runtime.
	raw, err := json.Marshal(input)
	if err != nil || len(raw) > 512*1024 {
		return ErrInvalid
	}
	if json.Unmarshal(raw, &input) != nil {
		return ErrInvalid
	}
	want, err := Digest(input)
	if err != nil || input.ModelVersion < 1 || input.BillingVersion < 1 || want != input.Digest {
		return ErrInvalid
	}
	m.mu.Lock()
	defer m.mu.Unlock()
	// Validate every incoming envelope, including replays. References never change accounts.
	values := map[string]string{}
	if len(input.Credentials) != len(input.Config.Providers) {
		return ErrInvalid
	}
	for _, c := range input.Credentials {
		if !validID(c.Ref) || !validID(c.ProviderID) {
			return ErrInvalid
		}
		plain, err := OpenCredential(m.options.EnvelopeSecret, c)
		if err != nil || values[c.Ref] != "" {
			return ErrInvalid
		}
		values[c.Ref] = plain
	}
	err = m.db.View(func(tx *bolt.Tx) error {
		for _, c := range input.Credentials {
			if data := tx.Bucket([]byte("credentials")).Get([]byte(c.Ref)); data != nil {
				var previous SealedCredential
				if json.Unmarshal(data, &previous) != nil {
					return ErrUnavailable
				}
				plain, err := OpenCredential(m.options.EnvelopeSecret, previous)
				if err != nil || previous.ProviderID != c.ProviderID || plain != values[c.Ref] {
					return ErrConflict
				}
			}
		}
		return nil
	})
	if err != nil {
		return err
	}
	runtime, err := m.build(input)
	if err != nil {
		return err
	}
	err = m.db.Update(func(tx *bolt.Tx) error {
		versions := tx.Bucket([]byte("versions"))
		if previous := versions.Get([]byte(input.Digest)); previous != nil {
			var old PreparedConfig
			if json.Unmarshal(previous, &old) != nil {
				return ErrUnavailable
			}
			return nil
		}
		for _, c := range input.Credentials {
			encoded, _ := json.Marshal(c)
			if tx.Bucket([]byte("credentials")).Get([]byte(c.Ref)) == nil {
				if err := tx.Bucket([]byte("credentials")).Put([]byte(c.Ref), encoded); err != nil {
					return err
				}
			}
		}
		return versions.Put([]byte(input.Digest), raw)
	})
	if err != nil {
		return ErrUnavailable
	}
	m.runtimes[input.Digest] = runtime
	return nil
}
func (m *Manager) ByDigest(digest string) (*RuntimeSnapshot, error) {
	m.mu.Lock()
	defer m.mu.Unlock()
	runtime := m.runtimes[digest]
	if runtime == nil {
		return nil, ErrNotFound
	}
	return runtime, nil
}
func (m *Manager) ActiveDigest() (string, error) {
	var digest string
	err := m.db.View(func(tx *bolt.Tx) error { digest = string(tx.Bucket([]byte("state")).Get([]byte("active"))); return nil })
	if err != nil {
		return "", ErrUnavailable
	}
	return digest, nil
}
func (m *Manager) Activate(id, expectedDigest, digest string) error {
	if !validID(id) || len(id) > 160 {
		return ErrInvalid
	}
	m.mu.Lock()
	defer m.mu.Unlock()
	if m.runtimes[digest] == nil {
		return ErrNotFound
	}
	return m.db.Update(func(tx *bolt.Tx) error {
		publications := tx.Bucket([]byte("publications"))
		state := tx.Bucket([]byte("state"))
		if raw := publications.Get([]byte(id)); raw != nil {
			var previous activation
			if json.Unmarshal(raw, &previous) != nil {
				return ErrUnavailable
			}
			if previous.ExpectedDigest != expectedDigest || previous.Digest != digest {
				return ErrConflict
			}
			return nil
		}
		if string(state.Get([]byte("active"))) != expectedDigest {
			return ErrConflict
		}
		value, _ := json.Marshal(activation{PublicationStatus: PublicationStatus{ID: id, Digest: digest, Phase: "applied"}, ExpectedDigest: expectedDigest})
		if err := publications.Put([]byte(id), value); err != nil {
			return err
		}
		return state.Put([]byte("active"), []byte(digest))
	})
}

type activation struct {
	PublicationStatus
	ExpectedDigest string `json:"expectedDigest"`
}

func (m *Manager) Status(id string) (PublicationStatus, error) {
	var status activation
	err := m.db.View(func(tx *bolt.Tx) error {
		data := tx.Bucket([]byte("publications")).Get([]byte(id))
		if data == nil {
			return ErrNotFound
		}
		if json.Unmarshal(data, &status) != nil {
			return ErrUnavailable
		}
		return nil
	})
	return status.PublicationStatus, err
}
