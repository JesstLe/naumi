package configuration

import (
	"net/http"
	"net/http/httptest"
	"net/url"
	"testing"
)

func TestApprovedModelProxy(t *testing.T) {
	var connected string
	proxy := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		connected = r.Method + " " + r.Host
		if r.Header.Get("Authorization") != "" {
			t.Error("API credential leaked to proxy CONNECT")
		}
		w.WriteHeader(403)
	}))
	defer proxy.Close()
	t.Setenv("NAUMI_MODEL_PROXY_URL", proxy.URL)
	t.Setenv("NAUMI_MODEL_PROXY_ORIGINS", "https://api.apimart.ai")
	m := &Manager{}
	target, _ := url.Parse("https://api.apimart.ai/v1/models")
	client := m.httpClient(ProviderSpec{TimeoutMS: 5000}, target, false)
	req, _ := http.NewRequest("GET", target.String(), nil)
	req.Header.Set("Authorization", "Bearer fixture-private-key")
	_, err := client.Do(req)
	if err == nil {
		t.Fatal("CONNECT rejection must not count as success")
	}
	if connected != "CONNECT api.apimart.ai:443" {
		t.Fatalf("unexpected tunnel destination %q", connected)
	}
	other, _ := url.Parse("https://other.example/v1/models")
	if m.httpClient(ProviderSpec{TimeoutMS: 5000}, other, false).Transport.(*http.Transport).Proxy != nil {
		t.Fatal("unapproved provider must retain direct transport")
	}
}
