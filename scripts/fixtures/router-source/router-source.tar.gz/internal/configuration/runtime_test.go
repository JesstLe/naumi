package configuration

import (
	"bytes"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/JesstLe/naumi-router/internal/domain"
	"github.com/JesstLe/naumi-router/internal/routing"
)

func preparedFixture(t *testing.T, version uint64, endpoint, ref string, limit int) PreparedConfig {
	t.Helper()
	secret := "fixture-envelope-secret-independent-20261004"
	sealed, err := SealCredential(secret, "p1", ref, "fixture-provider-account")
	if err != nil {
		t.Fatal(err)
	}
	route := routing.Route{ID: "u1", Provider: "p1", UpstreamModel: "gpt-image-1", Enabled: true, Healthy: true, QualityRank: 3, MaxPixels: 4096 * 4096, MaxConcurrent: limit, MaxReferenceImages: 4, SupportsEdit: true, Native4K: true}
	input := PreparedConfig{ModelVersion: version, BillingVersion: 1, Config: Projection{Routes: []routing.Route{route}, Providers: []ProviderSpec{{ID: "p1", Protocol: "openai-images", BaseURL: endpoint + "/v1", CredentialRef: ref, TimeoutMS: 120000, MaxConcurrent: limit}}, Aliases: []routing.Alias{{ID: "custom-image", Candidates: []string{"u1"}, Strategy: "priority"}}}, Credentials: []SealedCredential{sealed}}
	input.Digest, err = Digest(input)
	if err != nil {
		t.Fatal(err)
	}
	return input
}

func TestTrustedOriginsNeverAllowMappedOrIPv6Metadata(t *testing.T) {
	for _, host := range []string{"[::ffff:169.254.169.254]", "[::ffff:100.100.100.200]", "[fd00:ec2::254]"} {
		origin := "http://" + host
		m := &Manager{options: Options{TrustedOrigins: []string{origin}}}
		if _, _, err := m.endpoint(origin + "/v1"); err == nil {
			t.Fatalf("metadata bypassed exact-origin trust: %s", host)
		}
	}
}
func TestPreparedVersionsSurviveRestartWithoutLeakingCredentials(t *testing.T) {
	server := httptest.NewTLSServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) { t.Error("configuration must never call generation") }))
	defer server.Close()
	options := Options{EnvelopeSecret: "fixture-envelope-secret-independent-20261004", TrustedOrigins: []string{server.URL}, HTTPClient: server.Client()}
	dir := t.TempDir()
	m, err := Open(dir, options)
	if err != nil {
		t.Fatal(err)
	}
	one := preparedFixture(t, 1, server.URL, "ref-one", 2)
	if err = m.Prepare(one); err != nil {
		t.Fatal(err)
	}
	if err = m.Activate("first", "", one.Digest); err != nil {
		t.Fatal(err)
	}
	if err = m.Activate("first", "", one.Digest); err != nil {
		t.Fatal(err)
	}
	two := preparedFixture(t, 2, server.URL, "ref-two", 2)
	// Rotation within the same configured supplier account must not double capacity.
	rotated, err := SealCredential(options.EnvelopeSecret, "p1", "ref-two", "fixture-rotated-account-key")
	if err != nil {
		t.Fatal(err)
	}
	two.Credentials = []SealedCredential{rotated}
	if err = m.Prepare(two); err != nil {
		t.Fatal(err)
	}
	if err = m.Activate("first", one.Digest, two.Digest); err == nil {
		t.Fatal("operation id was rebound")
	}
	if err = m.Activate("second", one.Digest, two.Digest); err != nil {
		t.Fatal(err)
	}
	if err = m.Close(); err != nil {
		t.Fatal(err)
	}
	disk, err := os.ReadFile(filepath.Join(dir, "configurations.db"))
	if err != nil {
		t.Fatal(err)
	}
	if bytes.Contains(disk, []byte("fixture-provider-account")) {
		t.Fatal("plaintext secret persisted")
	}
	m, err = Open(dir, options)
	if err != nil {
		t.Fatal(err)
	}
	defer m.Close()
	first, err := m.ByDigest(one.Digest)
	if err != nil {
		t.Fatal(err)
	}
	status, err := m.Status("second")
	if err != nil || status.Digest != two.Digest || status.Phase != "applied" {
		t.Fatalf("status=%+v err=%v", status, err)
	}
	if first.CredentialRefs["p1"] != "ref-one" {
		t.Fatal("credential reference overwritten")
	}
	latest, err := m.ByDigest(two.Digest)
	if err != nil {
		t.Fatal(err)
	}
	a, ok := first.Engine.AcquireProvider("p1", false)
	if !ok {
		t.Fatal("first lease")
	}
	defer a(true)
	b, ok := latest.Engine.AcquireProvider("p1", false)
	if !ok {
		t.Fatal("second lease")
	}
	defer b(true)
	if release, ok := latest.Engine.AcquireProvider("p1", false); ok {
		release(true)
		t.Fatal("same account was allotted per-version capacity")
	}
	n := 1
	request := domain.ImageRequest{Model: "custom-image", Prompt: "product", N: &n, Quality: "medium", Size: "1024x1024"}
	if _, _, err = first.Engine.Candidates(request); err != nil {
		t.Fatal(err)
	}
	request.Model = "unknown-alias"
	if _, _, err = first.Engine.Candidates(request); err == nil {
		t.Fatal("unknown alias accepted")
	}
	encoded, _ := json.Marshal(status)
	if strings.Contains(string(encoded), "fixture-provider-account") || strings.Contains(string(encoded), "ciphertext") {
		t.Fatal("status leaked credential")
	}
}
func TestPrepareRejectsTamperAndCredentialReferenceReuse(t *testing.T) {
	server := httptest.NewTLSServer(http.HandlerFunc(func(http.ResponseWriter, *http.Request) { t.Error("paid call") }))
	defer server.Close()
	m, err := Open(t.TempDir(), Options{EnvelopeSecret: "fixture-envelope-secret-independent-20261004", TrustedOrigins: []string{server.URL}, HTTPClient: server.Client()})
	if err != nil {
		t.Fatal(err)
	}
	defer m.Close()
	one := preparedFixture(t, 1, server.URL, "ref-one", 2)
	broken := one
	broken.Digest = strings.Repeat("0", 64)
	if m.Prepare(broken) == nil {
		t.Fatal("tampered digest accepted")
	}
	if err = m.Prepare(one); err != nil {
		t.Fatal(err)
	}
	two := preparedFixture(t, 2, server.URL, "ref-one", 2)
	changed, err := SealCredential("fixture-envelope-secret-independent-20261004", "p1", "ref-one", "different-account")
	if err != nil {
		t.Fatal(err)
	}
	two.Credentials = []SealedCredential{changed}
	if m.Prepare(two) == nil {
		t.Fatal("immutable credential reference changed account")
	}
	one.Credentials[0].Ciphertext.CT = "bad"
	if m.Prepare(one) == nil {
		t.Fatal("bad envelope was ignored on replay")
	}
	if _, err = m.ByDigest(strings.Repeat("f", 64)); err == nil {
		t.Fatal("unknown digest resolved to active")
	}
}
