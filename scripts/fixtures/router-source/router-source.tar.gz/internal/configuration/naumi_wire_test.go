package configuration

import (
	"encoding/json"
	"os"
	"testing"

	"github.com/JesstLe/naumi-router/internal/domain"
)

func TestNaumiWireProjection(t *testing.T) {
	path := os.Getenv("NAUMI_VERIFY_CONFIG_PAYLOAD")
	if path == "" {
		t.Skip("Cross-repository fixture: run Naumi verify:model-router-contract")
	}
	file, err := os.Open(path)
	if err != nil {
		t.Fatal(err)
	}
	defer file.Close()
	var input PreparedConfig
	decoder := json.NewDecoder(file)
	decoder.DisallowUnknownFields()
	if err := decoder.Decode(&input); err != nil {
		t.Fatal(err)
	}
	digest, err := Digest(input)
	if err != nil || digest != input.Digest {
		t.Fatalf("cross-language digest mismatch: %v", err)
	}
	manager, err := Open(t.TempDir(), Options{EnvelopeSecret: "naumi-go-wire-test-envelope-independent-secret"})
	if err != nil {
		t.Fatal(err)
	}
	defer manager.Close()
	if err := manager.Prepare(input); err != nil {
		t.Fatal(err)
	}
	runtime, err := manager.ByDigest(digest)
	if err != nil {
		t.Fatal(err)
	}
	count := 4
	candidates, _, err := runtime.Engine.Candidates(domain.ImageRequest{Model: "image-a", Prompt: "product photo", Quality: "high", Size: "1024x1024", N: &count, Naumi: domain.RoutingOptions{Task: "product", Resolution: "1K"}})
	if err != nil {
		t.Fatal(err)
	}
	if len(candidates) != 1 || candidates[0].CostCurrency != "CNY" || candidates[0].EstimatedCostMicros != 290000 || candidates[0].UpstreamQuality != "hd" {
		t.Fatal("wire projection changed monetary unit or parameter mapping")
	}
}
