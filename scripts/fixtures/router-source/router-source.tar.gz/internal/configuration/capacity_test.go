package configuration

import (
	"encoding/json"
	"net/http"
	"os"
	"testing"
)

// Node runs this against a real isolated PostgreSQL capacity service and keeps
// a direct request's streaming response open during the first acquisition.
func TestNaumiDirectAndPoolCapacity(t *testing.T) {
	path := os.Getenv("NAUMI_VERIFY_CONFIG_PAYLOAD")
	endpoint := os.Getenv("NAUMI_VERIFY_CAPACITY_URL")
	if path == "" || endpoint == "" {
		t.Skip("Node/PostgreSQL integration fixture only")
	}
	raw, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	var input PreparedConfig
	if json.Unmarshal(raw, &input) != nil {
		t.Fatal("invalid fixture")
	}
	options := Options{EnvelopeSecret: os.Getenv("MODEL_CONFIG_ENVELOPE_SECRET"), TrustedOrigins: []string{os.Getenv("NAUMI_VERIFY_SUPPLIER_ORIGIN")}}
	options.CapacityAcquire, err = NewCapacityClient(endpoint+"/api/internal/model-capacity", "fixture-shared-capacity-control-independent-secret")
	if err != nil {
		t.Fatal(err)
	}
	dir := t.TempDir()
	m, err := Open(dir, options)
	if err != nil {
		t.Fatal(err)
	}
	defer func() { m.Close() }()
	if err = m.Prepare(input); err != nil {
		t.Fatal(err)
	}
	runtime, err := m.ByDigest(input.Digest)
	if err != nil {
		t.Fatal(err)
	}
	if release, ok := runtime.Engine.AcquireProvider("p1", false); ok {
		release(true)
		t.Fatal("pool admitted while same-account direct response still occupies the only slot")
	}
	response, err := http.Post(endpoint+"/fixture/release-direct", "application/json", nil)
	if err != nil {
		t.Fatal(err)
	}
	response.Body.Close()
	release, ok := runtime.Engine.AcquireProvider("p1", false)
	if !ok {
		t.Fatal("released direct slot did not become available to pool")
	}
	response, err = http.Get(endpoint + "/fixture/assert-direct-busy")
	if err != nil {
		t.Fatal(err)
	}
	response.Body.Close()
	if response.StatusCode != 200 {
		t.Fatal("direct admitted while pool holds shared slot")
	}
	// Router process loss cannot reset the shared PostgreSQL slot. Reopening
	// the durable configuration loses local counters but must still deny it.
	if err = m.Close(); err != nil {
		t.Fatal(err)
	}
	m, err = Open(dir, options)
	if err != nil {
		t.Fatal(err)
	}
	restarted, err := m.ByDigest(input.Digest)
	if err != nil {
		t.Fatal(err)
	}
	if finish, allowed := restarted.Engine.AcquireProvider("p1", true); allowed {
		finish(true)
		t.Fatal("restart reset the shared account lease")
	}
	release(true)
	response, err = http.Get(endpoint + "/fixture/assert-empty")
	if err != nil {
		t.Fatal(err)
	}
	response.Body.Close()
	if response.StatusCode != 200 {
		t.Fatal("pool lease not released")
	}
	response, err = http.Post(endpoint+"/fixture/drop-next-claim", "application/json", nil)
	if err != nil {
		t.Fatal(err)
	}
	response.Body.Close()
	if finish, allowed := restarted.Engine.AcquireProvider("p1", false); allowed {
		finish(true)
		t.Fatal("unknown claim reply authorized an upstream call")
	}
	response, err = http.Get(endpoint + "/fixture/assert-direct-busy")
	if err != nil {
		t.Fatal(err)
	}
	response.Body.Close()
	if response.StatusCode != 200 {
		t.Fatal("unknown claim lost its durable lease")
	}
	response, err = http.Post(endpoint+"/fixture/expire-claims", "application/json", nil)
	if err != nil {
		t.Fatal(err)
	}
	response.Body.Close()
	if response.StatusCode != 200 {
		t.Fatal("bounded expired lease could not be reclaimed")
	}
}
