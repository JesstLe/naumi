package configuration

import (
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
	"sort"

	"github.com/JesstLe/naumi-router/internal/provider"
	"github.com/JesstLe/naumi-router/internal/routing"
)

func (m *Manager) ExportLegacy(engine *routing.Engine, registry provider.Registry) (Projection, []SealedCredential, error) {
	projection := Projection{Routes: []routing.Route{}, Providers: []ProviderSpec{}, Aliases: []routing.Alias{}}
	credentials := []SealedCredential{}
	limits := map[string]int{}
	for _, r := range engine.Routes() {
		if r.MaxConcurrent > 0 {
			limits[r.Provider] = r.MaxConcurrent
		} else {
			limits[r.Provider] = 4
		}
	}
	ids := make([]string, 0, len(registry))
	for id := range registry {
		ids = append(ids, id)
	}
	sort.Strings(ids)
	for _, id := range ids {
		generator := registry[id]
		var protocol, endpoint, key string
		switch p := generator.(type) {
		case *provider.OpenAIImages:
			protocol, endpoint, key = "openai-images", p.BaseURL, p.Key
		case *provider.APIMart:
			protocol, endpoint, key = "apimart-images", p.BaseURL, p.Key
			if endpoint == "" {
				endpoint = "https://api.apimart.ai"
			}
		case *provider.Fal:
			protocol, endpoint, key = "fal-images", p.BaseURL, p.Key
			if endpoint == "" {
				endpoint = "https://queue.fal.run"
			}
		default:
			continue // mock/unimplemented providers never become paid configured candidates
		}
		digest := hmac.New(sha256.New, []byte(m.options.EnvelopeSecret))
		digest.Write([]byte(id + "\x00" + provider.Identity(generator)))
		value := hex.EncodeToString(digest.Sum(nil)[:16])
		ref := value[:8] + "-" + value[8:12] + "-" + value[12:16] + "-" + value[16:20] + "-" + value[20:]
		sealed, err := SealCredential(m.options.EnvelopeSecret, id, ref, key)
		if err != nil {
			return Projection{}, nil, err
		}
		limit := limits[id]
		if limit == 0 {
			limit = 4
		}
		projection.Providers = append(projection.Providers, ProviderSpec{ID: id, Protocol: protocol, BaseURL: endpoint, CredentialRef: ref, TimeoutMS: 120000, MaxConcurrent: limit})
		credentials = append(credentials, sealed)
	}
	candidates := []string{}
	for _, r := range engine.Routes() {
		for _, p := range projection.Providers {
			if r.Provider == p.ID {
				projection.Routes = append(projection.Routes, r)
				candidates = append(candidates, r.ID)
				break
			}
		}
	}
	if len(candidates) > 0 {
		for _, a := range []struct {
			id   string
			rank int
		}{{"naumi-image-auto", 1}, {"naumi-image-economy", 1}, {"naumi-image-standard", 2}, {"naumi-image-premium", 3}} {
			projection.Aliases = append(projection.Aliases, routing.Alias{ID: a.id, Strategy: "lowest-cost", Candidates: candidates, MinQualityRank: a.rank})
		}
	}
	return projection, credentials, nil
}
func (m *Manager) BindLegacy(engine *routing.Engine, registry provider.Registry) error {
	keys := map[string]string{}
	for id, g := range registry {
		keys[id] = provider.Identity(g)
	}
	return engine.UseSharedHealth(m.health, keys)
}
