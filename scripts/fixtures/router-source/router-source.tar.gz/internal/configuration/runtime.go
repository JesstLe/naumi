package configuration

import (
	"context"
	"net"
	"net/http"
	"net/url"
	"regexp"
	"strings"
	"time"

	"github.com/JesstLe/naumi-router/internal/provider"
	"github.com/JesstLe/naumi-router/internal/routing"
)

var identifier = regexp.MustCompile(`^[A-Za-z0-9][A-Za-z0-9._:-]{0,99}$`)
var wireModelPattern = regexp.MustCompile(`^[A-Za-z0-9][A-Za-z0-9._:/-]{0,159}$`)

func validID(id string) bool { return identifier.MatchString(id) }
func metadataHost(host string) bool {
	if ip := net.ParseIP(host); ip != nil {
		if ip.Equal(net.ParseIP("fd00:ec2::254")) {
			return true
		}
		if v4 := ip.To4(); v4 != nil {
			return v4[0] == 169 && v4[1] == 254 || v4[0] == 100 && v4[1] == 100 && v4[2] == 100 && v4[3] == 200
		}
	}
	return strings.HasPrefix(host, "169.254.") || strings.HasPrefix(host, "metadata.") || host == "100.100.100.200"
}
func publicIP(ip net.IP) bool {

	if v4 := ip.To4(); v4 != nil && (v4[0] == 0 || v4[0] >= 224 || v4[0] == 100 && v4[1] >= 64 && v4[1] <= 127 || v4[0] == 198 && (v4[1] == 18 || v4[1] == 19)) {
		return false
	}
	return ip != nil && !ip.IsLoopback() && !ip.IsPrivate() && !ip.IsUnspecified() && !ip.IsLinkLocalUnicast() && !ip.IsLinkLocalMulticast() && !ip.IsMulticast() && !metadataHost(ip.String())
}
func (m *Manager) endpoint(endpoint string) (*url.URL, bool, error) {
	u, err := url.Parse(endpoint)
	if err != nil || u.Hostname() == "" || u.User != nil || u.RawQuery != "" || u.Fragment != "" || (u.Scheme != "http" && u.Scheme != "https") || metadataHost(strings.ToLower(u.Hostname())) {
		return nil, false, ErrInvalid
	}
	origin := u.Scheme + "://" + u.Host
	trusted := false
	for _, allowed := range m.options.TrustedOrigins {
		if allowed == origin {
			trusted = true
		}
	}
	host := strings.ToLower(u.Hostname())
	ip := net.ParseIP(host)
	if !trusted && (u.Scheme != "https" || ip != nil && !publicIP(ip) || host == "localhost" || strings.HasSuffix(host, ".internal") || !strings.Contains(host, ".")) {
		return nil, false, ErrInvalid
	}
	return u, trusted, nil
}
func (m *Manager) httpClient(p ProviderSpec, u *url.URL, trusted bool) *http.Client {
	if m.options.HTTPClient != nil {
		return m.options.HTTPClient
	}
	transport := http.DefaultTransport.(*http.Transport).Clone()
	transport.Proxy = nil
	transport.DialContext = func(ctx context.Context, network, address string) (net.Conn, error) {
		host, port, err := net.SplitHostPort(address)
		if err != nil || !strings.EqualFold(host, u.Hostname()) {
			return nil, ErrInvalid
		}
		ips, err := net.DefaultResolver.LookupIPAddr(ctx, host)
		if err != nil || len(ips) == 0 {
			return nil, ErrUnavailable
		}
		for _, ip := range ips {
			if metadataHost(ip.IP.String()) || !trusted && !publicIP(ip.IP) {
				return nil, ErrInvalid
			}
		}
		return (&net.Dialer{Timeout: 10 * time.Second}).DialContext(ctx, network, net.JoinHostPort(ips[0].IP.String(), port))
	}
	return &http.Client{Transport: transport, Timeout: time.Duration(p.TimeoutMS) * time.Millisecond, CheckRedirect: func(*http.Request, []*http.Request) error { return http.ErrUseLastResponse }}
}
func (m *Manager) build(input PreparedConfig) (*RuntimeSnapshot, error) {
	if len(input.Config.Providers) > 100 || len(input.Config.Routes) > 600 || len(input.Config.Aliases) > 200 {
		return nil, ErrInvalid
	}
	values := map[string]string{}
	owners := map[string]string{}
	for _, c := range input.Credentials {
		plain, err := OpenCredential(m.options.EnvelopeSecret, c)
		if err != nil {
			return nil, ErrInvalid
		}
		values[c.Ref] = plain
		owners[c.Ref] = c.ProviderID
	}
	registry := provider.Registry{}
	refs := map[string]string{}
	keys := map[string]string{}
	limits := map[string]int{}
	for _, p := range input.Config.Providers {
		if !validID(p.ID) || p.CredentialRef == "" || owners[p.CredentialRef] != p.ID || values[p.CredentialRef] == "" || registry[p.ID] != nil || p.TimeoutMS < 1000 || p.TimeoutMS > 900000 || p.MaxConcurrent < 1 || p.MaxConcurrent > 256 {
			return nil, ErrInvalid
		}
		u, trusted, err := m.endpoint(p.BaseURL)
		if err != nil {
			return nil, err
		}
		client := m.httpClient(p, u, trusted)
		switch p.Protocol {
		case "openai-images":
			registry[p.ID] = &provider.OpenAIImages{BaseURL: p.BaseURL, Key: values[p.CredentialRef], Client: client, TrustedHTTP: trusted}
		case "apimart-images":
			registry[p.ID] = &provider.APIMart{BaseURL: p.BaseURL, Key: values[p.CredentialRef], Client: client, MediaClient: m.options.HTTPClient, ConfiguredModels: map[string]bool{}}
		case "fal-images":
			registry[p.ID] = &provider.Fal{BaseURL: p.BaseURL, Key: values[p.CredentialRef], Client: client, ConfiguredModels: map[string]bool{}, MediaClient: m.publicMediaClient()}
		default:
			return nil, ErrInvalid
		}
		refs[p.ID] = p.CredentialRef
		keys[p.ID] = provider.Identity(registry[p.ID])
		limits[p.ID] = p.MaxConcurrent
	}
	for i := range input.Config.Routes {
		r := &input.Config.Routes[i]
		if !wireModelPattern.MatchString(r.UpstreamModel) || (r.UpstreamVersion != "" && !validID(r.UpstreamVersion)) || (r.UpstreamQuality != "" && !validID(r.UpstreamQuality)) {
			return nil, ErrInvalid
		}
		for _, segment := range strings.Split(r.UpstreamModel, "/") {
			if segment == "." || segment == ".." || segment == "" {
				return nil, ErrInvalid
			}
		}
		if !validID(r.ID) || registry[r.Provider] == nil || r.MaxConcurrent != limits[r.Provider] || len(r.MoneyPrices) > 36 || len(r.QualityMap) > 6 {
			return nil, ErrInvalid
		}
		switch p := registry[r.Provider].(type) {
		case *provider.APIMart:
			if r.SupportsMask {
				return nil, ErrInvalid
			}
			p.ConfiguredModels[r.UpstreamModel] = true
		case *provider.Fal:
			if r.SupportsMask {
				return nil, ErrInvalid
			}
			p.ConfiguredModels[r.UpstreamModel] = true
		}
		for _, v := range r.NativeResolutions {
			if v != "1K" && v != "2K" && v != "4K" {
				return nil, ErrInvalid
			}
		}
		for _, v := range r.SupportedQualities {
			if !validQuality(v) {
				return nil, ErrInvalid
			}
		}
		for k, v := range r.QualityMap {
			if !validQuality(k) || !validID(v) {
				return nil, ErrInvalid
			}
		}
		for tier, value := range r.ResolutionMap {
			if (tier != "1K" && tier != "2K" && tier != "4K") || !validID(value) {
				return nil, ErrInvalid
			}
		}
		if len(r.ResolutionMap) > 3 {
			return nil, ErrInvalid
		}
		if _, ok := registry[r.Provider].(*provider.OpenAIImages); ok {
			for _, tier := range r.NativeResolutions {
				if tier != "1K" && r.ResolutionMap[tier] == "" {
					return nil, ErrInvalid
				}
			}
		}
		seen := map[string]bool{}
		for _, p := range r.MoneyPrices {
			if p.Unit != "" && p.Unit != "image" && p.Unit != "item" && p.Unit != "task" {
				return nil, ErrInvalid
			}
			key := p.Resolution + ":" + p.Quality + ":" + p.Mode
			if seen[key] || p.AmountMicros < 1 || p.AmountMicros > 1_000_000_000_000 || p.Currency != "CNY" && p.Currency != "USD" || !validQuality(p.Quality) || p.Mode != "generate" && p.Mode != "edit" || p.Resolution != "1K" && p.Resolution != "2K" && p.Resolution != "4K" {
				return nil, ErrInvalid
			}
			seen[key] = true
		}
	}
	for _, a := range input.Config.Aliases {
		if !validID(a.ID) || len(a.Candidates) > 50 || len(a.Rules) > 1000 {
			return nil, ErrInvalid
		}
		for _, r := range a.Rules {
			if !validID(r.ID) {
				return nil, ErrInvalid
			}
			for _, q := range r.When.Quality {
				if !validQuality(q) {
					return nil, ErrInvalid
				}
			}
			for _, s := range r.When.Resolution {
				if s != "1K" && s != "2K" && s != "4K" {
					return nil, ErrInvalid
				}
			}
			for _, task := range r.When.Task {
				if task != "draft" && task != "product" && task != "detail" && task != "layout" {
					return nil, ErrInvalid
				}
			}
		}
	}
	engine, err := routing.NewConfiguredEngine(input.Config.Routes, input.Config.Aliases, m.health, keys)
	if err != nil {
		return nil, ErrInvalid
	}
	for _, p := range input.Config.Providers {
		m.health.LinkAccounts(keys[p.ID], "supplier:"+p.ID+":"+strings.TrimRight(p.BaseURL, "/"))
	}
	if m.options.CapacityAcquire != nil {
		engine.SetExternalCapacity(func(id string) (func(), bool) {
			for _, p := range input.Config.Providers {
				if p.ID == id {
					return m.options.CapacityAcquire(input, p)
				}
			}
			return nil, false
		})
	}
	return &RuntimeSnapshot{Digest: input.Digest, Engine: engine, Providers: registry, CredentialRefs: refs}, nil
}

func (m *Manager) publicMediaClient() *http.Client {
	if m.options.HTTPClient != nil {
		return m.options.HTTPClient
	}
	transport := http.DefaultTransport.(*http.Transport).Clone()
	transport.Proxy = nil
	transport.DialContext = func(ctx context.Context, network, address string) (net.Conn, error) {
		host, port, err := net.SplitHostPort(address)
		if err != nil {
			return nil, ErrInvalid
		}
		ips, err := net.DefaultResolver.LookupIPAddr(ctx, host)
		if err != nil || len(ips) == 0 {
			return nil, ErrUnavailable
		}
		for _, ip := range ips {
			if !publicIP(ip.IP) {
				return nil, ErrInvalid
			}
		}
		return (&net.Dialer{Timeout: 10 * time.Second}).DialContext(ctx, network, net.JoinHostPort(ips[0].IP.String(), port))
	}
	return &http.Client{Transport: transport, Timeout: 45 * time.Second, CheckRedirect: func(*http.Request, []*http.Request) error { return http.ErrUseLastResponse }}
}
func validQuality(q string) bool {
	return q == "auto" || q == "low" || q == "medium" || q == "high" || q == "xhigh" || q == "max" || q == "standard"
}
