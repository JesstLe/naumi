package configuration

import (
	"bytes"
	"encoding/json"
	"io"
	"net"
	"net/http"
	"net/url"
	"time"
)

// A lost callback leaves the durable slot until its bounded lease expires.
// No confirmed claim means no permission to submit a paid supplier request.
func NewCapacityClient(endpoint, token string) (func(PreparedConfig, ProviderSpec) (func(), bool), error) {
	u, err := url.Parse(endpoint)
	if err != nil || u.Scheme != "http" || u.Hostname() != "127.0.0.1" || u.Port() == "" || u.User != nil || u.RawQuery != "" || u.Fragment != "" || u.Path != "/api/internal/model-capacity" || len(token) < 32 {
		return nil, ErrInvalid
	}
	transport := http.DefaultTransport.(*http.Transport).Clone()
	transport.Proxy = nil
	transport.DialContext = (&net.Dialer{Timeout: 2 * time.Second}).DialContext
	client := &http.Client{Transport: transport, Timeout: 5 * time.Second, CheckRedirect: func(*http.Request, []*http.Request) error { return http.ErrUseLastResponse }}
	request := func(body any) (string, bool) {
		raw, err := json.Marshal(body)
		if err != nil {
			return "", false
		}
		req, err := http.NewRequest("POST", endpoint, bytes.NewReader(raw))
		if err != nil {
			return "", false
		}
		req.Header.Set("Authorization", "Bearer "+token)
		req.Header.Set("Content-Type", "application/json")
		response, err := client.Do(req)
		if err != nil {
			return "", false
		}
		defer response.Body.Close()
		if response.StatusCode != 200 {
			return "", false
		}
		var result struct {
			Token    string `json:"token"`
			Released bool   `json:"released"`
		}
		if json.NewDecoder(io.LimitReader(response.Body, 4097)).Decode(&result) != nil {
			return "", false
		}
		return result.Token, result.Released || len(result.Token) == 36
	}
	return func(input PreparedConfig, p ProviderSpec) (func(), bool) {
		token, allowed := request(map[string]any{"action": "acquire", "digest": input.Digest, "modelVersion": input.ModelVersion, "billingVersion": input.BillingVersion, "providerId": p.ID})
		if !allowed || token == "" {
			return nil, false
		}
		return func() { _, _ = request(map[string]string{"action": "release", "token": token}) }, true
	}, nil
}
