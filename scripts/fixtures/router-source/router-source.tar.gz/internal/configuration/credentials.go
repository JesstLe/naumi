package configuration

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"io"
)

func envelopeCipher(secret string) (cipher.AEAD, error) {
	if len(secret) < 32 {
		return nil, ErrInvalid
	}
	key := sha256.Sum256([]byte(secret))
	block, err := aes.NewCipher(key[:])
	if err != nil {
		return nil, ErrInvalid
	}
	return cipher.NewGCM(block)
}
func SealCredential(secret, providerID, ref, plain string) (SealedCredential, error) {
	gcm, err := envelopeCipher(secret)
	if err != nil || plain == "" || len(plain) > 16384 || providerID == "" || ref == "" {
		return SealedCredential{}, ErrInvalid
	}
	iv := make([]byte, gcm.NonceSize())
	if _, err = io.ReadFull(rand.Reader, iv); err != nil {
		return SealedCredential{}, ErrUnavailable
	}
	encrypted := gcm.Seal(nil, iv, []byte(plain), []byte(providerID+"\x00"+ref))
	split := len(encrypted) - gcm.Overhead()
	enc := base64.StdEncoding.EncodeToString
	return SealedCredential{Ref: ref, ProviderID: providerID, Ciphertext: Envelope{IV: enc(iv), Tag: enc(encrypted[split:]), CT: enc(encrypted[:split])}}, nil
}
func OpenCredential(secret string, sealed SealedCredential) (string, error) {
	gcm, err := envelopeCipher(secret)
	if err != nil {
		return "", ErrInvalid
	}
	decode := base64.StdEncoding.DecodeString
	iv, e1 := decode(sealed.Ciphertext.IV)
	tag, e2 := decode(sealed.Ciphertext.Tag)
	ct, e3 := decode(sealed.Ciphertext.CT)
	if e1 != nil || e2 != nil || e3 != nil || len(iv) != gcm.NonceSize() || len(tag) != gcm.Overhead() || len(ct) > 16384 {
		return "", ErrInvalid
	}
	plain, err := gcm.Open(nil, iv, append(ct, tag...), []byte(sealed.ProviderID+"\x00"+sealed.Ref))
	if err != nil || len(plain) == 0 {
		return "", ErrInvalid
	}
	return string(plain), nil
}
