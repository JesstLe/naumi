package configuration

import (
	"errors"
	"net/http"

	"github.com/JesstLe/naumi-router/internal/provider"
	"github.com/JesstLe/naumi-router/internal/routing"
)

var ErrInvalid = errors.New("invalid_configuration")
var ErrConflict = errors.New("configuration_conflict")
var ErrNotFound = errors.New("configuration_not_found")
var ErrUnavailable = errors.New("configuration_unavailable")

type Envelope struct {
	IV  string `json:"iv"`
	Tag string `json:"tag"`
	CT  string `json:"ct"`
}
type SealedCredential struct {
	Ref        string   `json:"ref"`
	ProviderID string   `json:"providerID"`
	Ciphertext Envelope `json:"ciphertext"`
}
type ProviderSpec struct {
	ID            string `json:"id"`
	Protocol      string `json:"protocol"`
	BaseURL       string `json:"baseUrl"`
	CredentialRef string `json:"credentialRef"`
	TimeoutMS     int    `json:"timeoutMs"`
	MaxConcurrent int    `json:"maxConcurrent"`
}
type Projection struct {
	Routes    []routing.Route `json:"routes"`
	Providers []ProviderSpec  `json:"providers"`
	Aliases   []routing.Alias `json:"aliases"`
}
type PreparedConfig struct {
	Digest         string             `json:"digest"`
	ModelVersion   uint64             `json:"modelVersion"`
	BillingVersion uint64             `json:"billingVersion"`
	Config         Projection         `json:"config"`
	Credentials    []SealedCredential `json:"credentials"`
}
type RuntimeSnapshot struct {
	Digest         string
	Engine         *routing.Engine
	Providers      provider.Registry
	CredentialRefs map[string]string
}
type PublicationStatus struct {
	ID     string `json:"id"`
	Digest string `json:"digest"`
	Phase  string `json:"phase"`
}
type Options struct {
	CapacityAcquire func(PreparedConfig, ProviderSpec) (func(), bool)
	EnvelopeSecret  string
	TrustedOrigins  []string
	HTTPClient      *http.Client
}
