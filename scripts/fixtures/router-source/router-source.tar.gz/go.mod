module github.com/JesstLe/naumi-router

go 1.25

require go.etcd.io/bbolt v1.4.3

require golang.org/x/sys v0.29.0 // indirect
