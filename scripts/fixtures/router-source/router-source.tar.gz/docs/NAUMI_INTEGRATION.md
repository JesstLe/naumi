# Naumi infinite-canvas integration

## Decision

Naumi calls New API as its unified internal gateway. New API forwards the stable Naumi image aliases to Naumi Router, which selects and translates the real upstream provider.

```text
Naumi /api/generate-image
  -> OpenAI SDK
  -> New API /v1/images/generations or /v1/images/edits
  -> Naumi Router /v1/images/generations or /v1/images/edits
  -> APIMart first route
  -> result bytes
  -> Naumi shape enforcement, configured media storage, artwork record, credit settlement
```

## Existing Naumi contract

The integration reuses Naumi without changing its canvas business logic:

- `src/app/api/generate-image/route.ts` calls `images.generate` for text-to-image and `images.edit` for one or more reference images.
- `src/lib/image-model-catalog.ts` already exposes OpenAI Images models to the canvas model picker.
- `src/lib/openai-base.ts` already supports an internal compatible base URL.
- Naumi normalizes reference inputs to clean PNG files before edit calls and persists returned data into its own storage.

Naumi Router therefore provides:

| Endpoint | Canvas use |
|---|---|
| `GET /v1/models` | configuration test and alias discovery |
| `POST /v1/images/generations` | text-to-image nodes |
| `POST /v1/images/edits` | reference-image generation, fusion, re-composition and ratio regeneration |

The edit endpoint accepts OpenAI-style multipart fields named either `image` or `image[]`, up to 15 PNG/JPEG/WebP inputs. APIMart receives them as base64 data URIs through its documented `image_urls` field.

The unmodified New API source already registers `/v1/images/edits`, parses multipart image-edit requests, and its OpenAI adaptor re-emits every `image`, `image[]`, indexed image field and optional mask. The relevant source is `router/relay-router.go`, `relay/helper/valid_request.go`, and `relay/channel/openai/adaptor.go` in the local New API repository.

## Naumi environment

Naumi points at New API, not at the router:

```env
OPENAI_BASE_URL=https://new-api.internal.example/v1
OPENAI_API_KEY=<New API internal service token>
OPENAI_IMAGE_MODEL=naumi-image-standard
OPENAI_IMAGE_MODELS=naumi-image-auto,naumi-image-economy,naumi-image-standard
```

Configure one OpenAI-compatible channel in New API:

```text
Base URL: http://naumi-router:8081
Channel key: <same value as NAUMI_ROUTER_TOKEN>
Models: naumi-image-auto, naumi-image-economy, naumi-image-standard, naumi-image-premium
```

Do not add `/v1` to the New API channel Base URL. Its OpenAI channel adaptor
appends the incoming `/v1/images/...` request path, so a `/v1` suffix here would
produce `/v1/v1/images/...` and return 404.

Database-stored Naumi admin settings override its environment values. The Naumi-to-New-API token and New-API-to-router token are distinct server-side credentials and must never be exposed to the browser. Naumi continues to settle its product credits; the internal New API token should not create a second customer charge.

The gateway may recognize the premium alias, but the current APIMart route is
not eligible for it. Do not expose premium in the canvas until a verified route
exists. Auto/economy/standard currently share one provider route; these aliases
do not yet demonstrate distinct upstream quality or cost tiers.

## Current capability boundary

- Text-to-image: implemented and APIMart paid-tested.
- Multi-reference edit: transport implemented, locally contract-tested, and paid-tested through APIMart at 1K.
- Exact custom canvas dimensions: Naumi continues to enforce final dimensions with Sharp after generation.
- Masks/inpainting: rejected explicitly rather than silently ignored; needs an edit provider with verified mask semantics.
- Transparent background: not yet a guaranteed router capability; Naumi's existing dedicated cutout path should remain in place.
- APIMart commercial use: production traffic remains blocked until written product-integration authorization is obtained.

## Acceptance gate

Before enabling the router in the real canvas:

1. [x] run one paid APIMart edit with the user's product image;
2. [x] verify subject preservation, 1254×1254 output, 51-second duration and `$0.0085` settled cost;
3. [x] configure an unmodified local New API channel for Naumi Router;
4. [x] run Naumi `canvas-generation-smoke` through New API with both the default `standard` alias and an explicit `economy` model switch;
5. [x] verify Naumi credit refund on a pre-submit no-eligible-route rejection (422), without a paid provider task;
   - [ ] separately verify timeout and upstream terminal-failure settlement;
6. [ ] keep the existing cutout route separate until mask and alpha behavior are verified.

The browser-only selector assertions in `canvas-model-switch-smoke` remain
covered by their existing fixture test; the full gateway smoke verifies that an
explicitly selected alias reaches the real Naumi generation API. See the
[full-chain smoke record](research/2026-09-19-new-api-chain-smoke.md).

Server acceptance on 2026-09-19 exposed and fixed an execution/catalog mismatch:
Naumi's alias catalog supported edits but generation still gated reference
dispatch on a `gpt-image` prefix. Commit `3c9d995` uses the shared capability
predicate for both normal edit and ratio-regeneration branches. Regression
fixtures verify multipart image forwarding; the isolated server then completed
a real reference edit and displayed the saved image in the browser. See the
[server acceptance report](research/2026-09-19-server-canvas.md).
