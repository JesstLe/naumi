# New API and Naumi full-chain smoke — 2026-09-19

## Result

Follow-up correction: the original smoke established job completion and credit
settlement but did not assert that Naumi forwarded reference files. A later
server acceptance review found that Naumi's execution branch still limited
edits to `gpt-image*`, even though the catalog advertised the Naumi aliases as
edit-capable. Naumi commit `3c9d995` fixes normal edit and ratio-regeneration
branches; its regression fixture asserts `/v1/images/edits` and an actual
multipart image for both cases. Do not use the original smoke alone as evidence
of reference preservation.

PASS for the zero-cost integration chain:

```text
Naumi canvas /api/generate-image
  -> New API v1.0.0-rc.38
  -> Naumi Router
  -> mock provider
```

No APIMart or other paid upstream request was made in this smoke test.

## Environment

- New API image: `calciumion/new-api:latest`
- Pulled digest: `sha256:0a4d62b1b2b796a43a5e0ef92d49f12e0f229ab206b8f5a3a4cd42990121bfe1`
- Reported version: `v1.0.0-rc.38`
- New API test URL: `http://127.0.0.1:3100`
- Router URL from the New API container: `http://host.docker.internal:8081`
- Router routes: `config/routes.example.json` mock routes
- Naumi: isolated Next.js development instance and ephemeral PostgreSQL 16

All administrator passwords, New API tokens, Router tokens and database
passwords were generated or loaded at runtime. The harness does not print them
or store them in versioned files.

## Contract checks

The gateway-level smoke verified:

- four public aliases are visible through New API: `auto`, `economy`,
  `standard`, and `premium`;
- `POST /v1/images/generations` returns one OpenAI-shaped base64 image;
- `POST /v1/images/edits` forwards the multipart reference image and returns
  one OpenAI-shaped base64 image;
- New API and Router service credentials remain separate from customer-facing
  Naumi authentication.

The Naumi-level smoke verified twice:

1. default `naumi-image-standard` reference-image generation;
2. explicit `naumi-image-economy` reference-image generation.

Both runs returned one image, persisted the generated artwork and parent/batch
relationship, and settled exactly 6 Naumi credits. The first run moved the
test account from 30 to 24 credits; the second moved it from 24 to 18.

## Compatibility findings

Two integration details were found by executing the real image:

1. New API `v1.0.0-rc.38` returns a short-lived dashboard JWT from login. The
   management API requires that bearer token plus `New-Api-User`; its cookie is
   only a session marker. The smoke harness accepts both this response shape
   and the older cookie-backed response shape in the local source snapshot.
2. The OpenAI channel Base URL must not end in `/v1`. New API appends the
   incoming `/v1/images/...` path itself. A Base URL ending in `/v1` produces a
   double `/v1/v1/...` path and a 404.

Naumi also needed to mark the four `naumi-image-*` aliases as edit-capable;
otherwise it rejected reference images before calling New API.

## Replay

The replay harness is `scripts/new-api-chain-smoke.sh`. It requires a fresh,
uninitialized New API data volume and refuses to mutate an initialized
instance.

```bash
set -a && source .env && set +a
RUN_NAUMI_SMOKE=1 scripts/new-api-chain-smoke.sh
```

## Remaining gates

- exercise and verify Naumi credit refunds for gateway 4xx, timeouts and
  provider terminal failures;
- replace static route health and estimated costs with persisted observations;
- resolve the current Naumi production dependency audit before deployment;
- obtain written APIMart product-integration authorization before routing
  commercial traffic;
- keep cutout/mask/transparent-background traffic on the existing dedicated
  path until those capabilities are verified.

The dependency audit taken after `npm ci` reported 1 critical and 4 high
production dependency findings, centered on the current Next.js version plus
Sharp, Nodemailer, Nanoid and PostCSS transitive paths. No dependency upgrade
was attempted in this routing integration slice because the available Next.js
fix is a major-version change requiring its own regression pass.
