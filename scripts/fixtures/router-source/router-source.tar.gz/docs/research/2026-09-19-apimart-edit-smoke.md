# APIMart 1K reference-image edit smoke test

- Date: 2026-09-19
- Authorization: user explicitly approved one paid edit request
- Route: `apimart-gpt-image-2.5-ext-flare`
- Input: user-provided NexFort package photograph
- Input SHA-256: `636c1a85665e45c66bd7bfa2f98f35e0e25869434dea37c502c7c0b9c2f7b377`
- Output: [`assets/apimart-edit-1k-nexfort.png`](assets/apimart-edit-1k-nexfort.png)
- Output SHA-256: `7d21fe7e1298c8a0dc595f62ea6b09bec5159259e488508757fc4851b6be112f`

## Request

One reference image was sent to Naumi Router's OpenAI-compatible multipart `/v1/images/edits` endpoint. The router encoded it as an APIMart `image_urls` data URI and requested one 1K Flare output. The prompt asked for a pale-green ecommerce studio background while preserving the complete product and all package content.

## Result

| Metric | Observed |
|---|---:|
| HTTP status | 200 |
| End-to-end duration | 51 seconds |
| Output format | PNG, RGB |
| Output dimensions | 1254×1254 |
| APIMart settled cost | `$0.0085` |
| APIMart Credits cost | `0.085` |
| Cash cost at `$1 = ¥7` | `¥0.0595` |

The front logo, English product name, product type, `10.2mg`, net content, and Belgian inulin statement remained visually recognizable and correctly placed. The model successfully replaced the original gray scene with a pale-green commercial background and kept the box geometry close to the reference.

## Acceptance boundary

- **Pass** for Naumi canvas reference-image generation, background replacement, visual variation, and ecommerce scene composition.
- **Not a pixel-exact packaging workflow.** Tiny side-panel copy cannot be verified as unchanged and generative editing may redraw fine label details.
- Exact packaging delivery should keep the original product pixels and use segmentation/compositing over a generated background; generative output must not replace the authoritative packaging source.

## Integration conclusion

The paid test closes the APIMart text-plus-reference transport gate. The next gate is not another provider call: configure Naumi Router as an OpenAI channel in an unmodified New API instance and run Naumi's real canvas generation and model-switch smoke suites through the full chain.
