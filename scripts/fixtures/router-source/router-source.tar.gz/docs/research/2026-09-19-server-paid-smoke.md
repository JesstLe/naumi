# Server 1K smoke: passed after private proxy integration

## Successful completion

After the user authorized reuse of the workstation's Clash configuration, the
currently selected node was copied as a private snapshot to the server.
Mihomo runs independently of the workstation, only on `127.0.0.1:17890`, with
node configuration owned by its dedicated service user and mode `0600`.
No subscription URL or node credential was committed or printed.

Router commit `d91c31b` uses the proxy for APIMart API calls while downloading
media directly with the existing public-IP and HTTPS redirect restrictions.
The API model list passed with HTTP 200 before submitting the approved image.

| Measurement | Result |
| --- | --- |
| Start time | 2026-09-19 09:57:36 UTC |
| Path | New API -> Router -> Mihomo -> APIMart; image CDN direct |
| Public model | `naumi-image-standard` |
| Provider model | `gpt-image-2.5-ext` / Flare / 1K / one image |
| HTTP status | 200 |
| Gateway elapsed | 36.276617 seconds |
| Router elapsed | 36.164 seconds |
| Router request ID | `146cca21d62333b6550f3b45` |
| APIMart task ID | `task_01M2WHK71CBJM1GSK6598CG7S6` |
| Provider task status | completed |
| Settled task cost | USD 0.0085 / 0.085 Credits |
| CNY at user's USD 1 = CNY 7 | CNY 0.0595 |
| Output | PNG, 1254 x 1254, RGB |
| SHA-256 | `b1d822c167c743293dc9264bec20a2cdd3bd97191a6e2d3c460d73eafaf4c65c` |

The settled task cost was independently re-read from APIMart's task endpoint
after success and matched Router's receipt. It was not independently reconciled
with the account's wallet balance. One successful image was generated.

Visual inspection confirmed the requested green cosmetic bottle, blank cream
label, stone pedestal and botanical shadows, without visible text or watermark.
This simple image is a connectivity test, not an overall quality benchmark.
The 1K tier again produced 1254 x 1254 rather than exactly 1024 x 1024.

Artifacts reside on the server at
`/var/lib/naumi-gateway/smoke/approved-1k-20260919-proxy/`; a local image copy is
in ignored `artifacts/server-1k-20260919/image.png`. The three services remained
active. Naumi's running provider has not been switched.

Verification: `go test ./...`, `go vet ./...`, private-destination media
regression coverage with HTTPS_PROXY set, local-only proxy listener, secret
file permissions, authenticated API probe and the single paid gateway request.

## Earlier failed attempt

The user approved one 1K APIMart image. One gateway request was made at
2026-09-19 09:25:42 UTC through New API and Router, returning HTTP 502 after
60.052130 seconds. No image or provider task ID was returned.

Router request ID: `5e2bf2d830735db4c4171d55`.

The adapter failed while establishing TCP connections to APIMart, before
sending its HTTP generation request. Its two internal attempts shared the
same logical operation; both failed during connection establishment. No
additional gateway submission was made. There is no upstream billing receipt;
zero-valued log fields on this error are defaults, not billing evidence.

## Evidence

- Server system DNS returned `199.59.149.201` for `api.apimart.ai`.
- Independently queried Google and Cloudflare DNS-over-HTTPS services returned
  the same three A records: `104.26.11.94`, `172.67.70.35`, `104.26.10.94`.
- Server TCP connection to its system-resolved address timed out.
- Read-only HTTPS probes using each of the three independently resolved
  addresses, preserving the hostname/SNI and certificate validation, failed
  with `Recv failure: Connection reset by peer`.
- The workstation reached the same HTTPS hostname with certificate validation
  succeeding (root path returned HTTP 404, demonstrating HTTP reachability).
- Neither gateway service stopped. No running proxy service or listener was
  found among the inspected common proxy names/ports; this is not an exhaustive
  inventory of possible egress services.

The evidence establishes a server-specific outbound connectivity problem.
Changing only the DNS answer did not restore HTTPS. No TLS validation was
disabled and no global DNS or production Naumi configuration was changed.

## Earlier artifacts and resolution

Server artifacts are under
`/var/lib/naumi-gateway/smoke/approved-1k-20260919/`: the request, error response,
timing summary and Router receipt log. They contain no authorization token.
The reproducible one-shot harness is `scripts/server-paid-smoke.sh`; it refuses
to overwrite an existing output directory and does not retry gateway requests.

The proxy setup and approved image test were subsequently completed as recorded
above. The imported node is not automatically refreshed from a subscription;
updates require copying the authorized configuration again. Future CDN changes
still need direct reachability because the media downloader intentionally does
not inherit the API proxy.
