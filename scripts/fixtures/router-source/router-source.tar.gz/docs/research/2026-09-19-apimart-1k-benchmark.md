# APIMart 1K benchmark summary

- Run date: 2026-09-19
- Route: `gpt-image-2.5-ext` / `flare` / `1K`
- Reliability: 10/10 HTTP 200 and downloaded successfully
- Format: all PNG, 1254×1254
- Batch cost: $0.085 / 0.85 Credits / ¥0.595 at $1 = ¥7
- Latency: 29.03s minimum, 46.15s median, 42.68s mean, 56.94s maximum
- Human acceptance: 9/10

The passing cases covered product photography, exact Chinese copy, exact English poster copy, seven-object composition, logo generation, rainy Shanghai photorealism, children's illustration, a five-person scene, and precise surreal composition. The failed case asked for exactly two hands but returned three.

Decision: use APIMart for visual assets, but keep dense commerce copy, product facts, layout, and long-image assembly deterministic. See [JD product-detail style target](2026-09-19-jd-detail-style.md).

Raw images, request metadata, and the APIMart usage snapshot remain in the local ignored artifact directory:

`artifacts/apimart-1k-v1-20260919T061144Z/`
