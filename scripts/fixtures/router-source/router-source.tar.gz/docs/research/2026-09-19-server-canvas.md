# Server Naumi canvas acceptance — 2026-09-19

## Outcome

PASS for the isolated test canvas: Naumi → private New API → Naumi Router →
APIMart → persisted media/artwork → canvas display. The original Naumi app,
database and media were not switched or reused. This is technical acceptance,
not commercial authorization or a production cutover.

## Deployment and regression fix

- Test app: `/opt/naumi-gateway/canvas-test`, Compose project
  `naumi-gateway-canvas-test`, app `127.0.0.1:3013`, DB `127.0.0.1:15433`.
- Pinned Naumi image: `3c9d995f767f48ae688c84240835e8316754c06e`.
- Build: [GitHub Actions 35436655840](https://github.com/JesstLe/naumi/actions/runs/35436655840), successful.
- Offline image artifact SHA-256:
  `4516c1f96bae7538c11616c15f3f4eedab24fc742012f788a95fc4417696ba7c`;
  checked on the server before loading. No GitHub credentials copied to server.
- Router code remains `d91c31b`, with the previously verified private Mihomo
  egress. API traffic uses the local proxy; asset fetches retain public-IP SSRF
  validation and direct transport.
- Naumi fix `3c9d995`: replace the generation route's `gpt-image` prefix gate
  with `isOpenAIImagesEditModel` for both reference-edit branches. Before this
  fix an alias could advertise edit support yet silently issue text-to-image.
- Local regression: seven browser/contract checks passed, including normal
  edits and both ratio-regeneration values reaching multipart `/v1/images/edits`
  with an image. TypeScript check passed.

## One paid reference edit

Input: Naumi's existing `public/demos/suite-before.webp` portable-fan image.
Requested: preserve product shape, light-gray studio background, 1K, 1:1,
one image, `naumi-image-standard`.

| Evidence | Result |
|---|---|
| Naumi job | `job-1789812945207-923779` |
| Router request | `331d26f651d50b8f76c93a86` |
| APIMart task | `task_01M2WJMF50RRMB9XPKWFQBX9EC` |
| Job duration | 39,370 ms (Router 38,244 ms) |
| Output | PNG, 1254 × 1254 |
| Provider receipt | Completed; USD 0.0085; credits_cost 0.085 |
| Upstream CNY cost | 0.0595 at the user's recharge rate USD 1 = CNY 7 |
| Naumi available credits | 30 → 24; exactly six settled |
| Persisted / mock | true / false |
| Artwork | `gen-1789812983769-839208-0` |
| Reference parent | `art-1789812945035-366022` |
| Batch | `b-1789812984007-9129` |

The upstream receipt was independently re-read after generation. Visual review
found the recognizable fan shape, colors and materials retained, with the
requested studio background/shadow. One sample is not an identity-preservation
benchmark. The cost excludes gateway hosting, storage, bandwidth and other
business costs; product credits are not equivalent to provider credits.

## Failure, persistence and browser checks

- Temporarily offered premium only in this private instance to exercise a
  no-eligible-route rejection before provider submission. Job
  `job-1789812984682-244832` ended in error, available credits remained 24,
  no new artwork was added and no paid provider task was submitted.
- Removed premium from the final configuration and recreated the test app.
  The account, reference and generated artwork survived; available credits
  remained 24. Test DB: one user, two artworks, zero pending reservations.
- Browser opened the saved artwork deep link, showed original and generated
  nodes, selected economy and retained that selection after reload. No browser
  page errors. Browser verification submitted zero additional paid requests.
- Final exposed aliases: auto, economy, standard. They currently use the same
  eligible APIMart route, not three independently benchmarked quality tiers.
- Original DB counts before/after: 38 users and 170 artworks. Original app image
  remains `1528da1b1c5db40063b81b84dadadc1b4d572608`.

The browser harness initially opened a blank new-project canvas; correcting it
to the saved-artwork deep link resolved that test-navigation error. It was not
evidence of lost generated artwork.

## Reproducible evidence and rollback

- Versioned one-shot paid acceptance: `scripts/canvas-server-acceptance.mjs`.
  It refuses reuse of its output directory to avoid blind paid replays.
- Versioned no-generation browser check: `scripts/canvas-server-browser.mjs`.
- Local ignored artifacts: `artifacts/server-canvas/summary.json`,
  `artifacts/server-canvas/generated-image.png`,
  `artifacts/server-canvas-browser/summary.json`, and
  `artifacts/server-canvas-browser/canvas.png`.
- Server evidence: `/opt/naumi-gateway/canvas-test/acceptance-result`; original
  results also persist in the test app volume under `/data/gateway-acceptance`.
- Test secrets remain in root-only `.env`; no credentials in these records.
- Stop only the isolated instance using the commands in
  [CANVAS_TEST.md](../../deploy/server/CANVAS_TEST.md). Keep volumes for recovery.

## Remaining gates

No existing-user deployment cutover was performed. Timeout/terminal-provider
failure settlement, independently validated backup-provider fallback, 2K/4K
quality/cost, commercial upstream authorization and production security review
remain separate gates. This run consumed exactly one additional paid image.
