# JD product-detail style target

- Reference: [JD product 10195051622782](https://npcitem.jd.hk/10195051622782.html)
- Inspected: 2026-09-19 in the authenticated desktop page
- Purpose: define the visual/product target for Naumi's image-generation workflow

## What the reference actually is

The target is not one unconstrained AI poster. It is a vertical sequence of commerce modules rendered as background-image sections. The inspected page used a 710 px on-page content column, with source assets commonly around 750 px wide and heights ranging from roughly 736 to 1766 px; one combined section was 790×3360.

The sequence mixes:

1. brand history and authority;
2. overseas availability, certification, and reputation;
3. product hero and primary benefit;
4. lifestyle scenes aimed at the target customer;
5. ingredient and formulation explanations;
6. mechanism/benefit diagrams;
7. supporting evidence and citations;
8. usage instructions and package information;
9. qualification, safety, and legal notices.

## Visual grammar

- Large Chinese headlines, usually one idea per screen.
- Product packaging repeatedly anchors the bottom or side of a module.
- Full-bleed lifestyle photography alternates with clean infographic sections.
- A restrained brand palette repeats across modules; this item uses light blue, white, black, gold, and selective red.
- Trust evidence appears visually, not as a wall of body copy: badges, maps, dates, certifications, and short proof statements.
- Fine print and citations are present but subordinate.
- The narrative order is persuasion-first: trust → problem/benefit → explanation → proof → usage → compliance.

## Product decision

Naumi should generate this style through a hybrid modular pipeline, not by asking one model for a complete long image.

```text
Product facts + reference images
  -> claim/compliance review
  -> module plan and copy
  -> AI-generated product/lifestyle/illustration assets
  -> deterministic typography and module templates
  -> long-image assembly
  -> visual/OCR/compliance QA
  -> export
```

The image model owns pixels that benefit from generative variation: clean product scenes, lifestyle photography, atmospheric backgrounds, icons, and explanatory illustrations. Code owns text, measurements, hierarchy, repeated product identity, legal copy, and the final long-canvas geometry.

## Initial page specification

- Canvas: 790 px wide source export; responsive preview may render at 710 px.
- Length: 8–12 modules, typically 8,000–15,000 px total.
- Module templates:
  - hero/product promise;
  - three-benefit summary;
  - target-customer lifestyle;
  - ingredient/formulation cards;
  - mechanism diagram;
  - proof/certification;
  - directions/package details;
  - compliance footer.
- Copy must remain editable text until final raster export.
- Every factual claim requires a source field and approval state.
- Product packaging must come from user-provided reference assets; generated labels cannot be treated as the real product.
- Export must run OCR comparison against the approved copy and fail on omissions or substitutions.

## Benchmark impact

The first APIMart 1K run achieved 9/10 acceptance at ¥0.595 total. Product photography, Chinese headlines, posters, logos, scenes, and illustrations were strong. The one failure was a hard anatomy/count constraint: a two-hand request produced three hands.

That result supports APIMart as an asset generator but not as the final layout engine. Even though the tested Chinese poster was exact, dense product-detail copy must still be typeset deterministically.

## Next build slice

Build one end-to-end detail-page prototype from real product inputs:

1. ingest 3–5 real product images and verified product facts;
2. produce a module plan and editable copy;
3. generate four visual assets through APIMart;
4. render an eight-module 790 px-wide long image with HTML/CSS or SVG;
5. verify OCR, pixel dimensions, claim provenance, and final preview.

This slice proves the sellable product. Adding more providers before this page pipeline works would optimize the wrong layer.
