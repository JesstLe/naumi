# Isolated server staging record

Date: 2026-09-19

## Scope

The gateway was installed beside the existing Naumi deployment without
changing Naumi's running image provider or customer traffic:

```text
/opt/naumi-gateway/releases/fcbab7d-20260919T083642Z
  -> /opt/naumi-gateway/current
```

The deployed Router corresponds to commit `fcbab7d`. New API is the official
`v1.0.0-rc.38` Linux amd64 release with SHA-256:

```text
87aef2a18fc453f4082342a1a3bc1da1080b31790648c26d050d7b032505dac1
```

The hash was checked against the release's official `checksums-linux.txt`
before installation.

## Isolation and state

- `naumi-router.service` runs as the dedicated `naumi-gateway` user and binds
  `127.0.0.1:8081`.
- The upstream New API binary has no bind-address option and opens `*:3100`.
  Its systemd unit denies all IP traffic except localhost. A connection to
  server port 3100 from outside timed out, while localhost health checks passed.
- New API uses a fresh SQLite database under
  `/var/lib/naumi-gateway/new-api`; the stopped legacy `/opt/api-relay` state
  was not reused.
- Provider, Router, session, admin, and internal-token secrets are stored only
  in root-owned mode-0600 files under `/etc/naumi-gateway`.
- Public registration and password registration are both disabled.

## Non-billable verification

The following checks passed without submitting an image generation upstream:

- Router `/readyz` returned ready.
- New API `/api/setup` reported initialized.
- Exactly one `Naumi Router` channel and one `Naumi Internal` token exist.
- `/v1/models` returned `naumi-image-auto`, `naumi-image-economy`,
  `naumi-image-standard`, and `naumi-image-premium`.
- A generation request with no prompt traversed New API and stopped in Router
  validation with HTTP 422 `prompt is required`; it could not reach APIMart.
- Both systemd services remained active. Observed RSS was approximately 7 MiB
  for Router and 127 MiB for New API.

No paid server-side image request was made, and Naumi was not switched to this
gateway. Those remain separate approval gates.

This paragraph describes the initial staging checks. The subsequently approved
one-image test is recorded in [server paid smoke](2026-09-19-server-paid-smoke.md):
the gateway was reached but server egress failed before APIMart submission.
