# Durable image routing

The supported boundary is `Naumi -> private New API -> Naumi Router -> supplier`.
New API keeps authentication, protocol forwarding and account management. Router owns
supplier execution, capabilities, request estimates and runtime health.

## Request contract

Use a stable operation ID for each paid image operation:

```json
{
  "model": "naumi-image-auto",
  "prompt": "A product photo",
  "n": 1,
  "size": "1024x1024",
  "quality": "medium",
  "extra_fields": {
    "naumi": {
      "operation_id": "job-12345:image:0",
      "resolution": "1K",
      "task": "product",
      "preserve_identity": false,
      "text_accuracy": "auto"
    }
  }
}
```

For multipart edits, `extra_fields` is one form field containing the JSON string.
Naumi freezes quality and compiled generation prompts in its durable job.
An ID reused with different content returns 409. Completed results replay without
another supplier POST. Accepted APIMart/fal tasks recover by polling their saved
task ID. Unknown submission outcomes return 504 and require reconciliation; they
never trigger a fresh supplier POST, even when a supplier supports expiring
idempotency keys. Disable custom New API retries for 504/524 and never route these
operations into unrelated image channels as fallback.

`NAUMI_ALLOW_LEGACY_REQUESTS=true` permits clients without IDs and removes recovery
guarantees for those requests. Keep it unset in production.

## Capability and cost policy

`draft` requires quality rank 1; `product`, `detail` and `layout` require rank 2;
`layout` also requires text accuracy. Explicit quality and aliases may raise the
minimum rank. References require edit support, reference capacity and any requested
identity preservation. Requested resolution filters pixel/native capabilities
before sorting by estimated total cost, expected latency and route ID.

Each route can declare an exact price matrix. The following values are **mock
examples**, not supplier quotes:

```json
"prices": [
  {"resolution":"1K","quality":"medium","mode":"generate","cost_microusd":21000},
  {"resolution":"1K","quality":"medium","mode":"edit","cost_microusd":25000},
  {"resolution":"2K","quality":"high","mode":"edit","cost_microusd":60000}
]
```

The price is per image and multiplied by `n`. A matrix with no matching tier
excludes the route. Old flat prices remain compatible and are marked `legacy_flat`;
they cannot substantiate production savings. Configure verified supplier prices
and capabilities before enabling automatic cost selection. Task requirements are
explicit rules, not an unvalidated AI prompt difficulty classifier.

Supplier receipts and estimates are separate. `CostReported` distinguishes a
reported zero from a missing cost. APIMart terminal failure allows fallback only
when its receipt explicitly reports zero monetary and credit cost. Ordinary
OpenAI Images providers without billing receipts have unknown actual cost.

Providers share a bounded concurrency limit (default 4). Three real failures open
a 60-second circuit; one real request tests half-open recovery. Saved accepted
tasks can still poll while a circuit is open, subject to concurrency limits.
No paid health probes are issued.

## Adding a supplier

APIMart and fal retain their native task adapters. Compatible synchronous Images
services can be declared in `providers` with `protocol: "openai-images"`,
`base_url_env` and `api_key_env`; credentials remain environment variables.
Use an HTTPS base URL with `/v1` when required by that provider. Add a disabled route,
verify its model, b64 response, edits, reference limits, price tiers and quality,
then enable it. Generic adapters reject unsupported native 2K/4K requests and never
assume supplier idempotency. A provider requiring URL downloads, native resolution
parameters or asynchronous tasks needs an appropriate native adapter.

## State, reconciliation and release

Set `NAUMI_STATE_DIR` to a persistent private directory. Systemd uses
`/var/lib/naumi-gateway/router`; Docker uses `/data/router`. One Router process owns
the bbolt file. Replicas with separate ledgers cannot provide shared idempotency;
horizontal deployment requires a shared transactional execution store.

Authenticated internal endpoints:

- `GET /internal/operations/{operation_id}`: pinned route/account fingerprint,
  task ID, attempts, estimated prices, durations and supplier receipts.
- `GET /internal/health`: provider concurrency and circuit state.
- `/healthz` and `/readyz`: actual build version and readiness.

Check uncertain submissions against supplier task/billing records. Do not mint a
new operation ID, delete the ledger, rotate the original supplier credentials or
refund pending business reservations merely because a request timed out. This
release has no automatic reconciliation/refund job or state retention cleanup.
Monitor private result storage capacity; keep ledger/results for the supported
business recovery period and backup them together while Router is stopped.

New API itself can charge its internal quota/log a second time when Router replays
a completed HTTP 200. Naumi now caches completed paid results to minimize this
window, but New API has no billing deduplication across that crash window. Keep
this gateway internal and do not expose it as a billing-correct public resale API
without a separate New API billing idempotency implementation.

The installer preserves existing route/provider configuration, backs up New API
SQLite consistently and Router state while stopped, and never enables a new
provider or replaces live prices. If the new Router has started, automatic rollback
to a binary without the execution ledger marker stops the isolated services for
operator reconciliation rather than allowing old code to replay paid work.

## Validation boundary

Go fixtures cover duplicate/conflicting IDs, concurrent claims, restart recovery,
GET-only accepted-task recovery, unsafe submissions, orphan result receipts,
price matrices, health and protocol payloads. Naumi's isolated PostgreSQL fixture
uses its actual generation/suite/A+ routes, records JSON/multipart requests,
simulates an ambiguous result, recovers jobs and verifies one business settlement.
It also covers non-Router/BYOK guards and a crashed Canvas submission. No live paid
supplier request or fresh New API binary end-to-end run was performed for this
change. Production prices, provider quality and live health still need server
verification after deployment.

Recovery pins the managed gateway endpoint/account fingerprint. Set `NAUMI_ROUTER_STATE_DOMAIN` to identify the persistent Router state domain; changing it pauses pending recovery. A New API channel must not be redirected to an independent Router ledger while operations are pending. Migrate the ledger and results together when moving the service.
