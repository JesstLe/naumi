# Completed goal: server canvas integration

Started 2026-09-19 at the user's request to define a goal and continue.

Connect a server-side Naumi test canvas to private New API, Naumi Router and
APIMart; verify reference-image generation, persisted artwork/parent links and
credit settlement, plus a no-charge failure/refund case. Keep existing Naumi
users, media and configuration intact and preserve a clear rollback path.

## Plan and acceptance

- [x] Confirm gateway paid image test and private proxy egress.
- [x] Confirm latest Naumi integration image passed GitHub build CI.
- [x] Fix reference-image dispatch for Naumi aliases and verify both edit branches.
- [x] Start a separate same-server canvas instance with isolated DB and media.
- [x] Complete one 1K reference-image request from the canvas API.
- [x] Verify artwork persistence, parent links and exactly 6 credits settled.
- [x] Verify an upstream rejection refunds its reservation without a paid call.
- [x] Verify browser-visible canvas and model picker.
- [x] Preserve runtime evidence, rollback steps and versioned acceptance scripts.

Completed 2026-09-19. See the [server canvas acceptance report](research/2026-09-19-server-canvas.md).
Naumi's reference-dispatch fix is pushed as `3c9d995`; this goal and its Router
acceptance evidence are committed together. Production cutover is a separate
milestone, not part of this completed isolated acceptance goal.

Existing Naumi stays at its current deployment while this test instance is
validated. The test image is pinned to `3c9d995f767f48ae688c84240835e8316754c06e`.
The server-side test service listens only on `127.0.0.1:3013`, accessible
through an SSH tunnel. The premium alias has no eligible APIMart route and must
not be offered in the final test UI. It may be enabled temporarily only to
exercise zero-charge upstream rejection/refund.
