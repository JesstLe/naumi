# Private model configuration control plane

The generation listener does not expose configuration writes. Enabling management
requires `NAUMI_ROUTER_MANAGEMENT_TOKEN` and `MODEL_CONFIG_ENVELOPE_SECRET`, each at
least 32 characters, distinct from each other and from the generation token.
Leave the management token unset to keep the control plane disabled.

Management-enabled processes also require `NAUMI_MODEL_CAPACITY_URL`, the exact
loopback callback `http://127.0.0.1:3012/api/internal/model-capacity` for this
deployment. The callback uses the independent management token. Naumi checks the
retained digest/version/provider and obtains its PostgreSQL account lease; Router
never sends credentials or chooses a different limit. Direct and mixed calls,
including retained direct versions, therefore share one durable budget. An
unavailable or ambiguous callback denies submission. A process crash or lost
release cannot reset the budget; the bounded lease expires after the configured
provider timeout plus 60 seconds. Do not expose this callback on public ingress.

Management listens on `127.0.0.1:8082` by default. Keep it loopback-bound for the
existing systemd deployment and proxy only the exact routes in the private bridge
server block, using `deploy/server/model-management.nginx.example.conf`. Do not
make the original read-only BI proxy a generic writable proxy. Container installs
must publish the management port to loopback only and explicitly configure their
private listener. Public requests to the normal listener receive 404.

`NAUMI_CONFIG_STATE_DIR` defaults to `$NAUMI_STATE_DIR/configurations`. Its bbolt
database is mode 0600 and stores immutable preparations and AES-GCM credentials.
Back up that directory together with execution state. Losing or changing the
envelope secret prevents recovering historical runtimes; never rotate it by merely
replacing the environment variable. Provider key rotation uses a new credential
reference and retains old envelopes.

Prepare payloads have modelVersion, billingVersion, config (routes/providers/
aliases), credentials, and digest. Digest is SHA-256 of canonical JSON containing
only modelVersion, billingVersion and config: recursive byte-sorted object keys,
array order retained, no trailing newline, and HTML characters unescaped.
Amounts in `money_prices.amountMicros` are decimal strings in CNY or USD. They are
separate from legacy USD-only route estimates; no customer price is stored here.
Credential envelopes contain base64 iv/tag/ct, use a SHA-256-derived AES-256 key,
12-byte nonce, 16-byte tag, and AAD `providerID + NUL + ref`.

POST prepare is idempotent by digest. POST activate takes id, expectedDigest and
digest; repeating the same operation is idempotent, rebinding it conflicts. GET
publications/{id} resolves unknown activation outcomes. GET state is private and
allows initial active-pointer reconciliation. Simulation only reads a prepared
runtime and never acquires capacity or contacts an upstream.

GET legacy exports configured route/provider metadata without secrets. The separate
GET legacy/credentials returns only sealed envelopes over the independently
authenticated private channel. Mock or unsupported providers are never imported
as paid upstreams.

New paid requests explicitly supply `extra_fields.naumi.config_digest`. Unknown
digests and aliases are rejected. Operations retain that digest, candidate routes,
original task ID and credential reference. They never use the active pointer to
resume. Requests without a digest retain the legacy engine and identity checks.

Account budgets and circuit state are shared across retained versions and key
rotation. A stable supplier id and endpoint identify its account; exact duplicate
credential identities are also merged. Historical versions retain their most
restrictive capacity limit until safe reference retirement is implemented. The
configured maximum is therefore an upper bound, not a guarantee of extra slots.

External provider endpoints require HTTPS. Existing internal origins must be in
server-only `MODEL_CONFIG_TRUSTED_ORIGINS`. Metadata targets are always forbidden.
API redirects are rejected and resolved addresses are checked/pinned before dial;
administrators cannot enable a redirect exception from a form.
