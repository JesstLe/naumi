# Architecture

## Decision

Use New API as the unified gateway/control plane and keep Naumi Router as an independent image-routing data plane.

```text
+-----------------------+     +----------------+     +----------------+     +-----------------------+
| Naumi infinite canvas | --> | New API        | --> | Naumi Router   | --> | authorized provider A |
| UI/jobs/assets/credits|     | unified gateway|     | policy/retry   |     +-----------------------+
+-----------------------+     +----------------+     +----------------+     +-----------------------+
                                   |                    |          +----> | authorized provider B |
                                   v                    v                +-----------------------+
                           channel/audit state   route telemetry
```

## Why New API stays in the path

Naumi owns the design product, while New API provides a standard gateway for multiple upstream channels, model aliases, service credentials, rate limits, audit logs, and a future external API product. Naumi uses an internal service token and keeps its product-credit ledger, avoiding duplicate customer charging.

## Role of Naumi Router

New API provides channel-level forwarding; Naumi Router provides request-level policy that New API does not know about: reference-image capability, native versus upscaled resolution, text accuracy, observed quality, actual settled upstream cost, and safe failover after asynchronous submission.

## Request path

1. Naumi authenticates the user, validates the selected canvas model, and reserves product credits.
2. Naumi sends an OpenAI-compatible generation or multipart edit request to New API using an internal service token.
3. New API resolves the public model alias and forwards the request to the Naumi Router channel using the router service token.
4. Naumi Router validates the body and derives requirements:
   - requested delivery size;
   - minimum quality tier;
   - text-rendering sensitivity;
   - whether 4K must be native rather than upscaled.
5. The policy engine filters disabled, unhealthy, or incapable routes.
6. It sorts eligible routes by estimated monetary cost, then expected latency, then stable route ID.
7. The provider adapter is invoked. A retriable failure advances to the next eligible route.
8. Naumi Router returns an OpenAI-shaped response through New API.
9. Naumi settles product credits and persists the returned image; the router retains actual route cost for margin analytics.

Routing extensions travel as `extra_fields.naumi` because New API's image DTO does not re-emit arbitrary top-level JSON fields. Multipart edit requests use the ordinary OpenAI fields and reference files; the unmodified New API OpenAI adaptor preserves `image`/`image[]` and mask parts.

## Security boundary

- The router requires a service bearer token on every generation request.
- `/healthz` and `/readyz` reveal no configuration or secrets.
- Request bodies are bounded before decoding.
- Prompts and credentials are not logged.
- Provider keys will be read only from a secret manager or environment variables and will never be stored in route configuration.
- Provider integrations remain dormant unless their server-side credential and route configuration are both supplied.

Automatic failover is deliberately narrower than ordinary HTTP retry. An adapter may permit fallback only when it knows that the upstream did not accept a billable job. APIMart submission retries reuse one idempotency key. Once APIMart or fal returns a task ID, polling, result-fetch, timeout, or output-validation failures stop the request instead of submitting a second paid generation elsewhere. A confirmed APIMart terminal failure may fall back because its documentation states that failed tasks are refunded.

## Next components

- persistent provider health and circuit breakers;
- persistent cost settlement from upstream responses (APIMart task receipts are currently logged);
- image-dimension and format verification;
- perceptual and OCR quality gates;
- shadow routing and offline evaluation;
- PostgreSQL route observations;
- Prometheus metrics without prompt content;
- full Naumi → New API → Router canvas smoke and failure/refund tests.
