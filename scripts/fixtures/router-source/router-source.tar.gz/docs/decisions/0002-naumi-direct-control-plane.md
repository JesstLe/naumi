# 0002 — Use Naumi as the design-SaaS control plane

- Status: rejected after clarifying the multi-upstream gateway requirement
- Date: 2026-09-19

## Context

The live Naumi repository already implements the responsibilities previously assigned to New API: user authentication, credit reservation and refunds, asynchronous generation jobs, canvas lineage, model selection, image storage, and artwork persistence. Its generation route already calls an OpenAI-compatible service through the OpenAI SDK.

Putting New API between Naumi and Naumi Router would duplicate control-plane state and introduce another billing and failure boundary into every canvas request.

## Considered alternative

Naumi could call Naumi Router directly over the internal network:

```text
Naumi -> Naumi Router -> authorized upstream providers
```

The router still exposes the OpenAI-compatible surface needed by the current application:

- `GET /v1/models`;
- `POST /v1/images/generations`;
- `POST /v1/images/edits` with multipart reference images.

This shorter path was not selected because it removes the unified New API gateway that the planned multi-upstream and future external-API product require.

## Consequences

- No Naumi canvas business code needs to understand APIMart or fal protocols.
- The router remains replaceable and testable as a separate service.
- New API remains in the production request path as the unified gateway.
- The router service token must remain server-side and the router must not be publicly reachable.
