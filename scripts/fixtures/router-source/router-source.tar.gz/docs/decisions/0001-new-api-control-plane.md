# 0001 — Use New API as a separate control plane

- Status: accepted
- Date: 2026-09-19

## Context

Naumi needs one gateway for multiple upstream channels, model aliases, service tokens, rate limits, audit logs, and a future external API product. Its differentiated capability remains the infinite-canvas workflow and image-task routing across quality tiers and authorized upstream providers.

## Decision

Run an unmodified New API deployment as the unified gateway. Naumi calls it with an internal service token and keeps the design product's existing credit ledger. Run Naumi Router as an independent OpenAI-compatible service behind it. New API sees Naumi's stable public model aliases; Naumi Router owns task classification, route selection, fallback, and actual upstream-cost telemetry.

## Consequences

- We avoid rebuilding commodity billing and account features.
- We do not maintain a New API fork.
- New API branding and attribution remain intact.
- Naumi Router can remain independently licensed, subject to final legal review of the deployed combination.
- Customer billing and upstream cost settlement are separate ledgers and must be reconciled.
- A New API outage affects the customer control plane even if the router remains healthy, so both services need independent health checks and backups.
