# MVP acceptance

The commercial hypothesis is validated only when the router can lower weighted average image cost without a material drop in accepted output quality.

## Phase 0 — local vertical slice

- [x] OpenAI-compatible generation endpoint
- [x] service-to-service bearer authentication
- [x] request size and field validation
- [x] deterministic route eligibility and scoring
- [x] provider adapter boundary
- [x] mock generation and fallback tests
- [x] implement the OpenAI Images integration contract (`models`, `generations`, multipart `edits`)
- [x] verify in source that unmodified New API forwards multipart `image`/`image[]` edit files through its OpenAI adaptor
- [x] run Naumi's real canvas smoke suites through New API and the router
- [x] run an unmodified New API live integration smoke test

## Server staging gate

- [x] deploy the isolated gateway under `/opt/naumi-gateway`
- [x] bind Naumi Router to `127.0.0.1` and verify systemd blocks external New API access
- [x] provision registration-disabled New API with one internal token and four aliases
- [x] verify `/readyz`, `/api/setup`, and `/v1/models` without a paid generation
- [x] obtain explicit approval before the first server-side paid smoke request
- [x] complete one server-side APIMart 1K generation (2026-09-19 passed after private Mihomo egress was enabled)
- [x] validate isolated server Naumi canvas reference generation, saved artwork, six-credit settlement, pre-submit rejection refund and browser model selection ([evidence](research/2026-09-19-server-canvas.md))
- [ ] switch Naumi only after the isolated chain passes and rollback is recorded

## Phase 1 — APIMart technical and unit-economics test

- [ ] obtain written permission from APIMart for resale/white-label use before any customer pilot
- [x] implement the APIMart GPT Image 2.5 Ext adapter without committing secrets
- [x] add idempotent submit retry and double-charge-safe fallback behavior
- [x] verify the adapter against a local fake APIMart server
- [x] implement APIMart reference-image transport through documented `image_urls` data URIs
- [x] perform one explicitly approved paid APIMart 1K request
- [x] perform one explicitly approved paid APIMart reference-image edit request
- [x] record task ID, route, duration, success, settled USD cost, and Credits cost
- [x] verify the returned source format and actual pixel dimensions
- [ ] repeat at 2K and 4K only after the 1K path and billing record pass
- [ ] distinguish native 4K from post-generation upscaling; APIMart remains `native_4k: false` until proven

## Phase 1b — backup provider

- [x] implement the fal Queue API adapter without committing secrets
- [x] verify the adapter against a local fake fal server
- [ ] perform one explicitly approved paid fal request
- [ ] reconcile failed-request billing and refunds

## Phase 2 — routing experiment

- [ ] add a second independently authorized provider
- [ ] run the same 10 prompts across every quality route
- [ ] measure acceptance rate, OCR accuracy, identity preservation, P50/P95 latency, and effective cost per accepted image
- [ ] shadow-evaluate policy changes before sending paid traffic
- [ ] demonstrate automatic fallback without double-charging the customer

## Product slice — JD-style product detail page

- [x] inspect and record the target long-image structure
- [x] run a 10-case APIMart 1K asset benchmark
- [x] demonstrate 9/10 initial human acceptance at ¥0.595 total model cost
- [x] ingest one real product reference image and record the package-front evidence boundary
- [x] plan and implement eight editable commerce modules
- [ ] generate four visual assets through APIMart
- [x] render and visually verify a 790 px-wide long image with deterministic typography
- [ ] verify approved copy with OCR and require human approval

## Phase 3 — paid pilot

- [ ] customer credit price is configured in Naumi by router model alias
- [ ] weighted upstream cost is below the target for seven consecutive days
- [ ] gross margin includes payment fees, storage, bandwidth, moderation, retry, and refund costs
- [ ] customer-visible terms accurately distinguish native and upscaled delivery
- [ ] production security and dependency review passes
