#!/usr/bin/env bash
set -euo pipefail

prototype_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
chrome_bin="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
output_file="${prototype_dir}/output/nexfort-detail-v1.png"

mkdir -p "${prototype_dir}/output"

if [[ ! -x "${chrome_bin}" ]]; then
  echo "Google Chrome was not found at ${chrome_bin}" >&2
  exit 1
fi

"${chrome_bin}" \
  --headless \
  --disable-gpu \
  --hide-scrollbars \
  --no-sandbox \
  --force-device-scale-factor=1 \
  --window-size=790,7830 \
  --screenshot="${output_file}" \
  "file://${prototype_dir}/index.html"

echo "Rendered ${output_file}"
