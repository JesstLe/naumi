# NexFort product detail prototype V1

This 790 px-wide long-image prototype tests the modular JD-style product-detail workflow using the user-provided package photograph.

## Evidence boundary

- The brand, English product name, product type, net content, pack count, zinc-gluconate addition statement, and Belgian inulin raw-material statement are transcribed from the visible front of `assets/product-source.jpg`.
- Raspberry, mannan oligosaccharide, and ginseng are presented only as terms in the product name—not as a full ingredient list or evidence of efficacy.
- Directions, intended users, contraindications, standards, registrations, manufacturing details, nutrition facts, test reports, and efficacy claims remain unverified.
- The page intentionally makes no medical, treatment, disease-prevention, or health-function claim.

## Render

Open `index.html` at a 790 px viewport. The deterministic text layer is the editable source of truth; the PNG export is a review artifact. Run `./render.sh` to recreate the 790 × 7830 PNG.

The generated background-removal experiment was rejected because it did not meet the product-identity preservation gate. The prototype uses the original user-provided package photograph directly.
